(function(){
  const CHAVE='look_carrinho';
  const WA=document.body.getAttribute('data-wa');
  let itens={};
  const guarda=function(){try{localStorage.setItem(CHAVE,JSON.stringify(itens))}catch(_){/* sem armazenamento */}};
  const carrega=function(){
    try{
      const j=JSON.parse(localStorage.getItem(CHAVE)||'{}');
      Object.keys(j).forEach(function(k){
        const v=j[k];
        if(v&&typeof v.nome==='string'&&Number.isInteger(v.q)&&v.q>0&&v.q<=999)itens[k]={nome:v.nome.slice(0,80),q:v.q,tipo:v.tipo==='mobilia'?'mobilia':'kit'};
      });
    }catch(_){itens={}}
  };
  const total=function(){return Object.keys(itens).reduce(function(s,k){return s+itens[k].q},0)};
  const el=function(id){return document.getElementById(id)};

  /* ---------- Carrinho ---------- */
  function render(){
    const n=total(),lista=el('carLista'),form=el('carForm'),vazio=el('carVazio');
    const c=el('contN');c.textContent=String(n);c.setAttribute('aria-label',n+(n===1?' item':' itens'));
    lista.textContent='';
    const ks=Object.keys(itens);
    vazio.hidden=ks.length>0;form.hidden=ks.length===0;
    ks.forEach(function(k){
      const it=itens[k],li=document.createElement('li');
      const nome=document.createElement('div');nome.className='n';nome.textContent=it.nome;
      const q=document.createElement('div');q.className='qtd';q.setAttribute('role','group');q.setAttribute('aria-label','Quantidade de '+it.nome);
      const m=document.createElement('button');m.type='button';m.textContent='−';m.setAttribute('aria-label','Diminuir quantidade de '+it.nome);
      const v=document.createElement('output');v.className='v';v.textContent=String(it.q);
      const p=document.createElement('button');p.type='button';p.textContent='+';p.setAttribute('aria-label','Aumentar quantidade de '+it.nome);
      m.addEventListener('click',function(){muda(k,-1)});p.addEventListener('click',function(){muda(k,1)});
      q.append(m,v,p);
      const rm=document.createElement('button');rm.type='button';rm.className='rm';rm.textContent='Remover';rm.setAttribute('aria-label','Remover '+it.nome+' do carrinho');
      rm.addEventListener('click',function(){delete itens[k];guarda();render();el('abreCar').focus&&0});
      li.append(nome,q,rm);lista.append(li);
    });
  }
  function muda(k,d){
    if(!itens[k])return;
    itens[k].q=Math.max(1,Math.min(999,itens[k].q+d));
    guarda();render();
  }
  function adiciona(id,nome,tipo,q){
    if(itens[id])itens[id].q=Math.min(999,itens[id].q+q);else itens[id]={nome:nome,q:q,tipo:tipo};
    guarda();render();
  }

  let ultimoFoco=null;
  function abreCarrinho(){
    ultimoFoco=document.activeElement;
    el('carWrap').hidden=false;
    document.body.style.overflow='hidden';
    el('car').focus();
  }
  function fechaCarrinho(){
    el('carWrap').hidden=true;
    document.body.style.overflow='';
    if(ultimoFoco&&ultimoFoco.focus)ultimoFoco.focus();
  }

  function initCarrinho(){
    carrega();
    const hoje=new Date();
    const iso=hoje.getFullYear()+'-'+String(hoje.getMonth()+1).padStart(2,'0')+'-'+String(hoje.getDate()).padStart(2,'0');
    el('cData').min=iso;
    document.querySelectorAll('.item').forEach(function(card){
      const btn=card.querySelector('.add'),v=card.querySelector('.v');
      const id=card.dataset.id,nome=card.dataset.nome,tipo=card.dataset.cat;
      if(v){
        card.querySelector('.menos').addEventListener('click',function(){v.textContent=String(Math.max(1,Number(v.textContent)-1))});
        card.querySelector('.mais').addEventListener('click',function(){v.textContent=String(Math.min(999,Number(v.textContent)+1))});
      }
      btn.addEventListener('click',function(){
        adiciona(id,nome,tipo,v?Number(v.textContent):1);
        const txt=btn.firstChild.nodeValue;btn.classList.add('ok');btn.firstChild.nodeValue='Adicionado ✓';
        setTimeout(function(){btn.classList.remove('ok');btn.firstChild.nodeValue=txt},1600);
      });
    });
    el('abreCar').addEventListener('click',abreCarrinho);
    el('carX').addEventListener('click',fechaCarrinho);
    el('carFundo').addEventListener('click',fechaCarrinho);
    el('cLimpar').addEventListener('click',function(){itens={};guarda();render()});
    document.addEventListener('keydown',function(e){
      const w=el('carWrap');if(w.hidden)return;
      if(e.key==='Escape'){fechaCarrinho();return}
      if(e.key==='Tab'){
        const f=[].slice.call(el('car').querySelectorAll('button,input,a[href]')).filter(function(x){return x.offsetParent!==null&&!x.disabled});
        if(!f.length)return;
        const a=f[0],z=f[f.length-1];
        if(e.shiftKey&&(document.activeElement===a||document.activeElement===el('car'))){z.focus();e.preventDefault()}
        else if(!e.shiftKey&&document.activeElement===z){a.focus();e.preventDefault()}
      }
    });
    el('carForm').addEventListener('submit',function(e){
      e.preventDefault();
      const d=el('cData').value,ok=el('cAceite').checked;
      el('cDataE').textContent='';el('cAceiteE').textContent='';el('cGeralE').textContent='';
      let bad=false;
      if(!Object.keys(itens).length){el('cGeralE').textContent='Adicione ao menos um item ao carrinho.';return}
      if(!d||d<el('cData').min){el('cDataE').textContent='Escolha uma data de locação a partir de hoje.';el('cData').focus();bad=true}
      if(!ok){el('cAceiteE').textContent='Marque a caixa para enviar o pedido pelo WhatsApp.';if(!bad)el('cAceite').focus();bad=true}
      if(bad)return;
      const a=document.createElement('a');
      a.href=montaLink(d);a.target='_blank';a.rel='noopener';
      document.body.appendChild(a);a.click();a.remove();
    });
    render();
  }

  function montaLink(d){
    const p=d.split('-'),dataBr=p[2]+'/'+p[1]+'/'+p[0];
    const nome=el('cNome').value.trim().slice(0,80);
    const ks=Object.keys(itens);
    const kits=ks.filter(function(k){return itens[k].tipo==='kit'});
    const mob=ks.filter(function(k){return itens[k].tipo!=='kit'});
    let t='Olá! Gostaria de pedir um orçamento de locação na Look de Festas.\n';
    if(nome)t+='Nome: '+nome+'\n';
    t+='Data da locação: '+dataBr+'\n\n';
    if(kits.length){t+='Kit festa:\n';kits.forEach(function(k){t+='- '+itens[k].q+'x '+itens[k].nome+'\n'});t+='\n'}
    if(mob.length){t+='Mesas e cadeiras:\n';mob.forEach(function(k){t+='- '+itens[k].q+' '+itens[k].nome.replace(' para locação','').toLowerCase()+(itens[k].q>1?'s':'')+'\n'});t+='\n'}
    t+='Pode me passar os valores e a disponibilidade? Obrigado(a)!';
    return 'https://wa.me/'+WA+'?text='+encodeURIComponent(t);
  }

  /* ---------- Catálogo: filtros ---------- */
  function initFiltros(){
    const bs=document.querySelectorAll('.filtro'),cards=document.querySelectorAll('.item');
    bs.forEach(function(b){
      b.addEventListener('click',function(){
        const f=b.dataset.f;
        bs.forEach(function(x){const on=x===b;x.classList.toggle('on',on);x.setAttribute('aria-pressed',on?'true':'false')});
        cards.forEach(function(c){c.hidden=!(f==='todos'||c.dataset.cat===f)});
      });
    });
  }

  /* ---------- Vídeo ---------- */
  function initVideo(){
    const v=el('vid'),pl=el('vidPlay'),so=el('vidSom');
    const reduz=window.matchMedia&&window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    const atualiza=function(){
      pl.textContent=v.paused?'Reproduzir':'Pausar';
      pl.setAttribute('aria-label',v.paused?'Reproduzir vídeo':'Pausar vídeo');
      so.textContent=v.muted?'Ativar som':'Silenciar';
      so.setAttribute('aria-label',v.muted?'Ativar som do vídeo':'Silenciar vídeo');
    };
    pl.addEventListener('click',function(){if(v.paused){v.play().catch(function(){})}else{v.pause()}});
    so.addEventListener('click',function(){v.muted=!v.muted;if(v.paused)v.play().catch(function(){});atualiza()});
    v.addEventListener('play',atualiza);v.addEventListener('pause',atualiza);
    if('IntersectionObserver' in window&&!reduz){
      new IntersectionObserver(function(es){es.forEach(function(e){
        if(e.isIntersecting){if(!v.dataset.manual)v.play().catch(function(){})}else v.pause();
      })},{threshold:.35}).observe(v);
      pl.addEventListener('click',function(){v.dataset.manual='1'});
    }
    atualiza();
  }

  function initMenu(){
    const gav=el('gaveta'),bg=el('burger');
    const abre=function(v){
      gav.classList.toggle('on',v);
      gav.setAttribute('aria-hidden',v?'false':'true');
      bg.setAttribute('aria-expanded',v?'true':'false');
      bg.setAttribute('aria-label',v?'Fechar menu':'Abrir menu');
      document.body.style.overflow=v?'hidden':'';
      if(v){el('gavetaX').focus()}else{bg.focus()}
    };
    bg.addEventListener('click',function(){abre(true)});
    el('gavetaX').addEventListener('click',function(){abre(false)});
    el('gavetaFundo').addEventListener('click',function(){abre(false)});
    gav.querySelectorAll('a').forEach(function(a){a.addEventListener('click',function(){abre(false)})});
    document.addEventListener('keydown',function(e){if(e.key==='Escape'&&gav.classList.contains('on'))abre(false)});
  }
  function initHoje(){
    const d=String(new Date().getDay());
    document.querySelectorAll('#tab tr').forEach(function(tr){if(tr.dataset.d===d){tr.classList.add('hoje');tr.setAttribute('aria-current','date')}});
  }

  [initCarrinho,initFiltros,initVideo,initMenu,initHoje].forEach(function(f){f()});
})();
