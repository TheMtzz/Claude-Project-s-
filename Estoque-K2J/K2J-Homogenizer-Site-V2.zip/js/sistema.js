(function () {
  'use strict';
  // Sistema interno da K2J: DEMONSTRAÇÃO LOCAL.
  // Os dados ficam só neste navegador (localStorage). Não é seguro para uso real:
  // o login de verdade precisa de servidor e banco de dados.
  var MODO_TESTE = true;
  var P = 'k2j_demo_';
  var d = document;
  d.documentElement.classList.add('js');
  function $(s, r) { return (r || d).querySelector(s); }
  function $$(s, r) { return Array.prototype.slice.call((r || d).querySelectorAll(s)); }
  function esc(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }

  /* ---------- SHA-256 (domínio público, adaptado) ---------- */
  function sha256(ascii) {
    function rr(v, a) { return (v >>> a) | (v << (32 - a)); }
    var mp = Math.pow, mw = mp(2, 32), result = '', i, j, words = [], bl = ascii.length * 8;
    var hash = sha256.h = sha256.h || [], k = sha256.k = sha256.k || [], pc = k.length, comp = {};
    for (var c = 2; pc < 64; c++) {
      if (!comp[c]) {
        for (i = 0; i < 313; i += c) comp[i] = c;
        hash[pc] = (mp(c, 0.5) * mw) | 0; k[pc++] = (mp(c, 1 / 3) * mw) | 0;
      }
    }
    ascii += '\x80'; while (ascii.length % 64 - 56) ascii += '\x00';
    for (i = 0; i < ascii.length; i++) { j = ascii.charCodeAt(i); words[i >> 2] |= j << ((3 - i) % 4) * 8; }
    words[words.length] = ((bl / mw) | 0); words[words.length] = bl;
    for (j = 0; j < words.length;) {
      var w = words.slice(j, j += 16), old = hash; hash = hash.slice(0, 8);
      for (i = 0; i < 64; i++) {
        var w15 = w[i - 15], w2 = w[i - 2], a = hash[0], e = hash[4];
        var t1 = hash[7] + (rr(e, 6) ^ rr(e, 11) ^ rr(e, 25)) + ((e & hash[5]) ^ ((~e) & hash[6])) + k[i] +
          (w[i] = (i < 16) ? w[i] : (w[i - 16] + (rr(w15, 7) ^ rr(w15, 18) ^ (w15 >>> 3)) + w[i - 7] + (rr(w2, 17) ^ rr(w2, 19) ^ (w2 >>> 10))) | 0);
        var t2 = (rr(a, 2) ^ rr(a, 13) ^ rr(a, 22)) + ((a & hash[1]) ^ (a & hash[2]) ^ (hash[1] & hash[2]));
        hash = [(t1 + t2) | 0].concat(hash); hash[4] = (hash[4] + t1) | 0;
      }
      for (i = 0; i < 8; i++) hash[i] = (hash[i] + old[i]) | 0;
    }
    for (i = 0; i < 8; i++) for (j = 3; j + 1; j--) { var b = (hash[i] >> (j * 8)) & 255; result += ((b < 16) ? 0 : '') + b.toString(16); }
    return result;
  }
  function utf8(s) { return unescape(encodeURIComponent(s)); }

  /* ---------- armazenamento local ---------- */
  var mem = {};
  function ler(k, pad) {
    try { var v = localStorage.getItem(P + k); if (v != null) return JSON.parse(v); } catch (e) {}
    return (k in mem) ? mem[k] : pad;
  }
  function gravar(k, v) { mem[k] = v; try { localStorage.setItem(P + k, JSON.stringify(v)); } catch (e) {} }
  function sessGet() { try { return sessionStorage.getItem(P + 'sessao'); } catch (e) { return mem.sessao || null; } }
  function sessSet(v) { try { if (v == null) sessionStorage.removeItem(P + 'sessao'); else sessionStorage.setItem(P + 'sessao', v); } catch (e) { mem.sessao = v; } }

  function novoId() { return Date.now().toString(36) + Math.random().toString(36).slice(2, 7); }
  function agora() { return new Date().toISOString(); }
  function dataHora(iso) { var t = new Date(iso); return t.toLocaleDateString('pt-BR') + ' ' + t.toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' }); }
  function arred(n) { return Math.round(n * 1000) / 1000; }
  function fmt(n) { return Number(n).toLocaleString('pt-BR', { maximumFractionDigits: 3 }); }
  function num(s) {
    s = String(s).trim().replace(',', '.');
    if (!/^\d+(\.\d{1,3})?$/.test(s)) return NaN;
    return Number(s);
  }
  function norm(s) { return String(s || '').toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, ''); }

  /* ---------- usuários, itens, movimentos, registro ---------- */
  function usuarios() { return ler('usuarios', []); }
  function itens() { return ler('itens', []); }
  function movs() { return ler('movs', []); }
  function mkUser(o) {
    var sal = novoId() + novoId();
    return { id: novoId(), nome: o.nome, email: o.email, empresa: o.empresa || '', telefone: o.telefone || '', usuario: o.usuario.toLowerCase(), sal: sal, hash: sha256(sal + ':' + utf8(o.senha)), perfil: o.perfil, ativo: true, criado: agora() };
  }
  function checaSenha(u, senha) { return sha256(u.sal + ':' + utf8(senha)) === u.hash; }

  var atual = null; // usuário logado (nesta página)
  function registra(acao, detalhe, quem) {
    var l = ler('log', []), u = quem || atual;
    l.unshift({ id: novoId(), quando: agora(), uid: u ? u.id : '', nome: u ? u.nome : '', usuario: u ? u.usuario : '', acao: acao, detalhe: detalhe || '' });
    if (l.length > 1500) l.length = 1500;
    gravar('log', l);
  }
  var ACAO = {
    login: 'Entrou no sistema', login_falhou: 'Tentativa de login recusada', logout: 'Saiu do sistema', tela: 'Abriu uma tela',
    usuario_criado: 'Criou usuário', usuario_ativado: 'Ativou usuário', usuario_desativado: 'Desativou usuário', senha_redefinida: 'Redefiniu senha',
    usuario_excluido: 'Excluiu usuário', item_criado: 'Cadastrou item', item_editado: 'Editou item', item_excluido: 'Excluiu item',
    entrada: 'Registrou entrada', saida: 'Registrou saída', contagem: 'Ajustou contagem', restaurar: 'Restaurou dados de teste'
  };

  var SEED_ITENS = [
    ['MP-001', 'Barra de aço inox 304 Ø50 mm', 'Matéria-prima', 'm', 10, 42],
    ['MP-002', 'Chapa de aço inox 316 e=6 mm', 'Matéria-prima', 'un', 8, 5],
    ['PC-101', 'Pistão cerâmico Ø25 mm', 'Peças', 'un', 4, 12],
    ['PC-102', 'Válvula homogeneizadora (conjunto)', 'Peças', 'un', 2, 3],
    ['PC-103', 'Anel de vedação NBR', 'Peças', 'un', 30, 18],
    ['PC-104', 'Rolamento 6205 2RS', 'Peças', 'un', 10, 24],
    ['FX-201', 'Parafuso M12 x 60 inox', 'Fixação', 'un', 100, 340],
    ['FX-202', 'Porca M12 inox', 'Fixação', 'un', 100, 52],
    ['CS-301', 'Óleo lubrificante ISO VG 68', 'Consumíveis', 'L', 20, 60],
    ['CS-302', 'Inserto de metal duro CNMG', 'Consumíveis', 'un', 20, 36],
    ['CS-303', 'Fluido de corte', 'Consumíveis', 'L', 40, 85],
    ['EP-401', 'Luva de proteção', 'EPI', 'par', 10, 25]
  ];
  // [índice, tipo, quantidade, horas atrás, responsável (0 admin, 1 operador), destino]
  var SEED_MOVS = [
    [4, 'saida', 6, 2, 1, 'Montagem do homogeneizador lote 14'],
    [8, 'entrada', 20, 26, 0, 'Fornecedor Exemplo Lubrificantes, NF 1203'],
    [0, 'saida', 8, 30, 1, 'Pedido 0347'],
    [7, 'saida', 30, 50, 1, 'Montagem do homogeneizador lote 14'],
    [5, 'entrada', 10, 74, 0, 'NF 0981'],
    [1, 'saida', 3, 78, 1, 'Pedido 0345'],
    [9, 'saida', 4, 98, 1, 'Usinagem de eixos, pedido 0340'],
    [2, 'entrada', 4, 122, 0, 'NF 0950'],
    [6, 'saida', 60, 146, 1, 'Montagem do homogeneizador lote 13']
  ];
  function semear(forcar) {
    if (!forcar && ler('semeado', false) && usuarios().length) return;
    var us = [
      mkUser({ nome: 'Administrador de Teste', email: 'admin.teste@exemplo.com', empresa: 'K2J Homogenizer (teste)', telefone: '(00) 00000-0000', usuario: 'admin', senha: 'k2j2026', perfil: 'admin' }),
      mkUser({ nome: 'Operador de Teste', email: 'operador.teste@exemplo.com', empresa: 'K2J Homogenizer (teste)', telefone: '(00) 00000-0000', usuario: 'operador', senha: 'k2j2026', perfil: 'funcionario' })
    ];
    gravar('usuarios', us);
    var its = SEED_ITENS.map(function (s) { return { id: novoId(), codigo: s[0], nome: s[1], categoria: s[2], unidade: s[3], minimo: s[4], saldo: s[5] }; });
    gravar('itens', its);
    var run = {}, ms = [];
    SEED_MOVS.forEach(function (m) {
      var it = its[m[0]];
      if (!(it.id in run)) run[it.id] = it.saldo;
      var apos = run[it.id];
      run[it.id] = apos - (m[1] === 'entrada' ? m[2] : -m[2]);
      var u = us[m[4]];
      ms.push({ id: novoId(), quando: new Date(Date.now() - m[3] * 3600000).toISOString(), tipo: m[1], itemId: it.id, codigo: it.codigo, nome: it.nome, un: it.unidade, qtd: m[2], saldoApos: apos, usuario: u.nome, obs: m[5] });
    });
    gravar('movs', ms);
    gravar('log', []);
    gravar('semeado', true);
  }

  /* ---------- sessão ---------- */
  function usuarioAtual() {
    var id = sessGet(); if (!id) return null;
    var u = usuarios().filter(function (x) { return x.id === id; })[0];
    return (u && u.ativo) ? u : null;
  }
  function exige(admin) {
    var u = usuarioAtual();
    if (!u) { location.replace('area-funcionario.html'); return null; }
    if (admin && u.perfil !== 'admin') { location.replace('painel.html'); return null; }
    atual = u; return u;
  }
  function topo(u) {
    var pg = d.body.getAttribute('data-pagina');
    $('#sis-nome').textContent = u.nome + (u.perfil === 'admin' ? ' (administrador)' : '');
    $$('.sis-nav a').forEach(function (a) {
      if (a.hasAttribute('data-admin')) a.hidden = u.perfil !== 'admin';
      if (a.getAttribute('data-pg') === pg) a.setAttribute('aria-current', 'page');
    });
    $('#sair').addEventListener('click', function () {
      registra('logout', 'Saiu do sistema');
      sessSet(null); location.href = 'area-funcionario.html';
    });
  }
  var TELA = { painel: 'Painel inicial', estoque: 'Controle de estoque', usuarios: 'Controle de usuários' };

  /* ---------- utilitários de interface ---------- */
  function abas(raiz, cb) {
    var bs = $$('[role="tab"]', raiz), ps = bs.map(function (b) { return d.getElementById(b.getAttribute('aria-controls')); });
    function ativa(i, foco) {
      bs.forEach(function (b, k) { b.setAttribute('aria-selected', k === i ? 'true' : 'false'); b.tabIndex = k === i ? 0 : -1; ps[k].hidden = k !== i; });
      if (foco) bs[i].focus();
      if (cb) cb(i);
    }
    bs.forEach(function (b, i) {
      b.addEventListener('click', function () { ativa(i); });
      b.addEventListener('keydown', function (e) {
        var n = -1;
        if (e.key === 'ArrowRight') n = (i + 1) % bs.length;
        else if (e.key === 'ArrowLeft') n = (i - 1 + bs.length) % bs.length;
        else if (e.key === 'Home') n = 0; else if (e.key === 'End') n = bs.length - 1;
        if (n > -1) { e.preventDefault(); ativa(n, true); }
      });
    });
    return ativa;
  }
  function dialogo(o, ok) {
    var dl = d.createElement('dialog'); dl.className = 'dlg';
    dl.setAttribute('aria-label', o.titulo);
    dl.innerHTML = '<form method="dialog"><h2 class="h-s">' + esc(o.titulo) + '</h2><p>' + esc(o.texto) + '</p>' +
      (o.senha ? '<label class="campo"><span>Nova senha (mínimo 6 caracteres)</span><input type="password" autocomplete="new-password"></label><p class="erro" role="alert" hidden></p>' : '') +
      '<div class="dlg-acoes"><button class="botao botao--vazio" value="cancel">Cancelar</button><button class="botao ' + (o.perigo ? 'botao--perigo' : 'botao--cheio') + '" value="ok">' + esc(o.botao || 'Confirmar') + '</button></div></form>';
    d.body.appendChild(dl);
    var volta = d.activeElement;
    $('[value="cancel"]', dl).addEventListener('click', function (e) { e.preventDefault(); dl.close(); });
    $('[value="ok"]', dl).addEventListener('click', function (e) {
      e.preventDefault();
      if (o.senha) {
        var v = $('input', dl).value;
        if (v.length < 6) { var er = $('.erro', dl); er.textContent = 'A senha precisa ter pelo menos 6 caracteres.'; er.hidden = false; return; }
        dl.close(); ok(v);
      } else { dl.close(); ok(); }
    });
    dl.addEventListener('close', function () { dl.remove(); if (volta && d.contains(volta)) volta.focus(); });
    dl.showModal();
    var f = $('input', dl) || $('[value="cancel"]', dl); f.focus();
  }
  function senhaToggle(inp, btn) {
    btn.addEventListener('click', function () {
      var ver = inp.type === 'password';
      inp.type = ver ? 'text' : 'password';
      btn.textContent = ver ? 'Ocultar' : 'Mostrar';
      btn.setAttribute('aria-pressed', ver ? 'true' : 'false');
    });
  }
  function mascaraTel(v) {
    var n = v.replace(/\D/g, '').slice(0, 11);
    if (n.length > 10) return '(' + n.slice(0, 2) + ') ' + n.slice(2, 7) + '-' + n.slice(7);
    if (n.length > 6) return '(' + n.slice(0, 2) + ') ' + n.slice(2, 6) + '-' + n.slice(6);
    if (n.length > 2) return '(' + n.slice(0, 2) + ') ' + n.slice(2);
    return n ? '(' + n : '';
  }
  function mostra(el, msg) { el.textContent = msg; el.hidden = false; }
  function csv(linhas, nome) {
    function cel(v) { v = String(v == null ? '' : v); if (/^[=+\-@]/.test(v)) v = "'" + v; return '"' + v.replace(/"/g, '""') + '"'; }
    var txt = '﻿' + linhas.map(function (l) { return l.map(cel).join(';'); }).join('\r\n');
    var a = d.createElement('a');
    a.href = URL.createObjectURL(new Blob([txt], { type: 'text/csv;charset=utf-8' }));
    a.download = nome; d.body.appendChild(a); a.click();
    setTimeout(function () { URL.revokeObjectURL(a.href); a.remove(); }, 500);
  }

  /* =====================================================
     PÁGINA: LOGIN
     ===================================================== */
  function paginaLogin() {
    semear();
    if (usuarioAtual()) { location.replace('painel.html'); return; }
    var f = $('#form-login'), er = $('#login-erro'), inU = f.usuario, inS = f.senha;
    senhaToggle(inS, $('#ver-senha'));
    var box = $('#teste-box');
    if (MODO_TESTE) {
      box.hidden = false;
      $$('[data-usar]', box).forEach(function (b) {
        b.addEventListener('click', function () {
          inU.value = b.getAttribute('data-usar'); inS.value = 'k2j2026'; er.hidden = true;
          $('button[type="submit"]', f).focus();
        });
      });
    }
    f.addEventListener('submit', function (e) {
      e.preventDefault();
      var nome = inU.value.trim().toLowerCase(), senha = inS.value;
      inU.removeAttribute('aria-invalid'); inS.removeAttribute('aria-invalid');
      if (!nome) { mostra(er, 'Digite o usuário.'); inU.setAttribute('aria-invalid', 'true'); inU.focus(); return; }
      if (!senha) { mostra(er, 'Digite a senha.'); inS.setAttribute('aria-invalid', 'true'); inS.focus(); return; }
      var u = usuarios().filter(function (x) { return x.usuario === nome; })[0];
      if (!u || !checaSenha(u, senha)) {
        registra('login_falhou', 'Usuário digitado: ' + nome, { id: '', nome: '', usuario: nome });
        mostra(er, 'Usuário ou senha incorretos.'); inS.value = ''; inS.focus(); return;
      }
      if (!u.ativo) {
        registra('login_falhou', 'Usuário desativado tentou entrar', u);
        mostra(er, 'Este usuário está desativado. Fale com o administrador.'); return;
      }
      sessSet(u.id); atual = u;
      registra('login', 'Entrou no sistema');
      location.href = 'painel.html';
    });
  }

  /* =====================================================
     PÁGINA: PAINEL (duas opções)
     ===================================================== */
  function paginaPainel() {
    var u = exige(false); if (!u) return;
    topo(u); registra('tela', 'Abriu a tela: ' + TELA.painel);
    $('#ola').textContent = 'Olá, ' + u.nome.split(' ')[0] + '.';
    var its = itens(), baixos = its.filter(function (i) { return i.saldo < i.minimo; });
    $('#pn-itens').textContent = its.length; $('#pn-baixo').textContent = baixos.length;
    $('#pn-usu').textContent = usuarios().filter(function (x) { return x.ativo; }).length;
    if (u.perfil !== 'admin') {
      var m = $('#mod-usuarios');
      m.classList.add('modulo--off');
      $('#mod-usuarios-btn').hidden = true;
      $('#mod-usuarios-aviso').hidden = false;
      $('#restaurar').hidden = true;
    }
    $('#restaurar').addEventListener('click', function () {
      dialogo({ titulo: 'Restaurar dados de teste', texto: 'Isso apaga o que foi cadastrado neste navegador e volta aos dados de exemplo. Você precisará entrar de novo.', botao: 'Restaurar', perigo: true }, function () {
        registra('restaurar', 'Restaurou os dados de teste');
        semear(true); sessSet(null); location.href = 'area-funcionario.html';
      });
    });
  }

  /* =====================================================
     PÁGINA: USUÁRIOS (admin)
     ===================================================== */
  function paginaUsuarios() {
    var u = exige(true); if (!u) return;
    topo(u); registra('tela', 'Abriu a tela: ' + TELA.usuarios);
    var tb = $('#t-usu tbody'), busca = $('#usu-busca'), form = $('#f-usu'), er = $('#usu-erro'), ok = $('#usu-ok');
    senhaToggle($('#u-senha'), $('#u-ver'));
    $('#u-tel').addEventListener('input', function (e) { e.target.value = mascaraTel(e.target.value); });

    function adminsAtivos() { return usuarios().filter(function (x) { return x.ativo && x.perfil === 'admin'; }).length; }
    function lista() {
      var q = norm(busca.value), todos = usuarios();
      var vis = todos.filter(function (x) { return !q || norm([x.nome, x.usuario, x.email, x.empresa, x.telefone, x.perfil === 'admin' ? 'administrador' : 'funcionario', x.ativo ? 'ativo' : 'desativado'].join(' ')).indexOf(q) > -1; });
      $('#usu-cont').textContent = vis.length + (vis.length === 1 ? ' usuário' : ' usuários') + (q ? ' encontrados' : ' cadastrados');
      if (!vis.length) { tb.innerHTML = '<tr><td colspan="6" class="vazio">Nenhum usuário encontrado.</td></tr>'; return; }
      tb.innerHTML = vis.map(function (x) {
        var eu = x.id === u.id, ultimo = x.ativo && x.perfil === 'admin' && adminsAtivos() < 2;
        var ac = '<button class="botao botao--vazio botao--p" type="button" data-acao="senha" data-id="' + x.id + '">Nova senha</button>';
        if (!eu && !ultimo) {
          ac += '<button class="botao botao--vazio botao--p" type="button" data-acao="' + (x.ativo ? 'desativar' : 'ativar') + '" data-id="' + x.id + '">' + (x.ativo ? 'Desativar' : 'Ativar') + '</button>';
          ac += '<button class="botao botao--perigo botao--p" type="button" data-acao="excluir" data-id="' + x.id + '">Excluir</button>';
        }
        return '<tr><td data-label="Nome"><span class="cel"><b>' + esc(x.nome) + '</b>' + (eu ? ' <span class="selo selo--cont">Você</span>' : '') + '<small>' + esc(x.email) + '</small></span></td>' +
          '<td data-label="Usuário">' + esc(x.usuario) + '</td>' +
          '<td data-label="Empresa"><span class="cel">' + (esc(x.empresa) || '—') + '<small>' + esc(x.telefone) + '</small></span></td>' +
          '<td data-label="Perfil">' + (x.perfil === 'admin' ? 'Administrador' : 'Funcionário') + '</td>' +
          '<td data-label="Situação"><span class="selo ' + (x.ativo ? 'selo--ok' : 'selo--off') + '">' + (x.ativo ? 'Ativo' : 'Desativado') + '</span></td>' +
          '<td class="acoes-td"><div class="acoes">' + ac + '</div></td></tr>';
      }).join('');
    }
    busca.addEventListener('input', lista);
    tb.addEventListener('click', function (e) {
      var b = e.target.closest('button[data-acao]'); if (!b) return;
      var todos = usuarios(), x = todos.filter(function (y) { return y.id === b.getAttribute('data-id'); })[0]; if (!x) return;
      var a = b.getAttribute('data-acao');
      if (a === 'ativar' || a === 'desativar') {
        x.ativo = a === 'ativar'; gravar('usuarios', todos);
        registra(x.ativo ? 'usuario_ativado' : 'usuario_desativado', x.nome + ' (' + x.usuario + ')'); lista();
      } else if (a === 'senha') {
        dialogo({ titulo: 'Nova senha', texto: 'Defina uma nova senha para ' + x.nome + '.', senha: true, botao: 'Salvar senha' }, function (v) {
          x.sal = novoId() + novoId(); x.hash = sha256(x.sal + ':' + utf8(v)); gravar('usuarios', todos);
          registra('senha_redefinida', x.nome + ' (' + x.usuario + ')');
          mostra(ok, 'Senha de ' + x.nome + ' alterada.');
        });
      } else if (a === 'excluir') {
        dialogo({ titulo: 'Excluir usuário', texto: 'Excluir ' + x.nome + ' (' + x.usuario + ')? O histórico de movimentações dele continua guardado.', botao: 'Excluir', perigo: true }, function () {
          gravar('usuarios', todos.filter(function (y) { return y.id !== x.id; }));
          registra('usuario_excluido', x.nome + ' (' + x.usuario + ')'); lista();
        });
      }
    });

    // novo usuário
    var cx = $('#cx-usu'), btnNovo = $('#usu-novo');
    function abreForm() { cx.hidden = false; ok.hidden = true; er.hidden = true; btnNovo.setAttribute('aria-expanded', 'true'); form.nome.focus(); cx.scrollIntoView({ block: 'nearest' }); }
    function fechaForm() { cx.hidden = true; form.reset(); btnNovo.setAttribute('aria-expanded', 'false'); btnNovo.focus(); }
    btnNovo.addEventListener('click', abreForm);
    $('#u-cancelar').addEventListener('click', fechaForm);
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      $$('input,select', form).forEach(function (i) { i.removeAttribute('aria-invalid'); });
      var v = { nome: form.nome.value.trim(), email: form.email.value.trim(), empresa: form.empresa.value.trim(), telefone: form.telefone.value.trim(), usuario: form.usuario.value.trim().toLowerCase(), senha: form.senha.value, perfil: form.perfil.value };
      var msg = null, campo = null;
      if (v.nome.length < 3) { msg = 'Digite o nome completo.'; campo = form.nome; }
      else if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(v.email)) { msg = 'Digite um e-mail válido.'; campo = form.email; }
      else if (!/^[a-z0-9._-]{3,}$/.test(v.usuario)) { msg = 'O usuário precisa ter 3 ou mais caracteres, só letras, números, ponto, traço ou sublinhado.'; campo = form.usuario; }
      else if (usuarios().some(function (x) { return x.usuario === v.usuario; })) { msg = 'Já existe um usuário com esse nome de acesso.'; campo = form.usuario; }
      else if (v.senha.length < 6) { msg = 'A senha precisa ter pelo menos 6 caracteres.'; campo = form.senha; }
      if (msg) { mostra(er, msg); campo.setAttribute('aria-invalid', 'true'); campo.focus(); return; }
      var lst = usuarios(); lst.push(mkUser(v)); gravar('usuarios', lst);
      registra('usuario_criado', v.nome + ' (' + v.usuario + '), perfil ' + (v.perfil === 'admin' ? 'administrador' : 'funcionário'));
      form.reset(); cx.hidden = true; btnNovo.setAttribute('aria-expanded', 'false');
      busca.value = ''; lista();
      mostra(ok, 'Usuário ' + v.nome + ' cadastrado. Ele já pode entrar com o usuário ' + v.usuario + '.');
      btnNovo.focus();
    });

    // registro de atividades
    var tl = $('#t-log tbody'), lb = $('#log-busca'), lf = $('#log-filtro');
    function log() {
      var q = norm(lb.value), f = lf.value;
      var vis = ler('log', []).filter(function (r) {
        if (f && r.acao !== f) return false;
        return !q || norm([r.nome, r.usuario, ACAO[r.acao], r.detalhe].join(' ')).indexOf(q) > -1;
      });
      $('#log-cont').textContent = vis.length + (vis.length === 1 ? ' registro' : ' registros') + (vis.length > 300 ? ' (mostrando os 300 mais recentes)' : '');
      if (!vis.length) { tl.innerHTML = '<tr><td colspan="4" class="vazio">Nenhum registro.</td></tr>'; return; }
      tl.innerHTML = vis.slice(0, 300).map(function (r) {
        return '<tr><td data-label="Quando">' + dataHora(r.quando) + '</td>' +
          '<td data-label="Quem"><span class="cel">' + (r.nome ? esc(r.nome) + '<small>' + esc(r.usuario) + '</small>' : (esc(r.usuario) || '—')) + '</span></td>' +
          '<td data-label="O que fez">' + esc(ACAO[r.acao] || r.acao) + '</td>' +
          '<td data-label="Detalhe">' + (esc(r.detalhe) || '—') + '</td></tr>';
      }).join('');
    }
    lf.innerHTML = '<option value="">Todas as ações</option>' + Object.keys(ACAO).map(function (k) { return '<option value="' + k + '">' + esc(ACAO[k]) + '</option>'; }).join('');
    lb.addEventListener('input', log); lf.addEventListener('change', log);
    abas($('#abas-usu'), function (i) { if (i === 1) log(); else lista(); });
    lista();
  }

  /* =====================================================
     PÁGINA: ESTOQUE
     ===================================================== */
  function paginaEstoque() {
    var u = exige(false); if (!u) return;
    topo(u); registra('tela', 'Abriu a tela: ' + TELA.estoque);
    var admin = u.perfil === 'admin';
    var ativaAba = abas($('#abas-est'), function (i) { if (i === 2) desenhaContagem(); if (i === 3) desenhaHist(); });
    var ST = { ok: 'Em dia', baixo: 'Abaixo do mínimo', zero: 'Zerado' };
    function status(it) { return it.saldo <= 0 ? 'zero' : it.saldo < it.minimo ? 'baixo' : 'ok'; }
    function achar(id) { return itens().filter(function (i) { return i.id === id; })[0]; }

    function registraMov(it, tipo, qtd, obs, delta) {
      var lst = itens(), alvo = lst.filter(function (i) { return i.id === it.id; })[0];
      alvo.saldo = arred(alvo.saldo + delta); gravar('itens', lst);
      var m = movs();
      m.unshift({ id: novoId(), quando: agora(), tipo: tipo, itemId: alvo.id, codigo: alvo.codigo, nome: alvo.nome, un: alvo.unidade, qtd: qtd, saldoApos: alvo.saldo, usuario: u.nome, obs: obs || '' });
      if (m.length > 3000) m.length = 3000;
      gravar('movs', m);
      registra(tipo, alvo.codigo + ' ' + alvo.nome + ': ' + (qtd > 0 && tipo === 'contagem' ? '+' : '') + fmt(qtd) + ' ' + alvo.unidade + (obs ? ' (' + obs + ')' : ''));
      return alvo;
    }

    /* resumo e alerta */
    function resumo() {
      var its = itens(), baixos = its.filter(function (i) { return status(i) !== 'ok'; });
      var hoje = new Date().toDateString();
      $('#res-itens').textContent = its.length;
      $('#res-baixo').textContent = baixos.length;
      $('#res-mov').textContent = movs().filter(function (m) { return new Date(m.quando).toDateString() === hoje; }).length;
      $('#res-baixo').parentNode.classList.toggle('res--baixo', baixos.length > 0);
      var al = $('#alerta');
      if (!baixos.length) { al.hidden = true; return; }
      al.hidden = false;
      al.innerHTML = '<b>Atenção:</b> ' + baixos.length + (baixos.length === 1 ? ' item está' : ' itens estão') + ' abaixo do estoque mínimo: ' +
        baixos.slice(0, 5).map(function (i) { return esc(i.codigo) + ' ' + esc(i.nome); }).join('; ') + (baixos.length > 5 ? '; e mais ' + (baixos.length - 5) + '.' : '.') +
        ' <a href="#" id="ver-baixos">Ver na tabela</a>';
    }
    d.addEventListener('click', function (e) {
      if (e.target.id === 'ver-baixos') { e.preventDefault(); ativaAba(0); $('#it-filtro').value = 'baixo'; tabelaItens(); $('#it-filtro').focus(); }
    });

    /* ----- produtos ----- */
    var tbI = $('#t-itens tbody'), fI = $('#it-busca'), fS = $('#it-filtro');
    function tabelaItens() {
      var q = norm(fI.value), st = fS.value;
      var vis = itens().filter(function (i) {
        if (st === 'baixo' && status(i) === 'ok') return false;
        return !q || norm([i.codigo, i.nome, i.categoria].join(' ')).indexOf(q) > -1;
      });
      $('#it-cont').textContent = vis.length + (vis.length === 1 ? ' item' : ' itens');
      if (!vis.length) { tbI.innerHTML = '<tr><td colspan="7" class="vazio">Nenhum item encontrado.</td></tr>'; return; }
      tbI.innerHTML = vis.map(function (i) {
        var s = status(i);
        return '<tr><td data-label="Código"><b>' + esc(i.codigo) + '</b></td>' +
          '<td data-label="Produto"><span class="cel">' + esc(i.nome) + '<small>' + esc(i.categoria) + '</small></span></td>' +
          '<td data-label="Saldo" class="n"><b>' + fmt(i.saldo) + '</b> ' + esc(i.unidade) + '</td>' +
          '<td data-label="Mínimo" class="n">' + fmt(i.minimo) + ' ' + esc(i.unidade) + '</td>' +
          '<td data-label="Situação"><span class="selo selo--' + s + '">' + ST[s] + '</span></td>' +
          '<td class="acoes-td"><div class="acoes">' +
          '<button class="botao botao--vazio botao--p" type="button" data-acao="ent" data-id="' + i.id + '" aria-label="Entrada de ' + esc(i.nome) + '">Entrada</button>' +
          '<button class="botao botao--vazio botao--p" type="button" data-acao="sai" data-id="' + i.id + '" aria-label="Saída de ' + esc(i.nome) + '">Saída</button>' +
          '<button class="botao botao--vazio botao--p" type="button" data-acao="edit" data-id="' + i.id + '" aria-label="Editar ' + esc(i.nome) + '">Editar</button>' +
          (admin ? '<button class="botao botao--perigo botao--p" type="button" data-acao="del" data-id="' + i.id + '" aria-label="Excluir ' + esc(i.nome) + '">Excluir</button>' : '') +
          '</div></td></tr>';
      }).join('');
    }
    fI.addEventListener('input', tabelaItens); fS.addEventListener('change', tabelaItens);
    tbI.addEventListener('click', function (e) {
      var b = e.target.closest('button[data-acao]'); if (!b) return;
      var it = achar(b.getAttribute('data-id')); if (!it) return;
      var a = b.getAttribute('data-acao');
      if (a === 'ent' || a === 'sai') {
        ativaAba(1); fM.tipo.value = a === 'ent' ? 'entrada' : 'saida';
        fM.item.value = it.id; mudaTipo(); infoSaldo(); fM.qtd.focus();
      } else if (a === 'edit') { abreItem(it); }
      else if (a === 'del') {
        dialogo({ titulo: 'Excluir item', texto: 'Excluir ' + it.codigo + ' ' + it.nome + '? O histórico dele continua guardado.', botao: 'Excluir', perigo: true }, function () {
          gravar('itens', itens().filter(function (x) { return x.id !== it.id; }));
          registra('item_excluido', it.codigo + ' ' + it.nome);
          tudo();
        });
      }
    });

    var fIt = $('#f-item'), cxIt = $('#cx-item'), erIt = $('#item-erro'), editId = null;
    function abreItem(it) {
      editId = it ? it.id : null;
      fIt.reset(); erIt.hidden = true;
      $('#item-titulo').textContent = it ? 'Editar item' : 'Cadastrar novo item';
      $('#item-salvar').textContent = it ? 'Salvar alterações' : 'Cadastrar item';
      fIt.saldo.disabled = !!it;
      $('#item-saldo-rot').textContent = it ? 'Saldo atual (altere por entrada, saída ou contagem)' : 'Saldo inicial';
      if (it) { fIt.codigo.value = it.codigo; fIt.nome.value = it.nome; fIt.categoria.value = it.categoria; fIt.unidade.value = it.unidade; fIt.minimo.value = String(it.minimo).replace('.', ','); fIt.saldo.value = String(it.saldo).replace('.', ','); }
      cxIt.hidden = false; $('#it-novo').setAttribute('aria-expanded', 'true'); fIt.codigo.focus();
      cxIt.scrollIntoView({ block: 'nearest' });
    }
    function fechaItem() { cxIt.hidden = true; editId = null; $('#it-novo').setAttribute('aria-expanded', 'false'); $('#it-novo').focus(); }
    $('#it-novo').addEventListener('click', function () { abreItem(null); });
    $('#item-cancelar').addEventListener('click', fechaItem);
    fIt.addEventListener('submit', function (e) {
      e.preventDefault();
      $$('input,select', fIt).forEach(function (i) { i.removeAttribute('aria-invalid'); });
      var cod = fIt.codigo.value.trim().toUpperCase(), nome = fIt.nome.value.trim(), min = num(fIt.minimo.value || '0'), sal = editId ? 0 : num(fIt.saldo.value || '0');
      var msg = null, campo = null;
      if (!cod) { msg = 'Digite o código do item.'; campo = fIt.codigo; }
      else if (itens().some(function (i) { return i.codigo.toUpperCase() === cod && i.id !== editId; })) { msg = 'Já existe um item com esse código.'; campo = fIt.codigo; }
      else if (nome.length < 3) { msg = 'Digite o nome do item.'; campo = fIt.nome; }
      else if (isNaN(min)) { msg = 'Estoque mínimo: digite só números (ex.: 10 ou 2,5).'; campo = fIt.minimo; }
      else if (isNaN(sal)) { msg = 'Saldo inicial: digite só números (ex.: 10 ou 2,5).'; campo = fIt.saldo; }
      if (msg) { mostra(erIt, msg); campo.setAttribute('aria-invalid', 'true'); campo.focus(); return; }
      var lst = itens();
      if (editId) {
        var al = lst.filter(function (i) { return i.id === editId; })[0];
        al.codigo = cod; al.nome = nome; al.categoria = fIt.categoria.value; al.unidade = fIt.unidade.value; al.minimo = min;
        gravar('itens', lst); registra('item_editado', cod + ' ' + nome);
      } else {
        var novo = { id: novoId(), codigo: cod, nome: nome, categoria: fIt.categoria.value, unidade: fIt.unidade.value, minimo: min, saldo: 0 };
        lst.unshift(novo); gravar('itens', lst);
        registra('item_criado', cod + ' ' + nome);
        if (sal > 0) registraMov(novo, 'entrada', sal, 'Saldo inicial', sal);
      }
      fechaItem(); fI.value = ''; fS.value = ''; tudo();
    });

    /* ----- movimentar ----- */
    var fM = $('#f-mov'), erM = $('#mov-erro'), okM = $('#mov-ok');
    function selectItens() {
      var cur = fM.item.value;
      fM.item.innerHTML = '<option value="">Selecione o produto</option>' + itens().slice().sort(function (a, b) { return a.codigo.localeCompare(b.codigo); }).map(function (i) {
        return '<option value="' + i.id + '">' + esc(i.codigo) + ' · ' + esc(i.nome) + '</option>';
      }).join('');
      if (cur && achar(cur)) fM.item.value = cur;
    }
    function mudaTipo() {
      var ent = fM.tipo.value === 'entrada';
      $('#mov-obs-rot').textContent = ent ? 'Fornecedor ou nota fiscal (opcional)' : 'Para qual máquina ou pedido?';
      fM.obs.placeholder = ent ? 'Ex.: NF 1234' : 'Ex.: Pedido 0350 ou Montagem lote 15';
      $('#mov-btn').textContent = ent ? 'Registrar entrada' : 'Registrar saída';
    }
    function infoSaldo() {
      var it = achar(fM.item.value), el = $('#mov-info');
      el.innerHTML = it ? 'Saldo atual: <b>' + fmt(it.saldo) + ' ' + esc(it.unidade) + '</b> · Mínimo: ' + fmt(it.minimo) + ' ' + esc(it.unidade) : 'Escolha o produto para ver o saldo.';
    }
    $$('input[name="tipo"]', fM).forEach(function (r) { r.addEventListener('change', function () { mudaTipo(); erM.hidden = true; }); });
    fM.item.addEventListener('change', function () { infoSaldo(); erM.hidden = true; });
    fM.addEventListener('submit', function (e) {
      e.preventDefault();
      okM.hidden = true; $$('input,select', fM).forEach(function (i) { i.removeAttribute('aria-invalid'); });
      var it = achar(fM.item.value), tipo = fM.tipo.value, q = num(fM.qtd.value), obs = fM.obs.value.trim();
      var msg = null, campo = null;
      if (!it) { msg = 'Escolha o produto.'; campo = fM.item; }
      else if (isNaN(q) || q <= 0) { msg = 'Digite a quantidade com números maiores que zero (ex.: 10 ou 2,5).'; campo = fM.qtd; }
      else if (tipo === 'saida' && q > it.saldo) { msg = 'Saldo insuficiente: há ' + fmt(it.saldo) + ' ' + it.unidade + ' em estoque.'; campo = fM.qtd; }
      else if (tipo === 'saida' && obs.length < 2) { msg = 'Informe para qual máquina ou pedido o item vai.'; campo = fM.obs; }
      if (msg) { mostra(erM, msg); campo.setAttribute('aria-invalid', 'true'); campo.focus(); return; }
      erM.hidden = true;
      var al = registraMov(it, tipo, q, obs, tipo === 'entrada' ? q : -q);
      mostra(okM, (tipo === 'entrada' ? 'Entrada' : 'Saída') + ' registrada por ' + u.nome + ': ' + fmt(q) + ' ' + al.unidade + ' de ' + al.codigo + '. Novo saldo: ' + fmt(al.saldo) + ' ' + al.unidade + '.' + (al.saldo < al.minimo ? ' Atenção: abaixo do mínimo.' : ''));
      fM.qtd.value = ''; fM.obs.value = ''; infoSaldo(); tudo(true); fM.qtd.focus();
    });
    function recentes() {
      var m = movs().slice(0, 6), ul = $('#recentes');
      if (!m.length) { ul.innerHTML = '<li class="vazio">Nenhuma movimentação ainda.</li>'; return; }
      ul.innerHTML = m.map(function (x) {
        return '<li><span class="selo selo--' + (x.tipo === 'entrada' ? 'ent' : x.tipo === 'saida' ? 'sai' : 'cont') + '">' + (x.tipo === 'entrada' ? 'Entrada' : x.tipo === 'saida' ? 'Saída' : 'Contagem') + '</span>' +
          '<span><span class="q">' + (x.tipo === 'contagem' && x.qtd > 0 ? '+' : '') + fmt(x.qtd) + ' ' + esc(x.un) + '</span> · ' + esc(x.codigo) + ' ' + esc(x.nome) + '</span>' +
          '<small>' + dataHora(x.quando) + ' · ' + esc(x.usuario) + (x.obs ? ' · ' + esc(x.obs) : '') + '</small></li>';
      }).join('');
    }

    /* ----- contagem ----- */
    var tbC = $('#t-cont tbody');
    function desenhaContagem() {
      var guard = {}; $$('input[data-id]', tbC).forEach(function (i) { guard[i.getAttribute('data-id')] = i.value; });
      tbC.innerHTML = itens().map(function (i) {
        return '<tr data-id="' + i.id + '"><td data-label="Código"><b>' + esc(i.codigo) + '</b></td><td data-label="Produto">' + esc(i.nome) + '</td>' +
          '<td data-label="No sistema" class="n">' + fmt(i.saldo) + ' ' + esc(i.unidade) + '</td>' +
          '<td data-label="Contado"><input data-id="' + i.id + '" inputmode="decimal" autocomplete="off" aria-label="Quantidade contada de ' + esc(i.nome) + '" value="' + esc(guard[i.id] || '') + '"></td>' +
          '<td data-label="Diferença" class="n"><span class="dif" data-dif></span></td>' +
          '<td class="acoes-td"><div class="acoes"><button class="botao botao--vazio botao--p" type="button" data-ajusta="' + i.id + '" disabled>Ajustar</button></div></td></tr>';
      }).join('');
      $$('tr', tbC).forEach(atualizaDif);
    }
    function atualizaDif(tr) {
      var it = achar(tr.getAttribute('data-id')), inp = $('input', tr), el = $('[data-dif]', tr), b = $('[data-ajusta]', tr);
      var v = inp.value.trim(), n = v === '' ? NaN : num(v);
      el.className = 'dif';
      if (v === '') { el.textContent = ''; b.disabled = true; inp.removeAttribute('aria-invalid'); return; }
      if (isNaN(n)) { el.textContent = 'Número inválido'; b.disabled = true; inp.setAttribute('aria-invalid', 'true'); return; }
      inp.removeAttribute('aria-invalid');
      var df = arred(n - it.saldo);
      if (df === 0) { el.textContent = 'Confere'; b.disabled = true; }
      else { el.textContent = (df > 0 ? '+' : '') + fmt(df) + ' ' + it.unidade; el.classList.add(df > 0 ? 'dif--mais' : 'dif--menos'); b.disabled = false; }
    }
    tbC.addEventListener('input', function (e) { var tr = e.target.closest('tr'); if (tr) atualizaDif(tr); });
    function aplica(tr) {
      var it = achar(tr.getAttribute('data-id')), n = num($('input', tr).value.trim());
      if (!it || isNaN(n)) return false;
      var df = arred(n - it.saldo); if (df === 0) return false;
      registraMov(it, 'contagem', df, 'Ajuste de contagem (contado ' + fmt(n) + ')', df);
      $('input', tr).value = ''; return true;
    }
    tbC.addEventListener('click', function (e) {
      var b = e.target.closest('[data-ajusta]'); if (!b) return;
      var tr = b.closest('tr'), it = achar(tr.getAttribute('data-id')), n = num($('input', tr).value.trim());
      dialogo({ titulo: 'Ajustar saldo', texto: it.codigo + ' ' + it.nome + ': o saldo vai de ' + fmt(it.saldo) + ' para ' + fmt(n) + ' ' + it.unidade + '. Isso fica registrado no histórico.', botao: 'Ajustar saldo' }, function () {
        aplica(tr); tudo(true); desenhaContagem();
      });
    });
    $('#cont-todos').addEventListener('click', function () {
      var trs = $$('tr', tbC).filter(function (tr) { return !$('[data-ajusta]', tr).disabled; });
      if (!trs.length) { mostra($('#cont-msg'), 'Digite as quantidades contadas. Só aparecem para ajuste as que diferem do sistema.'); return; }
      dialogo({ titulo: 'Aplicar todos os ajustes', texto: 'Ajustar o saldo de ' + trs.length + (trs.length === 1 ? ' item' : ' itens') + ' conforme a contagem? Tudo fica registrado no histórico.', botao: 'Aplicar ajustes' }, function () {
        var n = 0; trs.forEach(function (tr) { if (aplica(tr)) n++; });
        tudo(true); desenhaContagem(); mostra($('#cont-msg'), n + (n === 1 ? ' ajuste aplicado.' : ' ajustes aplicados.'));
      });
    });

    /* ----- histórico ----- */
    var tbH = $('#t-hist tbody'), hB = $('#h-busca'), hT = $('#h-tipo');
    function filtraHist() {
      var q = norm(hB.value), t = hT.value;
      return movs().filter(function (m) { return (!t || m.tipo === t) && (!q || norm([m.codigo, m.nome, m.usuario, m.obs].join(' ')).indexOf(q) > -1); });
    }
    function desenhaHist() {
      var vis = filtraHist();
      $('#h-cont').textContent = vis.length + (vis.length === 1 ? ' movimentação' : ' movimentações') + (vis.length > 200 ? ' (mostrando as 200 mais recentes)' : '');
      if (!vis.length) { tbH.innerHTML = '<tr><td colspan="7" class="vazio">Nenhuma movimentação encontrada.</td></tr>'; return; }
      tbH.innerHTML = vis.slice(0, 200).map(function (m) {
        var c = m.tipo === 'entrada' ? 'ent' : m.tipo === 'saida' ? 'sai' : 'cont';
        return '<tr><td data-label="Quando">' + dataHora(m.quando) + '</td>' +
          '<td data-label="Tipo"><span class="selo selo--' + c + '">' + (m.tipo === 'entrada' ? 'Entrada' : m.tipo === 'saida' ? 'Saída' : 'Contagem') + '</span></td>' +
          '<td data-label="Produto"><b>' + esc(m.codigo) + '</b> ' + esc(m.nome) + '</td>' +
          '<td data-label="Quantidade" class="n">' + (m.tipo === 'contagem' && m.qtd > 0 ? '+' : '') + fmt(m.qtd) + ' ' + esc(m.un) + '</td>' +
          '<td data-label="Saldo após" class="n">' + fmt(m.saldoApos) + ' ' + esc(m.un) + '</td>' +
          '<td data-label="Quem">' + esc(m.usuario) + '</td>' +
          '<td data-label="Destino ou obs.">' + (esc(m.obs) || '—') + '</td></tr>';
      }).join('');
    }
    hB.addEventListener('input', desenhaHist); hT.addEventListener('change', desenhaHist);
    $('#h-csv').addEventListener('click', function () {
      var l = [['Data e hora', 'Tipo', 'Código', 'Produto', 'Quantidade', 'Unidade', 'Saldo após', 'Quem', 'Destino ou observação']];
      filtraHist().forEach(function (m) { l.push([dataHora(m.quando), m.tipo, m.codigo, m.nome, m.qtd, m.un, m.saldoApos, m.usuario, m.obs]); });
      csv(l, 'historico-estoque-k2j.csv');
    });

    function tudo(manterMsg) {
      resumo(); selectItens(); infoSaldo(); tabelaItens(); recentes();
      if (!$('#p-cont').hidden) desenhaContagem();
      if (!$('#p-hist').hidden) desenhaHist();
    }
    mudaTipo(); tudo();
  }

  /* ---------- início ---------- */
  var pg = d.body.getAttribute('data-pagina');
  try {
    if (pg === 'login') paginaLogin();
    else if (pg === 'painel') paginaPainel();
    else if (pg === 'usuarios') paginaUsuarios();
    else if (pg === 'estoque') paginaEstoque();
  } catch (e) {
    var av = $('#erro-geral');
    if (av) { av.hidden = false; av.textContent = 'Não foi possível carregar esta tela. Abra o site pelo Chrome ou pelo Edge. (' + e.message + ')'; }
    if (window.console) console.error(e);
  }
})();
