(function () {
  'use strict';
  // Geradores de relatório (CSV, Excel .xlsx e PDF) sem bibliotecas externas: funcionam offline.
  // Entrada: dados = { titulo, filtro, geradoEm, geradoPor, itens: [[cod,nome,cat,un,saldo,min,situacao]...], movs: [[quando,tipo,produto,qtd,un,saldoApos,quem,obs]...] | null }
  var CAB_ITENS = ['Código', 'Produto', 'Categoria', 'Un', 'Saldo', 'Mínimo', 'Situação'];
  var CAB_MOVS = ['Quando', 'Tipo', 'Produto', 'Quantidade', 'Un', 'Saldo após', 'Quem', 'Destino ou observação'];
  var enc = new TextEncoder();

  function baixar(blob, nome) {
    var a = document.createElement('a');
    a.href = URL.createObjectURL(blob); a.download = nome;
    document.body.appendChild(a); a.click();
    setTimeout(function () { URL.revokeObjectURL(a.href); a.remove(); }, 800);
  }
  function fmtN(n) { return Number(n).toLocaleString('pt-BR', { maximumFractionDigits: 3 }); }

  /* ---------------- CSV ---------------- */
  function csv(dados) {
    function cel(v) { v = (typeof v === 'number') ? String(v).replace('.', ',') : String(v == null ? '' : v); if (/^[=+\-@]/.test(v) && isNaN(Number(v.replace(',', '.')))) v = "'" + v; return '"' + v.replace(/"/g, '""') + '"'; }
    function lin(a) { return a.map(cel).join(';'); }
    var out = [lin(CAB_ITENS)].concat(dados.itens.map(lin));
    if (dados.movs) { out.push(''); out.push(lin(['Histórico de movimentações'])); out.push(lin(CAB_MOVS)); dados.movs.forEach(function (m) { out.push(lin(m)); }); }
    return new Blob(['﻿' + out.join('\r\n')], { type: 'text/csv;charset=utf-8' });
  }

  /* ---------------- XLSX (zip sem compressão) ---------------- */
  var CT = (function () { var t = [], c, n, k; for (n = 0; n < 256; n++) { c = n; for (k = 0; k < 8; k++) c = c & 1 ? 0xEDB88320 ^ (c >>> 1) : c >>> 1; t[n] = c >>> 0; } return t; })();
  function crc32(b) { var c = 0xFFFFFFFF; for (var i = 0; i < b.length; i++) c = CT[(c ^ b[i]) & 255] ^ (c >>> 8); return (c ^ 0xFFFFFFFF) >>> 0; }
  function zip(files, tipo) {
    var chunks = [], central = [], offset = 0, now = new Date();
    var dt = ((now.getHours() << 11) | (now.getMinutes() << 5) | (now.getSeconds() >> 1)) & 0xFFFF;
    var dd = (((now.getFullYear() - 1980) << 9) | ((now.getMonth() + 1) << 5) | now.getDate()) & 0xFFFF;
    files.forEach(function (f) {
      var nb = enc.encode(f.name), data = enc.encode(f.text), crc = crc32(data), n = data.length;
      var lh = new DataView(new ArrayBuffer(30));
      lh.setUint32(0, 0x04034b50, true); lh.setUint16(4, 20, true); lh.setUint16(6, 0x0800, true); lh.setUint16(8, 0, true);
      lh.setUint16(10, dt, true); lh.setUint16(12, dd, true); lh.setUint32(14, crc, true); lh.setUint32(18, n, true); lh.setUint32(22, n, true);
      lh.setUint16(26, nb.length, true); lh.setUint16(28, 0, true);
      chunks.push(new Uint8Array(lh.buffer), nb, data);
      var ch = new DataView(new ArrayBuffer(46));
      ch.setUint32(0, 0x02014b50, true); ch.setUint16(4, 20, true); ch.setUint16(6, 20, true); ch.setUint16(8, 0x0800, true); ch.setUint16(10, 0, true);
      ch.setUint16(12, dt, true); ch.setUint16(14, dd, true); ch.setUint32(16, crc, true); ch.setUint32(20, n, true); ch.setUint32(24, n, true);
      ch.setUint16(28, nb.length, true); ch.setUint32(42, offset, true);
      central.push(new Uint8Array(ch.buffer), nb);
      offset += 30 + nb.length + n;
    });
    var cs = 0; central.forEach(function (c) { cs += c.length; });
    var end = new DataView(new ArrayBuffer(22));
    end.setUint32(0, 0x06054b50, true); end.setUint16(8, files.length, true); end.setUint16(10, files.length, true); end.setUint32(12, cs, true); end.setUint32(16, offset, true);
    return new Blob(chunks.concat(central, [new Uint8Array(end.buffer)]), { type: tipo });
  }
  function xe(s) { return String(s).replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F]/g, '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;'); }
  function colL(i) { var s = '', n = i + 1; while (n > 0) { var m = (n - 1) % 26; s = String.fromCharCode(65 + m) + s; n = Math.floor((n - 1) / 26); } return s; }
  function planilha(cab, linhas, larg, numCols) {
    var x = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">';
    x += '<sheetViews><sheetView workbookViewId="0"><pane ySplit="1" topLeftCell="A2" activePane="bottomLeft" state="frozen"/></sheetView></sheetViews>';
    x += '<cols>' + larg.map(function (w, i) { return '<col min="' + (i + 1) + '" max="' + (i + 1) + '" width="' + w + '" customWidth="1"/>'; }).join('') + '</cols><sheetData>';
    x += '<row r="1" ht="22" customHeight="1">' + cab.map(function (h, i) { return '<c r="' + colL(i) + '1" s="1" t="inlineStr"><is><t>' + xe(h) + '</t></is></c>'; }).join('') + '</row>';
    linhas.forEach(function (l, r) {
      x += '<row r="' + (r + 2) + '">' + l.map(function (v, i) {
        var ref = colL(i) + (r + 2);
        if (typeof v === 'number' && isFinite(v)) return '<c r="' + ref + '" s="2"><v>' + v + '</v></c>';
        return '<c r="' + ref + '" t="inlineStr"><is><t xml:space="preserve">' + xe(v == null ? '' : v) + '</t></is></c>';
      }).join('') + '</row>';
    });
    x += '</sheetData><autoFilter ref="A1:' + colL(cab.length - 1) + (linhas.length + 1) + '"/></worksheet>';
    return x;
  }
  function xlsx(dados) {
    var abas = [{ nome: 'Estoque', xml: planilha(CAB_ITENS, dados.itens, [12, 44, 18, 8, 12, 12, 20]) }];
    if (dados.movs) abas.push({ nome: 'Movimentações', xml: planilha(CAB_MOVS, dados.movs, [18, 12, 44, 13, 8, 13, 24, 40]) });
    var files = [
      { name: '[Content_Types].xml', text: '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>' + abas.map(function (a, i) { return '<Override PartName="/xl/worksheets/sheet' + (i + 1) + '.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>'; }).join('') + '</Types>' },
      { name: '_rels/.rels', text: '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>' },
      { name: 'xl/workbook.xml', text: '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets>' + abas.map(function (a, i) { return '<sheet name="' + xe(a.nome) + '" sheetId="' + (i + 1) + '" r:id="rId' + (i + 1) + '"/>'; }).join('') + '</sheets></workbook>' },
      { name: 'xl/_rels/workbook.xml.rels', text: '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">' + abas.map(function (a, i) { return '<Relationship Id="rId' + (i + 1) + '" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet' + (i + 1) + '.xml"/>'; }).join('') + '<Relationship Id="rId' + (abas.length + 1) + '" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/></Relationships>' },
      { name: 'xl/styles.xml', text: '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><numFmts count="1"><numFmt numFmtId="164" formatCode="#,##0.###"/></numFmts><fonts count="2"><font><sz val="11"/><name val="Calibri"/></font><font><b/><sz val="11"/><color rgb="FFFFFFFF"/><name val="Calibri"/></font></fonts><fills count="3"><fill><patternFill patternType="none"/></fill><fill><patternFill patternType="gray125"/></fill><fill><patternFill patternType="solid"><fgColor rgb="FF0A1B33"/><bgColor indexed="64"/></patternFill></fill></fills><borders count="1"><border><left/><right/><top/><bottom/><diagonal/></border></borders><cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs><cellXfs count="3"><xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/><xf numFmtId="0" fontId="1" fillId="2" borderId="0" xfId="0" applyFont="1" applyFill="1" applyAlignment="1"><alignment vertical="center"/></xf><xf numFmtId="164" fontId="0" fillId="0" borderId="0" xfId="0" applyNumberFormat="1"/></cellXfs><cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles></styleSheet>' }
    ];
    abas.forEach(function (a, i) { files.push({ name: 'xl/worksheets/sheet' + (i + 1) + '.xml', text: a.xml }); });
    return zip(files, 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
  }

  /* ---------------- PDF (Helvetica, A4 paisagem) ---------------- */
  var W = 842, H = 595, M = 34, BASE = 46;
  var NAVY = '0A1B33', LARANJA = 'F2A33A', CINZA = '3C4F6E';
  function cor(h) { return [0, 2, 4].map(function (i) { return (parseInt(h.substr(i, 2), 16) / 255).toFixed(3); }).join(' '); }
  var ESP = { '—': 0x97, '–': 0x96, '…': 0x85, '“': 0x93, '”': 0x94, '‘': 0x91, '’': 0x92, '•': 0x95 };
  function pstr(s) {
    var o = '(';
    String(s).split('').forEach(function (ch) {
      var c = ch.charCodeAt(0);
      if (ESP[ch]) c = ESP[ch]; else if (!(c >= 32 && c < 127) && !(c >= 160 && c <= 255)) c = 63;
      if (c === 40 || c === 41 || c === 92) o += '\\';
      o += String.fromCharCode(c);
    });
    return o + ')';
  }
  function pdf(dados) {
    var cv = d_canvas();
    function tw(s, sz, b) { cv.font = (b ? 'bold ' : '') + sz + 'px Arial, Helvetica, sans-serif'; return cv.measureText(String(s)).width; }
    function corta(s, sz, b, max) { s = String(s); if (tw(s, sz, b) <= max) return s; while (s.length > 1 && tw(s + '...', sz, b) > max) s = s.slice(0, -1); return s + '...'; }
    var pages = [], cur, y, logo = window.K2J_LOGO_PDF;
    function rect(x, yy, w, h, c) { cur.push(cor(c) + ' rg ' + x.toFixed(2) + ' ' + yy.toFixed(2) + ' ' + w.toFixed(2) + ' ' + h.toFixed(2) + ' re f'); }
    function txt(x, yy, s, sz, b, c) { cur.push('BT /' + (b ? 'F2' : 'F1') + ' ' + sz + ' Tf ' + cor(c) + ' rg ' + x.toFixed(2) + ' ' + yy.toFixed(2) + ' Td ' + pstr(s) + ' Tj ET'); }
    function nova(prim) {
      cur = []; pages.push(cur);
      if (prim) {
        rect(0, H - 84, W, 84, NAVY); rect(0, H - 87, W, 3, LARANJA);
        if (logo) { var lh = 60, lw = lh * logo.w / logo.h; cur.push('q ' + lw.toFixed(2) + ' 0 0 ' + lh + ' ' + M + ' ' + (H - 84 + 12) + ' cm /Im1 Do Q'); txt(M + lw + 20, H - 44, dados.titulo, 20, true, 'FFFFFF'); txt(M + lw + 20, H - 64, 'K2J Homogenizer · Almoxarifado', 10.5, false, LARANJA); }
        else { txt(M, H - 44, dados.titulo, 20, true, 'FFFFFF'); }
        y = H - 87 - 26;
      } else {
        txt(M, H - 28, 'K2J Homogenizer · ' + dados.titulo, 9, false, CINZA);
        rect(M, H - 34, W - 2 * M, 0.8, 'C9D3E4'); y = H - 56;
      }
    }
    function tabela(cols, linhas, corCel) {
      var RH = 21, x0 = M;
      function cab() {
        rect(x0, y - RH + 6, W - 2 * M, RH, NAVY);
        var x = x0;
        cols.forEach(function (c) { var s = corta(c.t, 9, true, c.w - 12); txt(c.d ? x + c.w - 6 - tw(s, 9, true) : x + 6, y - RH + 12.5, s, 9, true, 'FFFFFF'); x += c.w; });
        y -= RH;
      }
      if (y - 2 * RH < BASE) { nova(false); }
      cab();
      linhas.forEach(function (l, r) {
        if (y - RH < BASE) { nova(false); cab(); }
        if (r % 2 === 0) rect(x0, y - RH + 6, W - 2 * M, RH, 'F3F6FB');
        var x = x0;
        cols.forEach(function (c, i) {
          var s = corta(l[i], 9.5, false, c.w - 12), cc = (corCel && corCel(l, i)) || '14223D';
          txt(c.d ? x + c.w - 6 - tw(s, 9.5, false) : x + 6, y - RH + 12.5, s, 9.5, !!(corCel && corCel(l, i)), cc); x += c.w;
        });
        y -= RH;
      });
      y -= 10;
    }
    nova(true);
    var baixos = dados.itens.filter(function (l) { return l[6] !== 'Em dia'; }).length;
    txt(M, y, 'Filtro: ' + dados.filtro, 10.5, false, CINZA); y -= 15;
    txt(M, y, 'Gerado em ' + dados.geradoEm + ' por ' + dados.geradoPor, 10.5, false, CINZA); y -= 15;
    txt(M, y, 'Itens listados: ' + dados.itens.length + '   ·   Abaixo do mínimo ou zerados: ' + baixos, 10.5, true, NAVY); y -= 28;
    txt(M, y, 'Itens em estoque', 13, true, NAVY); y -= 12;
    tabela([{ t: 'Código', w: 70 }, { t: 'Produto', w: 250 }, { t: 'Categoria', w: 110 }, { t: 'Un', w: 40 }, { t: 'Saldo', w: 80, d: 1 }, { t: 'Mínimo', w: 80, d: 1 }, { t: 'Situação', w: 144 }],
      dados.itens.map(function (l) { return [l[0], l[1], l[2], l[3], fmtN(l[4]), fmtN(l[5]), l[6]]; }),
      function (l, i) { if (i !== 6) return null; return l[6] === 'Zerado' ? 'B3261E' : l[6] === 'Em dia' ? '1E7B4B' : 'B86E0B'; });
    if (dados.movs) {
      if (y - 90 < BASE) nova(false);
      txt(M, y, 'Histórico de movimentações', 13, true, NAVY); y -= 12;
      if (!dados.movs.length) { txt(M, y - 6, 'Nenhuma movimentação registrada para os itens escolhidos.', 10, false, CINZA); y -= 24; }
      else tabela([{ t: 'Quando', w: 92 }, { t: 'Tipo', w: 56 }, { t: 'Produto', w: 180 }, { t: 'Quantidade', w: 60, d: 1 }, { t: 'Un', w: 34 }, { t: 'Saldo após', w: 66, d: 1 }, { t: 'Quem', w: 100 }, { t: 'Destino ou observação', w: 186 }],
        dados.movs.map(function (l) { return [l[0], l[1], l[2], fmtN(l[3]), l[4], fmtN(l[5]), l[6], l[7] || '—']; }),
        function (l, i) { return i === 1 ? (l[1] === 'Entrada' ? '1E7B4B' : l[1] === 'Saída' ? 'B3261E' : '2F4F8F') : null; });
    }
    // rodapé com número de página
    pages.forEach(function (p, i) {
      cur = p; rect(M, 34, W - 2 * M, 0.8, 'C9D3E4');
      txt(M, 20, 'K2J Homogenizer · ' + dados.titulo, 8.5, false, CINZA);
      var s = 'Página ' + (i + 1) + ' de ' + pages.length; txt(W - M - tw(s, 8.5, false), 20, s, 8.5, false, CINZA);
    });
    // montagem do arquivo
    var objs = [];
    function add(s) { objs.push(s); return objs.length; }
    add('<< /Type /Catalog /Pages 2 0 R >>'); add('');
    add('<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica /Encoding /WinAnsiEncoding >>');
    add('<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold /Encoding /WinAnsiEncoding >>');
    if (logo) { var bin = atob(logo.b64); add('<< /Type /XObject /Subtype /Image /Width ' + logo.w + ' /Height ' + logo.h + ' /ColorSpace /DeviceRGB /BitsPerComponent 8 /Filter /DCTDecode /Length ' + bin.length + ' >>\nstream\n' + bin + '\nendstream'); }
    var kids = [];
    pages.forEach(function (p) {
      var c = p.join('\n');
      var cid = add('<< /Length ' + c.length + ' >>\nstream\n' + c + '\nendstream');
      var pid = add('<< /Type /Page /Parent 2 0 R /MediaBox [0 0 ' + W + ' ' + H + '] /Resources << /Font << /F1 3 0 R /F2 4 0 R >>' + (logo ? ' /XObject << /Im1 5 0 R >>' : '') + ' >> /Contents ' + cid + ' 0 R >>');
      kids.push(pid + ' 0 R');
    });
    objs[1] = '<< /Type /Pages /Kids [' + kids.join(' ') + '] /Count ' + pages.length + ' >>';
    var out = '%PDF-1.4\n%âãÏÓ\n', offs = [];
    objs.forEach(function (o, i) { offs.push(out.length); out += (i + 1) + ' 0 obj\n' + o + '\nendobj\n'; });
    var xr = out.length;
    out += 'xref\n0 ' + (objs.length + 1) + '\n0000000000 65535 f \n' + offs.map(function (o) { return ('0000000000' + o).slice(-10) + ' 00000 n \n'; }).join('');
    out += 'trailer\n<< /Size ' + (objs.length + 1) + ' /Root 1 0 R >>\nstartxref\n' + xr + '\n%%EOF';
    var bytes = new Uint8Array(out.length);
    for (var i = 0; i < out.length; i++) bytes[i] = out.charCodeAt(i) & 255;
    return new Blob([bytes], { type: 'application/pdf' });
  }
  function d_canvas() { return document.createElement('canvas').getContext('2d'); }

  window.K2JExport = {
    gerar: function (formato, dados, nomeBase) {
      var blob, ext;
      if (formato === 'xlsx') { blob = xlsx(dados); ext = '.xlsx'; }
      else if (formato === 'pdf') { blob = pdf(dados); ext = '.pdf'; }
      else { blob = csv(dados); ext = '.csv'; }
      baixar(blob, nomeBase + ext);
      return nomeBase + ext;
    }
  };
})();
