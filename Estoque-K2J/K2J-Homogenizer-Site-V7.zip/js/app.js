(function () {
  'use strict';
  // Número do WhatsApp: vazio de propósito (modelo). Exemplo: '5511999999999'
  var WHATSAPP = '';
  var base = 'https://wa.me/' + WHATSAPP + '?text=';
  var d = document;
  d.documentElement.classList.add('js');
  function $(s, r) { return (r || d).querySelector(s); }
  function $$(s, r) { return Array.prototype.slice.call((r || d).querySelectorAll(s)); }
  function link(t) { return base + encodeURIComponent(t); }

  $$('[data-wa]').forEach(function (a) { a.href = link(a.getAttribute('data-wa')); a.target = '_blank'; a.rel = 'noopener'; });

  // entrada suave
  var revs = $$('.rev');
  if ('IntersectionObserver' in window) {
    var io = new IntersectionObserver(function (es) {
      es.forEach(function (e) { if (e.isIntersecting) { e.target.classList.add('in'); io.unobserve(e.target); } });
    }, { threshold: 0.12 });
    revs.forEach(function (r) { io.observe(r); });
  } else { revs.forEach(function (r) { r.classList.add('in'); }); }

  // cabeçalho some ao descer (celular/tablet)
  var topo = $('#topo'), gav = $('#gaveta'), ult = 0;
  window.addEventListener('scroll', function () {
    var y = window.pageYOffset;
    if (window.innerWidth <= 900 && gav.hidden) { topo.classList.toggle('some', y > ult && y > 120); }
    else { topo.classList.remove('some'); }
    ult = y;
  }, { passive: true });

  // menu: item ativo (só na página inicial)
  var links = $$('.topo-links a').filter(function (a) { return a.getAttribute('href').indexOf('#') === 0; });
  var secs = links.map(function (a) { return $(a.getAttribute('href')); });
  function marca() {
    var y = window.pageYOffset + 140, at = -1;
    secs.forEach(function (s, i) { if (s && s.offsetTop <= y) at = i; });
    links.forEach(function (a, i) { a.classList.toggle('on', i === at); });
  }
  if (links.length && $('#inicio')) { window.addEventListener('scroll', marca, { passive: true }); marca(); }

  // gaveta
  var bur = $('.burger'), antes = null;
  function abre() { antes = d.activeElement; gav.hidden = false; bur.setAttribute('aria-expanded', 'true'); d.body.style.overflow = 'hidden'; $('.gaveta-x').focus(); }
  function fecha() { gav.hidden = true; bur.setAttribute('aria-expanded', 'false'); d.body.style.overflow = ''; if (antes) antes.focus(); }
  bur.addEventListener('click', abre);
  $$('[data-fechar]').forEach(function (b) { b.addEventListener('click', fecha); });
  $$('.gaveta-painel a').forEach(function (a) { a.addEventListener('click', function () { gav.hidden = true; bur.setAttribute('aria-expanded', 'false'); d.body.style.overflow = ''; }); });
  d.addEventListener('keydown', function (e) {
    if (gav.hidden) return;
    if (e.key === 'Escape') { fecha(); return; }
    if (e.key === 'Tab') {
      var f = $$('button, a[href]', $('.gaveta-painel')), p = f[0], u = f[f.length - 1];
      if (e.shiftKey && d.activeElement === p) { e.preventDefault(); u.focus(); }
      else if (!e.shiftKey && d.activeElement === u) { e.preventDefault(); p.focus(); }
    }
  });

  // contato -> WhatsApp
  var fc = $('#form-contato');
  if (fc) fc.addEventListener('submit', function (e) {
    e.preventDefault();
    var er = $('#ct-erro'), nome = fc.nome.value.trim(), emp = fc.empresa.value.trim(), as = fc.assunto.value;
    fc.nome.removeAttribute('aria-invalid');
    if (nome.length < 2) { er.textContent = 'Digite seu nome.'; er.hidden = false; fc.nome.setAttribute('aria-invalid', 'true'); fc.nome.focus(); return; }
    er.hidden = true;
    var msg = 'Olá, meu nome é ' + nome + (emp ? ', da empresa ' + emp : '') + '. Gostaria de pedir um orçamento à K2J Homogenizer' + (as ? ' sobre: ' + as : '') + '.';
    window.open(link(msg), '_blank', 'noopener');
  });

})();
