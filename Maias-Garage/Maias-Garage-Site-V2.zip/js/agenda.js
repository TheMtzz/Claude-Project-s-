/* Agendamento da Maia's Garage. Script comum (sem módulos), funciona em file://.
   Sem agendaUrl: monta a mensagem de WhatsApp e o convite do Google Agenda.
   Com agendaUrl (Apps Script): lê horários ocupados e grava o pedido na agenda do cliente. */
(function () {
  'use strict';
  var C = window.MAIAS, f = document.getElementById('fAgenda');
  if (!C || !f) return;
  var T = function (s) { return window.HaneiT ? window.HaneiT(s) : s; };
  var $ = function (s, r) { return (r || document).querySelector(s); };
  var DIAS = ['Domingo', 'Segunda', 'Terça', 'Quarta', 'Quinta', 'Sexta', 'Sábado'];
  var PORTES = { pequeno: 'Pequeno (hatch, compacto)', medio: 'Médio (sedã)', grande: 'Grande (SUV, picape)' };
  var ocupados = [], carregando = false, escolhido = null;
  var elData = $('#ag-data'), elHoras = $('#ag-horas'), elErro = $('#ag-erro'), elOk = $('#ag-ok'), elInfo = $('#ag-info');

  function p2(n) { return (n < 10 ? '0' : '') + n; }
  function agoraLoja() { /* 'AAAA-MM-DD HH:MM:SS' no fuso da loja */
    return new Date().toLocaleString('sv-SE', { timeZone: C.fuso });
  }
  function minDe(d, h, m) { var a = d.split('-'); return Date.UTC(+a[0], +a[1] - 1, +a[2], h, m) / 60000; }
  function minAgora() { var s = agoraLoja(), a = s.slice(0, 10), h = s.slice(11).split(':'); return minDe(a, +h[0], +h[1]); }
  function soma(d, n) { var a = d.split('-'), t = new Date(Date.UTC(+a[0], +a[1] - 1, +a[2] + n)); return t.getUTCFullYear() + '-' + p2(t.getUTCMonth() + 1) + '-' + p2(t.getUTCDate()); }
  function diaSem(d) { var a = d.split('-'); return new Date(Date.UTC(+a[0], +a[1] - 1, +a[2])).getUTCDay(); }
  function br(d) { var a = d.split('-'); return a[2] + '/' + a[1]; }
  function servico() { var r = f.querySelector('input[name=servico]:checked'); return r ? C.servicos[r.value] : null; }
  function duracaoTxt(min) { var h = Math.floor(min / 60), m = min % 60; return h ? (h + 'h' + (m ? p2(m) : '')) : (m + ' min'); }

  function dias() {
    var hoje = agoraLoja().slice(0, 10), out = [];
    for (var i = 0; i <= C.diasAFrente; i++) { var d = soma(hoje, i); if (C.horarios[diaSem(d)]) out.push(d); }
    return out;
  }
  function livres(d, dur) {
    var jan = C.horarios[diaSem(d)] || [], lim = minAgora() + C.antecedenciaMin, out = [];
    jan.forEach(function (j) {
      for (var t = j[0] * 60; t + dur <= j[1] * 60; t += C.passoMin) {
        var ini = minDe(d, 0, t), fim = ini + dur;
        if (ini < lim) continue;
        var bate = ocupados.some(function (o) { return ini < o[1] && fim > o[0]; });
        if (!bate) out.push(t);
      }
    });
    return out;
  }
  function hhmm(t) { return p2(Math.floor(t / 60)) + ':' + p2(t % 60); }

  function desenhaDatas() {
    var s = servico(), atual = elData.value;
    elData.innerHTML = '';
    var o0 = document.createElement('option'); o0.value = ''; o0.textContent = T('Escolha o dia'); elData.appendChild(o0);
    if (!s) return;
    dias().forEach(function (d) {
      if (!livres(d, s.min).length) return;
      var o = document.createElement('option'); o.value = d;
      o.textContent = T(DIAS[diaSem(d)]) + ', ' + br(d); elData.appendChild(o);
    });
    if (atual) elData.value = atual;
    if (elData.value !== atual) { elData.value = ''; }
  }
  function desenhaHoras() {
    elHoras.innerHTML = ''; escolhido = null;
    var s = servico(), d = elData.value;
    if (!s || !d) { elHoras.textContent = T('Escolha o serviço e o dia para ver os horários.'); return; }
    var l = livres(d, s.min);
    if (!l.length) { elHoras.textContent = T('Sem horários livres neste dia.'); return; }
    l.forEach(function (t) {
      var lb = document.createElement('label'); lb.className = 'ag-h';
      var i = document.createElement('input'); i.type = 'radio'; i.name = 'hora'; i.value = hhmm(t); i.required = true;
      var sp = document.createElement('span'); sp.textContent = hhmm(t);
      i.addEventListener('change', function () { escolhido = i.value; limpaErro(); });
      lb.appendChild(i); lb.appendChild(sp); elHoras.appendChild(lb);
    });
  }
  function atualizaInfo() {
    var s = servico();
    elInfo.textContent = s ? (T(s.nome) + ' · ' + T('duração aproximada') + ' ' + duracaoTxt(s.min)) : '';
  }
  function erro(msg, campo) { elErro.textContent = T(msg); elErro.hidden = false; if (campo) campo.focus(); }
  function limpaErro() { elErro.hidden = true; elErro.textContent = ''; }

  function carregaOcupados() {
    if (!C.agendaUrl) { desenhaDatas(); desenhaHoras(); return; }
    carregando = true;
    var hoje = agoraLoja().slice(0, 10);
    var u = C.agendaUrl + (C.agendaUrl.indexOf('?') < 0 ? '?' : '&') + 'acao=ocupados&de=' + hoje + '&ate=' + soma(hoje, C.diasAFrente + 1);
    fetch(u, { method: 'GET', cache: 'no-store' }).then(function (r) { return r.json(); }).then(function (j) {
      ocupados = (j.ocupados || []).map(function (p) { return [Date.parse(p[0]) / 60000 + C.fusoMin, Date.parse(p[1]) / 60000 + C.fusoMin]; });
    }).catch(function () { ocupados = []; }).then(function () { carregando = false; desenhaDatas(); desenhaHoras(); });
  }

  function limpaTel(v) { return String(v).replace(/\D/g, ''); }
  function texto(v, n) { return String(v || '').replace(/[\u0000-\u001f\u007f]/g, ' ').replace(/\s+/g, ' ').trim().slice(0, n); }
  function dadosForm() {
    var s = servico(), fd = new FormData(f);
    return {
      servico: f.querySelector('input[name=servico]:checked') ? f.querySelector('input[name=servico]:checked').value : '',
      s: s, porte: fd.get('porte') || '', carro: texto(fd.get('carro'), 60), data: elData.value, hora: escolhido,
      nome: texto(fd.get('nome'), 80), tel: limpaTel(fd.get('tel')), obs: texto(fd.get('obs'), 200)
    };
  }
  function msgWhats(d) {
    var dt = DIAS[diaSem(d.data)] + ' ' + br(d.data) + ' ' + 'às' + ' ' + d.hora;
    return 'Olá! Quero agendar na Maia\'s Garage:\n' +
      '• ' + d.s.nome + ' (' + 'duração aproximada' + ' ' + duracaoTxt(d.s.min) + ')\n' +
      '• ' + 'Carro' + ': ' + d.carro + ' (' + PORTES[d.porte] + ')\n' +
      '• ' + 'Dia e hora' + ': ' + dt + '\n' +
      '• ' + 'Nome' + ': ' + d.nome + '\n' + '• ' + 'Telefone' + ': ' + d.tel +
      (d.obs ? '\n• ' + 'Observações' + ': ' + d.obs : '');
  }
  function linkWhats(d) { return 'https://wa.me/' + C.whatsapp + '?text=' + encodeURIComponent(msgWhats(d)); }
  function linkGoogle(d) {
    var a = d.data.replace(/-/g, ''), h = d.hora.replace(':', '') + '00', fimMin = (parseInt(d.hora, 10) * 60 + parseInt(d.hora.slice(3), 10)) + d.s.min;
    var fim = a + 'T' + p2(Math.floor(fimMin / 60) % 24) + p2(fimMin % 60) + '00';
    return 'https://calendar.google.com/calendar/render?action=TEMPLATE&text=' + encodeURIComponent(d.s.nome + ' – Maia\'s Garage') +
      '&dates=' + a + 'T' + h + '/' + fim + '&ctz=' + encodeURIComponent(C.fuso) +
      '&details=' + encodeURIComponent('Carro' + ': ' + d.carro + ' (' + PORTES[d.porte] + ')') + '&location=' + encodeURIComponent(C.local);
  }
  function mostraOk(d, enviado) {
    elOk.innerHTML = '';
    var p = document.createElement('p'); p.className = 'ag-ok-t';
    p.textContent = T(enviado ? 'Pedido enviado! A Maia\'s Garage vai confirmar o seu horário.' : 'Quase lá! Envie o pedido pelo WhatsApp para a Maia\'s Garage confirmar.');
    elOk.appendChild(p);
    var a1 = document.createElement('a'); a1.className = 'btn btn-y'; a1.href = linkWhats(d); a1.target = '_blank'; a1.rel = 'noopener noreferrer';
    a1.textContent = T(enviado ? 'Também avisar no WhatsApp' : 'Enviar pelo WhatsApp');
    var a2 = document.createElement('a'); a2.className = 'btn btn-l'; a2.href = linkGoogle(d); a2.target = '_blank'; a2.rel = 'noopener noreferrer';
    a2.textContent = T('Adicionar ao meu Google Agenda');
    var w = document.createElement('div'); w.className = 'ag-ok-b'; w.appendChild(a1); w.appendChild(a2); elOk.appendChild(w);
    elOk.hidden = false; elOk.setAttribute('tabindex', '-1'); elOk.focus();
  }

  f.addEventListener('submit', function (e) {
    e.preventDefault(); limpaErro(); elOk.hidden = true;
    if (f.querySelector('[name=site]').value) return; /* campo isca: robôs */
    var d = dadosForm();
    if (!d.s) return erro('Escolha o tipo de lavagem.', f.querySelector('input[name=servico]'));
    if (!d.porte) return erro('Escolha o porte do carro.', f.querySelector('[name=porte]'));
    if (d.carro.length < 2) return erro('Informe o modelo do carro.', f.querySelector('[name=carro]'));
    if (!d.data) return erro('Escolha o dia.', elData);
    if (!d.hora) return erro('Escolha o horário.', elHoras.querySelector('input'));
    if (d.nome.length < 2) return erro('Informe o seu nome.', f.querySelector('[name=nome]'));
    if (d.tel.length < 10 || d.tel.length > 13) return erro('Informe um WhatsApp com DDD.', f.querySelector('[name=tel]'));
    if (!f.querySelector('[name=aceite]').checked) return erro('Marque que está de acordo com a Política de Privacidade.', f.querySelector('[name=aceite]'));
    if (!C.agendaUrl) { mostraOk(d, false); return; }
    var b = $('button[type=submit]', f); b.disabled = true; b.textContent = T('Enviando...');
    fetch(C.agendaUrl, { method: 'POST', headers: { 'Content-Type': 'text/plain;charset=utf-8' }, body: JSON.stringify({ acao: 'agendar', servico: d.servico, porte: d.porte, carro: d.carro, data: d.data, hora: d.hora, nome: d.nome, tel: d.tel, obs: d.obs }) })
      .then(function (r) { return r.json(); }).then(function (j) {
        if (j && j.ok) { mostraOk(d, true); f.reset(); escolhido = null; carregaOcupados(); }
        else if (j && j.erro === 'ocupado') { erro('Esse horário acabou de ser ocupado. Escolha outro.'); carregaOcupados(); }
        else { erro('Não foi possível enviar agora. Use o botão do WhatsApp.'); mostraOk(d, false); }
      }).catch(function () { erro('Não foi possível enviar agora. Use o botão do WhatsApp.'); mostraOk(d, false); })
      .then(function () { b.disabled = false; b.textContent = T('Enviar pedido de agendamento'); });
  });

  f.addEventListener('change', function (e) {
    if (e.target.name === 'servico') { atualizaInfo(); desenhaDatas(); desenhaHoras(); }
    if (e.target.id === 'ag-data') desenhaHoras();
  });
  document.addEventListener('maias-idioma', function () { atualizaInfo(); var v = elData.value; desenhaDatas(); elData.value = v; desenhaHoras(); });

  /* botões do site que pré-selecionam o serviço */
  [].forEach.call(document.querySelectorAll('[data-servico]'), function (a) {
    a.addEventListener('click', function () {
      var r = f.querySelector('input[name=servico][value=' + a.getAttribute('data-servico') + ']');
      if (r) { r.checked = true; r.dispatchEvent(new Event('change', { bubbles: true })); }
    });
  });
  atualizaInfo(); carregaOcupados();
})();
