/**
 * Agenda da Maia's Garage — Google Apps Script (roda na conta Google do cliente).
 * Faz duas coisas:
 *  - GET  ?acao=ocupados&de=AAAA-MM-DD&ate=AAAA-MM-DD  -> devolve só os intervalos ocupados (sem nome nem telefone);
 *  - POST {acao:'agendar', ...}                         -> cria o pedido na agenda como "[PENDENTE]" e avisa o dono por e-mail.
 * O dono confirma tirando o "[PENDENTE]" do título (ou apaga o evento para recusar).
 * Publicar como "App da Web": executar como EU, acesso para QUALQUER PESSOA (veja LEIA-ME-AGENDA.md).
 */
var CFG = {
  fuso: 'America/Sao_Paulo',
  offset: '-03:00',
  passoMin: 30,
  antecedenciaMin: 120,
  diasAFrente: 30,
  maxPendentesPorTelefone: 3,
  servicos: { simples: { nome: 'Lavagem Simples', min: 60 }, detalhada: { nome: 'Lavagem Detalhada', min: 180 } }, // CONFIRMAR tempos (igual ao js/config.js)
  horarios: { 1: [[8, 18]], 2: [[14, 18]], 3: [[14, 18]], 4: [[14, 18]], 5: [[8, 18]], 6: [[8, 12]] },
  portes: { pequeno: 'Pequeno', medio: 'Médio', grande: 'Grande' }
};

function resp_(o) { return ContentService.createTextOutput(JSON.stringify(o)).setMimeType(ContentService.MimeType.JSON); }
function p2_(n) { return (n < 10 ? '0' : '') + n; }
function limpa_(v, n) { return String(v == null ? '' : v).replace(/[\u0000-\u001f\u007f]/g, ' ').replace(/\s+/g, ' ').trim().substring(0, n); }
function dataOk_(d) { return /^\d{4}-\d{2}-\d{2}$/.test(d); }
function horaOk_(h) { return /^\d{2}:\d{2}$/.test(h); }
function dt_(d, h) { return new Date(d + 'T' + (h || '00:00') + ':00' + CFG.offset); }
function diaSemana_(d) { return dt_(d, '12:00').getUTCDay(); } // meio-dia local evita virar o dia no UTC

function doGet(e) {
  var p = (e && e.parameter) || {};
  if (p.acao !== 'ocupados' || !dataOk_(p.de || '') || !dataOk_(p.ate || '')) return resp_({ ok: false, erro: 'pedido' });
  var de = dt_(p.de), ate = dt_(p.ate);
  if (ate - de > 40 * 86400000 || ate <= de) return resp_({ ok: false, erro: 'periodo' });
  var evs = CalendarApp.getDefaultCalendar().getEvents(de, ate);
  return resp_({ ok: true, ocupados: evs.map(function (ev) { return [ev.getStartTime().toISOString(), ev.getEndTime().toISOString()]; }) });
}

function doPost(e) {
  var lock = LockService.getScriptLock();
  try {
    lock.waitLock(15000);
    var b = JSON.parse((e && e.postData && e.postData.contents) || '{}');
    if (b.acao !== 'agendar') return resp_({ ok: false, erro: 'acao' });
    var s = CFG.servicos[b.servico];
    var porte = CFG.portes[b.porte];
    var nome = limpa_(b.nome, 80), carro = limpa_(b.carro, 60), obs = limpa_(b.obs, 200), tel = String(b.tel || '').replace(/\D/g, '');
    if (!s || !porte || nome.length < 2 || carro.length < 2 || tel.length < 10 || tel.length > 13) return resp_({ ok: false, erro: 'dados' });
    if (!dataOk_(b.data || '') || !horaOk_(b.hora || '')) return resp_({ ok: false, erro: 'dados' });

    // horário precisa existir na grade da loja
    var janelas = CFG.horarios[diaSemana_(b.data)] || [];
    var hh = parseInt(b.hora.substring(0, 2), 10), mm = parseInt(b.hora.substring(3), 10), ini = hh * 60 + mm;
    var cabe = janelas.some(function (j) { return ini >= j[0] * 60 && ini + s.min <= j[1] * 60 && (ini - j[0] * 60) % CFG.passoMin === 0; });
    if (!cabe) return resp_({ ok: false, erro: 'horario' });
    var inicio = dt_(b.data, b.hora), fim = new Date(inicio.getTime() + s.min * 60000);
    var agora = new Date();
    if (inicio.getTime() < agora.getTime() + CFG.antecedenciaMin * 60000) return resp_({ ok: false, erro: 'horario' });
    if (inicio.getTime() > agora.getTime() + (CFG.diasAFrente + 1) * 86400000) return resp_({ ok: false, erro: 'horario' });

    var cal = CalendarApp.getDefaultCalendar();
    if (cal.getEvents(inicio, fim).length) return resp_({ ok: false, erro: 'ocupado' });

    // freio contra abuso: poucos pedidos pendentes por telefone
    var futuros = cal.getEvents(agora, new Date(agora.getTime() + (CFG.diasAFrente + 1) * 86400000), { search: tel });
    var pend = futuros.filter(function (ev) { return ev.getTitle().indexOf('[PENDENTE]') === 0; }).length;
    if (pend >= CFG.maxPendentesPorTelefone) return resp_({ ok: false, erro: 'limite' });

    var titulo = '[PENDENTE] ' + s.nome + ' – ' + nome;
    var desc = 'Pedido pelo site.\nServiço: ' + s.nome + '\nCarro: ' + carro + ' (' + porte + ')\nCliente: ' + nome + '\nWhatsApp: ' + tel + (obs ? '\nObservações: ' + obs : '') + '\n\nPara confirmar, tire o "[PENDENTE]" do título. Para recusar, apague o evento.';
    var ev = cal.createEvent(titulo, inicio, fim, { description: desc });
    ev.setColor(CalendarApp.EventColor.YELLOW);
    try { MailApp.sendEmail(Session.getEffectiveUser().getEmail(), 'Novo pedido de agendamento: ' + s.nome, desc + '\n\nQuando: ' + b.data + ' ' + b.hora); } catch (err) { /* e-mail é só um aviso */ }
    return resp_({ ok: true });
  } catch (err) {
    return resp_({ ok: false, erro: 'interno' });
  } finally {
    try { lock.releaseLock(); } catch (_) { }
  }
}
