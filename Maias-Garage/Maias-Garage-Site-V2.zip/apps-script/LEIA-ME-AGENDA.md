# Agenda do Google na Maia's Garage — como ligar (uns 10 minutos)

O site já vem com o agendamento pronto. Sem esta ligação ele funciona assim: o cliente escolhe lavagem, carro, dia e hora e recebe um botão que envia o pedido pelo WhatsApp e um botão "Adicionar ao Google Agenda". Com a ligação abaixo, o pedido entra direto na agenda do dono e os horários já ocupados somem do site.

## O que preciso do cliente
1. O **Gmail** que vai guardar a agenda (a conta Google dele).
2. O **WhatsApp** (com DDD), o **endereço** completo e os **horários** de funcionamento.
3. O **tempo real** de cada lavagem (simples e detalhada) e os **valores**.

## Passo a passo (feito logado na conta Google do cliente)
1. Abra https://script.google.com e clique em **Novo projeto**.
2. Apague o código que aparece, cole o conteúdo de `Codigo.gs` e confira os tempos e horários no topo (`CFG`). Eles devem ser iguais aos de `js/config.js`.
3. Clique em **Implantar > Nova implantação > Tipo: App da Web**. Em *Executar como* escolha **Eu**; em *Quem pode acessar* escolha **Qualquer pessoa**. Clique em **Implantar** e **autorize** o acesso à agenda e ao envio de e-mail.
4. Copie o endereço que termina em `/exec` e cole em `agendaUrl` no arquivo `js/config.js`.
5. Suba o site de novo no Netlify. O `_headers` já libera só `script.google.com` e `script.googleusercontent.com`.
6. Teste fazendo um pedido: ele aparece na agenda como **[PENDENTE]** em amarelo e chega um e-mail de aviso. Para confirmar, tire o "[PENDENTE]" do título; para recusar, apague o evento.

## Segurança e limites
- O endereço `/exec` é público (precisa ser, para o site conversar com ele). Por isso o script confere tudo no servidor: serviço, dia e hora dentro da grade, antecedência, horário livre e no máximo 3 pedidos pendentes por telefone. Textos são limpos e cortados.
- A consulta de horários devolve só os intervalos ocupados, sem nome nem telefone.
- Só o dono vê os dados do cliente, dentro da própria agenda. Informe isso na Política de Privacidade (já atualizada nesta versão).
- Se mudar o código do script, é preciso fazer **Implantar > Gerenciar implantações > Editar > Nova versão**.
- Cotas gratuitas do Google são mais que suficientes para uma lavagem de carros.
