// Troca o WhatsApp, o e-mail e o endereço de exemplo pelos dados reais, em todos os arquivos do site.
// Uso:  node tools/trocar-dados.mjs --whatsapp 5561999990000 --email contato@exemplo.com --local "Rua X, 10, Sobradinho-DF"
import fs from 'node:fs'; import path from 'node:path';
const a = process.argv.slice(2), g = k => { const i = a.indexOf('--' + k); return i > -1 ? a[i + 1] : null; };
const wa = g('whatsapp'), em = g('email'), lc = g('local');
if (!wa && !em && !lc) { console.log('Informe ao menos --whatsapp, --email ou --local'); process.exit(1); }
if (wa && !/^\d{12,13}$/.test(wa)) { console.log('WhatsApp: use só dígitos com DDI+DDD (ex.: 5561999990000)'); process.exit(1); }
const fmt = wa ? `(${wa.slice(2, 4)}) ${wa.slice(4, -4)}-${wa.slice(-4)}` : null;
const raiz = path.resolve(path.dirname(new URL(import.meta.url).pathname), '..'); let n = 0;
(function varre(d) { for (const f of fs.readdirSync(d)) { const p = path.join(d, f), s = fs.statSync(p);
  if (s.isDirectory()) { if (!['node_modules', 'img', 'fonts', 'tools'].includes(f)) varre(p); continue; }
  if (!/\.(html|js|gs|md)$/.test(f)) continue; let t = fs.readFileSync(p, 'utf8'), o = t;
  if (wa) { t = t.replaceAll('5500000000000', wa).replaceAll('(00) 00000-0000', fmt); }
  if (em) t = t.replaceAll('[E-MAIL DE CONTATO]', em);
  if (lc) t = t.replace("local: 'Sobradinho, Distrito Federal'", `local: '${lc.replace(/'/g, "\\'")}'`);
  if (t !== o) { fs.writeFileSync(p, t); n++; console.log('atualizado', path.relative(raiz, p)); } } })(raiz);
console.log(n + ' arquivo(s) atualizado(s).');
