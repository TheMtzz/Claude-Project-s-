# Maia's Garage, versão 2
Novidades: agendamento online (lavagem, carro, dia e hora, com a duração de cada lavagem), pronto para o Google Agenda; PT/EN/ES; painel de acessibilidade; cabeçalhos de segurança; política de privacidade atualizada.
Para voltar à versão anterior, use `Maias-Garage-site.zip` (V1), que continua guardado.

## Antes de publicar, troque os dados de exemplo
1. `node tools/trocar-dados.mjs --whatsapp 5561999990000 --email contato@exemplo.com --local "Endereço completo"` (troca o WhatsApp, o e-mail e o endereço em todos os arquivos).
2. `js/config.js`: tempo de cada lavagem (hoje 1h e 3h são exemplos) e os horários.
3. Valores das lavagens (hoje o site diz "consulte pelo WhatsApp").
4. CNPJ e razão social no rodapé e nas páginas legais ([entre colchetes]).
5. Google Agenda: siga `apps-script/LEIA-ME-AGENDA.md` quando tiver o Gmail do cliente e cole o endereço em `agendaUrl`.

Enquanto o `agendaUrl` estiver vazio, o cliente envia o pedido pelo WhatsApp e pode adicionar o horário ao próprio Google Agenda.
