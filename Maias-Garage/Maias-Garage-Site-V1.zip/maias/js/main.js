(function(){

  const reduz=window.matchMedia&&window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  /* Controle antes/depois: duas imagens alinhadas, recorte sincronizado */
  function criaSlider(cena,aoMudar){
    const limpo=cena.querySelector('.limpo'),linha=cena.querySelector('.linha');
    const alca=cena.querySelector('.alca'),dica=cena.querySelector('.dica');
    const est={pos:0,arrasta:false};
    const set=function(p){
      est.pos=Math.max(0,Math.min(100,p));
      limpo.style.clipPath='inset(0 '+(100-est.pos)+'% 0 0)';
      linha.style.left=est.pos+'%';
      alca.style.left=est.pos+'%';
      alca.setAttribute('aria-valuenow',String(Math.round(est.pos)));
      if(est.pos>2)dica.classList.add('x');
      if(aoMudar)aoMudar(est.pos);
    };
    const doX=function(x){const r=cena.getBoundingClientRect();set((x-r.left)/r.width*100)};
    cena.addEventListener('pointerdown',function(e){
      est.arrasta=true;cena.classList.add('ok');
      if(est.parar)est.parar();
      try{cena.setPointerCapture(e.pointerId)}catch(_){/* sem captura */}
      doX(e.clientX);e.preventDefault();
    });
    cena.addEventListener('pointermove',function(e){if(est.arrasta)doX(e.clientX)});
    ['pointerup','pointercancel'].forEach(function(t){cena.addEventListener(t,function(){est.arrasta=false})});
    alca.addEventListener('keydown',function(e){
      const k={ArrowRight:est.pos+5,ArrowLeft:est.pos-5,ArrowUp:est.pos+5,ArrowDown:est.pos-5,Home:0,End:100}[e.key];
      if(k===undefined)return;
      if(est.parar)est.parar();
      set(k);e.preventDefault();
    });
    est.set=set;est.cena=cena;
    set(0);
    return est;
  }

  function initHero(){
    const cl=document.querySelector('.cena-l'),cp=document.querySelector('.cena-p');
    const cta=document.querySelector('.cta-lava'),ctaP=document.querySelector('.cta-pol');
    const sl=criaSlider(cl,function(p){
      cta.classList.toggle('on',p>=96);
      cl.classList.toggle('fim',p>=96);
    });
    setTimeout(function(){cl.classList.add('pronto')},reduz?0:2500);

    /* Polimento: inspeção -> correção -> revelação */
    const zoom=cp.querySelector('.zoom'),passos=document.querySelectorAll('.passos li');
    const btn=document.getElementById('verPol');
    let timers=[],raf=0;
    const marca=function(n){passos.forEach(function(li){li.classList.toggle('on',Number(li.dataset.p)===n)})};
    const zoomar=function(v){
      cp.classList.toggle('zoomado',v);
      zoom.style.transform=v?'scale(1.7)':'';
      zoom.style.transformOrigin='50% 40%';
    };
    const sp=criaSlider(cp,function(p){cp.classList.toggle('fim',p>=96)});
    const parar=function(){
      timers.forEach(clearTimeout);timers=[];cancelAnimationFrame(raf);
      zoomar(false);
    };
    sp.parar=parar;
    const varre=function(ate,dur,fim){
      const ini=performance.now(),de=sp.pos;
      const passo=function(t){
        const k=Math.min(1,(t-ini)/dur),e=k<.5?2*k*k:1-Math.pow(-2*k+2,2)/2;
        sp.set(de+(ate-de)*e);
        if(k<1)raf=requestAnimationFrame(passo);else if(fim)fim();
      };
      raf=requestAnimationFrame(passo);
    };
    const roda=function(){
      parar();cp.classList.remove('fim');sp.set(0);
      btn.textContent='Ver de novo';
      if(reduz){marca(3);sp.set(100);return}
      marca(1);zoomar(true);
      timers.push(setTimeout(function(){
        marca(2);zoomar(false);
        timers.push(setTimeout(function(){varre(100,2600,function(){marca(3)})},1200));
      },2600));
    };
    btn.addEventListener('click',roda);
    sp.cena.addEventListener('pointerdown',function(){marca(0)});

    /* Abas */
    const abas=[document.getElementById('t-lav'),document.getElementById('t-pol')];
    const paineis=[document.getElementById('p-lav'),document.getElementById('p-pol')];
    const troca=function(i,foco){
      if(i!==1)parar();
      else paineis[1].querySelectorAll('img').forEach(function(im){im.loading='eager'});
      abas.forEach(function(a,j){
        a.classList.toggle('on',j===i);
        a.setAttribute('aria-selected',j===i?'true':'false');
        a.tabIndex=j===i?0:-1;
        paineis[j].hidden=j!==i;
      });
      if(foco)abas[i].focus();
    };
    abas.forEach(function(a,i){
      a.addEventListener('click',function(){troca(i)});
      a.addEventListener('keydown',function(e){
        const k={ArrowRight:1,ArrowLeft:0,Home:0,End:1}[e.key];
        if(k===undefined)return;
        troca(k,true);e.preventDefault();
      });
    });
    if(ctaP)ctaP.setAttribute('data-ok','1');
  }

  function initMenu(){
    const gav=document.getElementById('gaveta'),bg=document.getElementById('burger');
    const abre=function(v){
      gav.classList.toggle('on',v);
      gav.setAttribute('aria-hidden',v?'false':'true');
      bg.setAttribute('aria-expanded',v?'true':'false');
      bg.setAttribute('aria-label',v?'Fechar menu':'Abrir menu');
      document.body.style.overflow=v?'hidden':'';
      if(v){document.getElementById('gavetaX').focus()}else{bg.focus()}
    };
    bg.addEventListener('click',function(){abre(true)});
    document.getElementById('gavetaX').addEventListener('click',function(){abre(false)});
    document.getElementById('gavetaFundo').addEventListener('click',function(){abre(false)});
    gav.querySelectorAll('a').forEach(function(a){a.addEventListener('click',function(){abre(false)})});
    document.addEventListener('keydown',function(e){if(e.key==='Escape'&&gav.classList.contains('on'))abre(false)});
  }

  function initCabecalho(){
    const topo=document.getElementById('topo');
    let ult=0;
    window.addEventListener('scroll',function(){
      const y=window.scrollY;
      if(window.innerWidth<=900){topo.classList.toggle('esconde',y>ult&&y>120)}else{topo.classList.remove('esconde')}
      ult=y;
    },{passive:true});
  }

  function initHoje(){
    const d=new Date().getDay();
    document.querySelectorAll('#tab tr').forEach(function(tr){
      if(tr.getAttribute('data-d').split(',').indexOf(String(d))>-1){tr.classList.add('hoje');tr.setAttribute('aria-current','date')}
    });
  }

  function initEntrada(){
    document.documentElement.classList.add('js');
    const rev=document.querySelectorAll('.rev');
    if(!('IntersectionObserver' in window)){rev.forEach(function(r){r.classList.add('vis')});return}
    const io=new IntersectionObserver(function(es){es.forEach(function(e){if(e.isIntersecting){e.target.classList.add('vis');io.unobserve(e.target)}})},{threshold:.12});
    rev.forEach(function(r){io.observe(r)});
  }

  [initHero,initMenu,initCabecalho,initHoje,initEntrada].forEach(function(f){f()});
})();
