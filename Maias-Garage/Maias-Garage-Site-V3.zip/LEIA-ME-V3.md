# Maia's Garage, versão 3
O que mudou em relação à V2: **sem Google Agenda**. O formulário continua igual (lavagem, carro, dia e horário, nome, WhatsApp), mas ao enviar o pedido ele abre o WhatsApp da loja com a mensagem pronta (lavagem, duração, carro, dia e hora, nome, telefone e observações). Não há mais pasta `apps-script`, nem endereço do Google nos cabeçalhos de segurança, e a Política de Privacidade foi ajustada.

A V2 continua guardada em `Maias-Garage-Site-V2.zip`.

## Antes de publicar, troque os dados de exemplo
1. `node tools/trocar-dados.mjs --whatsapp 5561999990000 --email contato@exemplo.com --local "Endereço completo"`
2. `js/config.js`: tempo de cada lavagem (1h e 3h são exemplos) e os horários.
3. Valores das lavagens (hoje o site diz "consulte pelo WhatsApp").
4. CNPJ e razão social no rodapé e nas páginas legais (entre colchetes).

Obs.: como não há agenda, o site oferece todos os horários da tabela, e a loja confirma ou sugere outro pelo WhatsApp.
