/* Configuração do agendamento da Maia's Garage.
   Os itens marcados "CONFIRMAR" são valores de exemplo: troque pelos dados reais do cliente. */
window.MAIAS = {
  whatsapp: '5500000000000',            /* CONFIRMAR: WhatsApp da Maia's Garage (DDI+DDD+número, só dígitos) */
  local: 'Sobradinho, Distrito Federal', /* CONFIRMAR: endereço completo */
  fuso: 'America/Sao_Paulo',
  passoMin: 30,                          /* de quanto em quanto tempo oferece um horário */
  antecedenciaMin: 120,                  /* não oferece horário com menos de 2 h de antecedência */
  diasAFrente: 30,
  servicos: {
    simples:   { nome: 'Lavagem Simples',   min: 60 },   /* CONFIRMAR: tempo real da lavagem simples */
    detalhada: { nome: 'Lavagem Detalhada', min: 180 }   /* CONFIRMAR: tempo real da lavagem detalhada */
  },
  /* dia da semana (0=domingo) -> janelas [início, fim] em horas. Conforme a tabela de horários do site */
  horarios: { 1: [[8, 18]], 2: [[14, 18]], 3: [[14, 18]], 4: [[14, 18]], 5: [[8, 18]], 6: [[8, 12]] }
};
