/* Agendamento da Maia's Garage. Script comum (sem módulos), funciona em file://.
   O cliente escolhe lavagem, carro, dia e hora; o pedido vai pronto para o WhatsApp da loja. Sem integração com agenda externa. */
(function () {
  'use strict';
  var C = window.MAIAS, f = document.getElementById('fAgenda');
  if (!C || !f) return;
  var T = function (s) { return window.HaneiT ? window.HaneiT(s) : s; };
  var $ = function (s, r) { return (r || document).querySelector(s); };
  var DIAS = ['Domingo', 'Segunda', 'Terça', 'Quarta', 'Quinta', 'Sexta', 'Sábado'];
  var PORTES = { pequeno: 'Pequeno (hatch, compacto)', medio: 'Médio (sedã)', grande: 'Grande (SUV, picape)' };
  var escolhido = null;
  var elData = $('#ag-data'), elHoras = $('#ag-horas'), elErro = $('#ag-erro'), elOk = $('#ag-ok'), elInfo = $('#ag-info');

  function p2(n) { return (n < 10 ? '0' : '') + n; }
  function agoraLoja() { /* 'AAAA-MM-DD HH:MM:SS' no fuso da loja */
    return new Date().toLocaleString('sv-SE', { timeZone: C.fuso });
  }
  function minDe(d, h, m) { var a = d.split('-'); return Date.UTC(+a[0], +a[1] - 1, +a[2], h, m) / 60000; }
  function minAgora() { var s = agoraLoja(), a = s.slice(0, 10), h = s.slice(11).split(':'); return minDe(a, +h[0], +h[1]); }
  function soma(d, n) { var a = d.split('-'), t = new Date(Date.UTC(+a[0], +a[1] - 1, +a[2] + n)); return t.getUTCFullYear() + '-' + p2(t.getUTCMonth() + 1) + '-' + p2(t.getUTCDate()); }
  function diaSem(d) { var a = d.split('-'); return new Date(Date.UTC(+a[0], +a[1] - 1, +a[2])).getUTCDay(); }
  function br(d) { var a = d.split('-'); return a[2] + '/' + a[1]; }
  function servico() { var r = f.querySelector('input[name=servico]:checked'); return r ? C.servicos[r.value] : null; }
  function duracaoTxt(min) { var h = Math.floor(min / 60), m = min % 60; return h ? (h + 'h' + (m ? p2(m) : '')) : (m + ' min'); }

  function dias() {
    var hoje = agoraLoja().slice(0, 10), out = [];
    for (var i = 0; i <= C.diasAFrente; i++) { var d = soma(hoje, i); if (C.horarios[diaSem(d)]) out.push(d); }
    return out;
  }
  function livres(d, dur) {
    var jan = C.horarios[diaSem(d)] || [], lim = minAgora() + C.antecedenciaMin, out = [];
    jan.forEach(function (j) {
      for (var t = j[0] * 60; t + dur <= j[1] * 60; t += C.passoMin) {
        if (minDe(d, 0, t) < lim) continue;
        out.push(t);
      }
    });
    return out;
  }
  function hhmm(t) { return p2(Math.floor(t / 60)) + ':' + p2(t % 60); }

  function desenhaDatas() {
    var s = servico(), atual = elData.value;
    elData.innerHTML = '';
    var o0 = document.createElement('option'); o0.value = ''; o0.textContent = T('Escolha o dia'); elData.appendChild(o0);
    if (!s) return;
    dias().forEach(function (d) {
      if (!livres(d, s.min).length) return;
      var o = document.createElement('option'); o.value = d;
      o.textContent = T(DIAS[diaSem(d)]) + ', ' + br(d); elData.appendChild(o);
    });
    if (atual) elData.value = atual;
    if (elData.value !== atual) { elData.value = ''; }
  }
  function desenhaHoras() {
    elHoras.innerHTML = ''; escolhido = null;
    var s = servico(), d = elData.value;
    if (!s || !d) { elHoras.textContent = T('Escolha o serviço e o dia para ver os horários.'); return; }
    var l = livres(d, s.min);
    if (!l.length) { elHoras.textContent = T('Sem horários livres neste dia.'); return; }
    l.forEach(function (t) {
      var lb = document.createElement('label'); lb.className = 'ag-h';
      var i = document.createElement('input'); i.type = 'radio'; i.name = 'hora'; i.value = hhmm(t); i.required = true;
      var sp = document.createElement('span'); sp.textContent = hhmm(t);
      i.addEventListener('change', function () { escolhido = i.value; limpaErro(); });
      lb.appendChild(i); lb.appendChild(sp); elHoras.appendChild(lb);
    });
  }
  function atualizaInfo() {
    var s = servico();
    elInfo.textContent = s ? (T(s.nome) + ' · ' + T('duração aproximada') + ' ' + duracaoTxt(s.min)) : '';
  }
  function erro(msg, campo) { elErro.textContent = T(msg); elErro.hidden = false; if (campo) campo.focus(); }
  function limpaErro() { elErro.hidden = true; elErro.textContent = ''; }

  function limpaTel(v) { return String(v).replace(/\D/g, ''); }
  function texto(v, n) { return String(v || '').replace(/[\u0000-\u001f\u007f]/g, ' ').replace(/\s+/g, ' ').trim().slice(0, n); }
  function dadosForm() {
    var s = servico(), fd = new FormData(f);
    return {
      servico: f.querySelector('input[name=servico]:checked') ? f.querySelector('input[name=servico]:checked').value : '',
      s: s, porte: fd.get('porte') || '', carro: texto(fd.get('carro'), 60), data: elData.value, hora: escolhido,
      nome: texto(fd.get('nome'), 80), tel: limpaTel(fd.get('tel')), obs: texto(fd.get('obs'), 200)
    };
  }
  function msgWhats(d) {
    var dt = DIAS[diaSem(d.data)] + ' ' + br(d.data) + ' ' + 'às' + ' ' + d.hora;
    return 'Olá! Quero agendar na Maia\'s Garage:\n' +
      '• ' + d.s.nome + ' (' + 'duração aproximada' + ' ' + duracaoTxt(d.s.min) + ')\n' +
      '• ' + 'Carro' + ': ' + d.carro + ' (' + PORTES[d.porte] + ')\n' +
      '• ' + 'Dia e hora' + ': ' + dt + '\n' +
      '• ' + 'Nome' + ': ' + d.nome + '\n' + '• ' + 'Telefone' + ': ' + d.tel +
      (d.obs ? '\n• ' + 'Observações' + ': ' + d.obs : '');
  }
  function linkWhats(d) { return 'https://wa.me/' + C.whatsapp + '?text=' + encodeURIComponent(msgWhats(d)); }
  function mostraOk(d) {
    elOk.innerHTML = '';
    var p = document.createElement('p'); p.className = 'ag-ok-t';
    p.textContent = T('Quase lá! Toque em enviar no WhatsApp para a Maia\'s Garage confirmar o seu horário.');
    elOk.appendChild(p);
    var a1 = document.createElement('a'); a1.className = 'btn btn-y'; a1.href = linkWhats(d); a1.target = '_blank'; a1.rel = 'noopener noreferrer';
    a1.textContent = T('Abrir o WhatsApp');
    var w = document.createElement('div'); w.className = 'ag-ok-b'; w.appendChild(a1); elOk.appendChild(w);
    elOk.hidden = false; elOk.setAttribute('tabindex', '-1'); elOk.focus();
    return a1.href;
  }

  f.addEventListener('submit', function (e) {
    e.preventDefault(); limpaErro(); elOk.hidden = true;
    if (f.querySelector('[name=site]').value) return; /* campo isca: robôs */
    var d = dadosForm();
    if (!d.s) return erro('Escolha o tipo de lavagem.', f.querySelector('input[name=servico]'));
    if (!d.porte) return erro('Escolha o porte do carro.', f.querySelector('[name=porte]'));
    if (d.carro.length < 2) return erro('Informe o modelo do carro.', f.querySelector('[name=carro]'));
    if (!d.data) return erro('Escolha o dia.', elData);
    if (!d.hora) return erro('Escolha o horário.', elHoras.querySelector('input'));
    if (d.nome.length < 2) return erro('Informe o seu nome.', f.querySelector('[name=nome]'));
    if (d.tel.length < 10 || d.tel.length > 13) return erro('Informe um WhatsApp com DDD.', f.querySelector('[name=tel]'));
    if (!f.querySelector('[name=aceite]').checked) return erro('Marque que está de acordo com a Política de Privacidade.', f.querySelector('[name=aceite]'));
    var url = mostraOk(d);
    try { window.open(url, '_blank', 'noopener'); } catch (x) { /* se o navegador bloquear, o botão acima abre */ }
  });

  f.addEventListener('change', function (e) {
    if (e.target.name === 'servico') { atualizaInfo(); desenhaDatas(); desenhaHoras(); }
    if (e.target.id === 'ag-data') desenhaHoras();
  });
  document.addEventListener('maias-idioma', function () { atualizaInfo(); var v = elData.value; desenhaDatas(); elData.value = v; desenhaHoras(); });

  /* botões do site que pré-selecionam o serviço */
  [].forEach.call(document.querySelectorAll('[data-servico]'), function (a) {
    a.addEventListener('click', function () {
      var r = f.querySelector('input[name=servico][value=' + a.getAttribute('data-servico') + ']');
      if (r) { r.checked = true; r.dispatchEvent(new Event('change', { bubbles: true })); }
    });
  });
  atualizaInfo(); desenhaDatas(); desenhaHoras();
})();
