(function () {
  'use strict';
  // Número do WhatsApp: deixado vazio de propósito (modelo). Exemplo: '5511999999999'
  var WHATSAPP = '';
  var base = 'https://wa.me/' + WHATSAPP + '?text=';
  var d = document;
  d.documentElement.classList.add('js');

  function $(s, r) { return (r || d).querySelector(s); }
  function $$(s, r) { return Array.prototype.slice.call((r || d).querySelectorAll(s)); }
  function link(txt) { return base + encodeURIComponent(txt); }

  // botões de WhatsApp com mensagem
  $$('[data-wa]').forEach(function (a) { a.href = link(a.getAttribute('data-wa')); a.target = '_blank'; a.rel = 'noopener'; });

  // entrada suave
  var revs = $$('.rev');
  if ('IntersectionObserver' in window) {
    var io = new IntersectionObserver(function (es) {
      es.forEach(function (e) { if (e.isIntersecting) { e.target.classList.add('in'); io.unobserve(e.target); } });
    }, { threshold: 0.12 });
    revs.forEach(function (r) { io.observe(r); });
  } else { revs.forEach(function (r) { r.classList.add('in'); }); }

  // cabeçalho some ao descer (celular/tablet)
  var topo = $('#topo'), ult = 0;
  window.addEventListener('scroll', function () {
    var y = window.pageYOffset;
    if (window.innerWidth <= 1040 && $('#gaveta').hidden) {
      topo.classList.toggle('some', y > ult && y > 120);
    } else { topo.classList.remove('some'); }
    ult = y;
  }, { passive: true });

  // menu: item ativo
  var links = $$('.topo-links a');
  var secs = links.map(function (a) { var h = a.getAttribute('href'); return h.charAt(0) === '#' ? $(h) : null; });
  function marca() {
    var y = window.pageYOffset + 140, at = 0;
    secs.forEach(function (s, i) { if (s && s.offsetTop <= y) at = i; });
    links.forEach(function (a, i) { if (a.getAttribute('aria-current')) return; a.classList.toggle('on', i === at && !!secs[i]); });
  }
  if (!$('#agenda-app')) { window.addEventListener('scroll', marca, { passive: true }); marca(); }

  // gaveta
  var gav = $('#gaveta'), bur = $('.burger'), antes = null;
  function abre() { antes = d.activeElement; gav.hidden = false; bur.setAttribute('aria-expanded', 'true'); d.body.style.overflow = 'hidden'; $('.gaveta-x').focus(); }
  function fecha() { gav.hidden = true; bur.setAttribute('aria-expanded', 'false'); d.body.style.overflow = ''; if (antes) antes.focus(); }
  bur.addEventListener('click', abre);
  $$('[data-fechar]').forEach(function (b) { b.addEventListener('click', fecha); });
  $$('.gaveta-painel a').forEach(function (a) { a.addEventListener('click', function () { gav.hidden = true; bur.setAttribute('aria-expanded', 'false'); d.body.style.overflow = ''; }); });
  d.addEventListener('keydown', function (e) {
    if (gav.hidden) return;
    if (e.key === 'Escape') { fecha(); return; }
    if (e.key === 'Tab') {
      var f = $$('button, a[href]', $('.gaveta-painel')), p = f[0], u = f[f.length - 1];
      if (e.shiftKey && d.activeElement === p) { e.preventDefault(); u.focus(); }
      else if (!e.shiftKey && d.activeElement === u) { e.preventDefault(); p.focus(); }
    }
  });

  // ---------- agenda de demonstração (página agenda.html) ----------
  if ($('#agenda-app')) {
  var LOCAIS = {
    santoli: { nome: 'Santoli', dias: [1, 3, 5] },
    care: { nome: 'Espaço Care – Saúde e Bem-Estar', dias: [2, 4] }
  };
  var HORAS = ['08:00', '09:00', '10:00', '11:00', '14:00', '15:00', '16:00', '17:00'];
  var MESES = ['janeiro', 'fevereiro', 'março', 'abril', 'maio', 'junho', 'julho', 'agosto', 'setembro', 'outubro', 'novembro', 'dezembro'];
  var DSEM = ['domingo', 'segunda-feira', 'terça-feira', 'quarta-feira', 'quinta-feira', 'sexta-feira', 'sábado'];
  var hoje = new Date(); hoje.setHours(0, 0, 0, 0);
  var st = { local: 'santoli', ano: hoje.getFullYear(), mes: hoje.getMonth(), dia: null, hora: null };
  var elDias = $('#cal-dias'), elMes = $('#cal-mes'), elHoras = $('#horas'), btnOk = $('#ag-ok'), inNome = $('#ag-nome');

  function ocupado(dt, i) { return (dt.getDate() * 7 + i * 3 + dt.getMonth()) % 5 === 0; }
  function livre(dt) { return dt >= hoje && LOCAIS[st.local].dias.indexOf(dt.getDay()) > -1; }

  function desenhaCal() {
    elMes.textContent = MESES[st.mes] + ' de ' + st.ano;
    $('#cal-ant').disabled = (st.ano === hoje.getFullYear() && st.mes === hoje.getMonth());
    elDias.innerHTML = '';
    var prim = new Date(st.ano, st.mes, 1), n = new Date(st.ano, st.mes + 1, 0).getDate();
    for (var v = 0; v < prim.getDay(); v++) elDias.appendChild(d.createElement('i'));
    for (var k = 1; k <= n; k++) {
      var dt = new Date(st.ano, st.mes, k), b = d.createElement('button');
      b.type = 'button'; b.textContent = k;
      var ok = livre(dt);
      b.disabled = !ok;
      if (ok) b.classList.add('livre');
      b.setAttribute('aria-label', k + ' de ' + MESES[st.mes] + ', ' + DSEM[dt.getDay()] + (ok ? '' : ', indisponível'));
      b.setAttribute('aria-pressed', st.dia === k ? 'true' : 'false');
      (function (kk) { b.addEventListener('click', function () { st.dia = kk; st.hora = null; desenhaCal(); desenhaHoras(); atualiza(); }); })(k);
      elDias.appendChild(b);
    }
  }
  function dataSel() { return st.dia ? new Date(st.ano, st.mes, st.dia) : null; }
  function desenhaHoras() {
    var dt = dataSel(); elHoras.innerHTML = '';
    var tx = $('#ag-dia-txt');
    if (!dt) { tx.textContent = ''; elHoras.innerHTML = '<p class="horas-vazio">Escolha um dia para ver os horários.</p>'; return; }
    tx.textContent = '· ' + DSEM[dt.getDay()] + ', ' + st.dia + ' de ' + MESES[st.mes];
    HORAS.forEach(function (h, i) {
      var b = d.createElement('button'); b.type = 'button'; b.textContent = h;
      var oc = ocupado(dt, i); b.disabled = oc;
      b.setAttribute('aria-label', h + (oc ? ', indisponível' : ''));
      b.setAttribute('aria-pressed', st.hora === h ? 'true' : 'false');
      b.addEventListener('click', function () { st.hora = h; desenhaHoras(); atualiza(); });
      elHoras.appendChild(b);
    });
  }
  function atualiza() { btnOk.disabled = !(st.dia && st.hora); }

  $$('input[name="ag-local"]').forEach(function (r) {
    r.addEventListener('change', function () { st.local = r.value; st.dia = null; st.hora = null; desenhaCal(); desenhaHoras(); atualiza(); });
  });
  $('#cal-ant').addEventListener('click', function () { st.mes--; if (st.mes < 0) { st.mes = 11; st.ano--; } st.dia = null; st.hora = null; desenhaCal(); desenhaHoras(); atualiza(); });
  $('#cal-prox').addEventListener('click', function () { st.mes++; if (st.mes > 11) { st.mes = 0; st.ano++; } st.dia = null; st.hora = null; desenhaCal(); desenhaHoras(); atualiza(); });

  function escolheLocal(id) {
    var r = $('input[name="ag-local"][value="' + id + '"]'); if (r) { r.checked = true; r.dispatchEvent(new Event('change')); }
  }

  $('#ag-form').addEventListener('submit', function (e) {
    e.preventDefault();
    var er = $('#ag-erro'), nome = inNome.value.trim();
    if (!st.dia || !st.hora) { er.textContent = 'Escolha o dia e o horário.'; er.hidden = false; return; }
    if (nome.length < 3) { er.textContent = 'Digite seu nome completo.'; er.hidden = false; inNome.setAttribute('aria-invalid', 'true'); inNome.focus(); return; }
    er.hidden = true; inNome.removeAttribute('aria-invalid');
    var dt = dataSel(), loc = LOCAIS[st.local].nome;
    var quando = DSEM[dt.getDay()] + ', ' + st.dia + ' de ' + MESES[st.mes] + ', às ' + st.hora;
    $('#ag-resumo').textContent = nome + ', sua consulta ficou reservada para ' + quando + ', em ' + loc + '.';
    $('#ag-wa').href = link('Olá, sou ' + nome + '. Gostaria de confirmar minha consulta: ' + quando + ', em ' + loc + '.');
    $('#ag-wa').target = '_blank'; $('#ag-wa').rel = 'noopener';
    $('#ag-form').hidden = true; $('#ag-conf').hidden = false; $('#ag-conf').focus();
  });
  $('#ag-novo').addEventListener('click', function () {
    st.dia = null; st.hora = null; inNome.value = '';
    $('#ag-conf').hidden = true; $('#ag-form').hidden = false;
    desenhaCal(); desenhaHoras(); atualiza();
  });
  desenhaCal(); desenhaHoras(); atualiza();

  var q = /[?&]local=(santoli|care)/.exec(location.search); if (q) escolheLocal(q[1]);
  }

  // ---------- formulário de contato -> WhatsApp ----------
  if ($('#form-contato')) {
  $('#form-contato').addEventListener('submit', function (e) {
    e.preventDefault();
    var f = e.target, er = $('#ct-erro');
    var nome = f.nome.value.trim(), idade = f.idade.value.trim(), obj = f.objetivo.value;
    f.nome.removeAttribute('aria-invalid'); f.idade.removeAttribute('aria-invalid');
    if (nome.length < 2) { er.textContent = 'Digite seu nome.'; er.hidden = false; f.nome.setAttribute('aria-invalid', 'true'); f.nome.focus(); return; }
    if (!/^\d{1,3}$/.test(idade) || +idade < 1 || +idade > 120) { er.textContent = 'Digite a idade com números (ex.: 32).'; er.hidden = false; f.idade.setAttribute('aria-invalid', 'true'); f.idade.focus(); return; }
    er.hidden = true;
    var msg = 'Olá, meu nome é ' + nome + ', tenho ' + idade + ' anos e gostaria de marcar uma consulta com a nutricionista Beatriz Tessitore.' + (obj ? ' Meu objetivo: ' + obj + '.' : '');
    window.open(link(msg), '_blank', 'noopener');
  });
  }
})();
