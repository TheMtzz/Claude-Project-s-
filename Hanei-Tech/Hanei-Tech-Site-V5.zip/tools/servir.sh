cd "$(dirname "$0")/.." && python3 -m http.server 8790 >/dev/null 2>&1
