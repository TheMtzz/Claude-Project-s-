import asyncio
from playwright.async_api import async_playwright
B='http://localhost:8790'
CH='/opt/pw-browsers/chromium-1194/chrome-linux/chrome'
async def main():
    async with async_playwright() as p:
        b=await p.chromium.launch(executable_path=CH,args=['--no-sandbox'])
        for w,h,tag in [(1440,900,'pc'),(1024,768,'tab'),(390,844,'cel')]:
            ctx=await b.new_context(viewport={'width':w,'height':h},is_mobile=w<800,has_touch=w<800)
            pg=await ctx.new_page()
            await pg.goto(B+'/'); await pg.wait_for_timeout(400)
            await pg.add_style_tag(content='.js [data-sobe]{opacity:1!important;transform:none!important}')
            await pg.evaluate("window.scrollTo(0,0)")
            await pg.screenshot(path=f'/tmp/p-{tag}-topo.png')
            for sec in ['produtos','quem-somos']:
                el=pg.locator('#'+sec); await el.scroll_into_view_if_needed(); await pg.wait_for_timeout(500)
                await el.screenshot(path=f'/tmp/p-{tag}-{sec}.png')
            for slug in ['gestao-de-estoque','agendamento-online']:
                await pg.goto(B+f'/produtos/{slug}/'); await pg.wait_for_timeout(300)
                await pg.add_style_tag(content='.js [data-sobe]{opacity:1!important;transform:none!important}')
                abas=await pg.locator('.pp-aba').count()
                for i in range(abas):
                    await pg.locator('.pp-aba').nth(i).click(); await pg.wait_for_timeout(200)
                    await pg.locator('.janela').screenshot(path=f'/tmp/p-{tag}-{slug}-{i}.png')
                await pg.screenshot(path=f'/tmp/p-{tag}-{slug}-pagina.png',full_page=True)
            await ctx.close()
        await b.close()
asyncio.run(main())
