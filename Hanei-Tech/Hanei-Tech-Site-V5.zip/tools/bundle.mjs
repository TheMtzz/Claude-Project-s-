// Junta js/modelos.js + js/site.js (+ js/produtos.js à parte) em js/app.js, sem módulos (funciona em file://)
import { readFileSync, writeFileSync } from 'node:fs';
const r = (f) => readFileSync(new URL(`../js/${f}`, import.meta.url), 'utf8');
const modelos = r('modelos.js').replace(/^export /gm, '');
const site = r('site.js').replace(/^import .*$/gm, '');
writeFileSync(new URL('../js/app.js', import.meta.url),
`/* Gerado por tools/bundle.mjs a partir de js/modelos.js e js/site.js. Edite os originais. */
(function () {
'use strict';
${modelos}
${site}
})();
`);
console.log('app.js ok');
