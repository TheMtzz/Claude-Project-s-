// Gera as páginas /produtos/<slug>/index.html
import { readFileSync, writeFileSync, mkdirSync } from 'node:fs';

const WA = '5511992315202';
const wa = (t) => `https://wa.me/${WA}?text=${encodeURIComponent(t)}`;
const MSG = 'Olá, bom dia, gostaria de fazer um orçamento para sites.';

// símbolo do letreiro (copiado da página inicial)
const home = readFileSync(new URL('../index.html', import.meta.url), 'utf8');
const defs = home.slice(home.indexOf('<svg width="0"'), home.indexOf('</symbol></svg>') + '</symbol></svg>'.length);

const pagina = ({ slug, titulo, descricao, rotulo, h1, lead, msg, abas, telas, recursos, fim, nota, existente, dominio }) => `<!doctype html>
<html lang="pt-BR">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<title>${titulo} · Hanei Tech</title>
<meta name="description" content="${descricao}">
<meta name="theme-color" content="#03050C">
<meta property="og:type" content="website">
<meta property="og:title" content="${titulo} · Hanei Tech">
<meta property="og:description" content="${descricao}">
<meta property="og:locale" content="pt_BR">
<link rel="icon" href="../../favicon.svg" type="image/svg+xml">
<link rel="stylesheet" href="../../css/fonts.css">
<link rel="stylesheet" href="../../css/site.css">
<link rel="stylesheet" href="../../css/produtos.css">
</head>
<body>
${defs}
<a class="pular" href="#conteudo">Pular para o conteúdo</a>
<div class="paisagem" aria-hidden="true"><div class="paisagem-escuro" style="opacity:.86"></div></div>
<header class="topo topo--simples">
  <a class="topo-marca" href="../../" aria-label="Hanei Tech, início"><svg class="marca" viewBox="0 0 1084 100" aria-hidden="true"><use href="#marca"/></svg></a>
  <nav class="topo-links" aria-label="Principal">
    <a href="../../">Início</a>
    <a href="../../#produtos">Produtos</a>
    <a href="../../#contato">Contato</a>
  </nav>
  <a class="botao-contorno topo-conversar" href="${wa(MSG)}" data-wa="${MSG}">Vamos Conversar <svg class="seta" viewBox="0 0 20 20" aria-hidden="true"><path d="M4 10h11M11 5l5 5-5 5"/></svg></a>
</header>
<main id="conteudo" class="pp-main">
  <section class="pp-hero" aria-labelledby="pp-h1">
    <div>
      <p class="pp-rotulo">${rotulo}</p>
      <h1 id="pp-h1">${h1}</h1>
    </div>
    <div class="pp-hero-texto">
      <p>${lead}</p>
      <div class="pp-acoes">
        <a class="botao" href="${wa(msg)}" data-wa="${msg}">Pedir orçamento</a>
        <a class="link" href="#telas">Ver as telas <span aria-hidden="true">↓</span></a>
      </div>
    </div>
  </section>
  <section class="pp-demo" id="telas" aria-labelledby="pp-demo-t">
    <div class="pp-demo-topo">
      <h2 id="pp-demo-t">Telas de exemplo</h2>
      <div class="pp-abas" role="tablist" aria-label="Escolha a tela">
        ${abas.map(([id, nome], i) => `<button type="button" role="tab" class="pp-aba" id="aba-${id}" aria-controls="tela-${id}" aria-selected="${i === 0}"${i ? ' tabindex="-1"' : ''}>${nome}</button>`).join('\n        ')}
      </div>
    </div>
    <div class="janela" data-ui>
      <div class="janela-barra" aria-hidden="true"><i></i><i></i><i></i><span>${dominio || 'seunegocio.com.br'}</span></div>
      ${telas.map(([id, html], i) => `<div class="tela" id="tela-${id}" role="tabpanel" aria-labelledby="aba-${id}"${i ? ' hidden' : ''}>${html}</div>`).join('\n      ')}
    </div>
    <p class="pp-nota">${nota}</p>
  </section>
  ${existente ? `<section class="pp-exist" id="modelo-existente" aria-labelledby="pp-ex-t">
    <div class="pp-exist-topo">
      <div>
        <p class="pp-rotulo">Modelo existente</p>
        <h2 id="pp-ex-t">${existente.nome}</h2>
        <p>${existente.texto}</p>
      </div>
      <a class="botao" href="${existente.url}" target="_blank" rel="noopener">Visitar site <svg class="seta" viewBox="0 0 20 20" aria-hidden="true"><path d="M4 10h11M11 5l5 5-5 5"/></svg></a>
    </div>
    <ul class="pp-exist-telas">
      ${existente.imgs.map(([f, t]) => `<li><a href="${existente.url}" target="_blank" rel="noopener"><img src="../../img/${f}.webp" width="1440" height="900" alt="${t}" loading="lazy"></a><span>${t}</span></li>`).join('\n      ')}
    </ul>
    <p class="pp-exist-chamada">${existente.chamada}</p>
    <ul class="pp-exist-itens">${existente.itens.map((i) => `<li>${i}</li>`).join('')}</ul>
  </section>` : ''}
  <section class="pp-recursos" aria-labelledby="pp-rec-t">
    <h2 id="pp-rec-t">O que vem no sistema</h2>
    ${recursos.map(([t, d], i) => `<div class="pp-recurso"><b>0${i + 1}</b><h3>${t}</h3><p>${d}</p></div>`).join('\n    ')}
  </section>
  <section class="pp-fim" aria-labelledby="pp-fim-t">
    <h2 id="pp-fim-t">${fim[0]}</h2>
    <p>${fim[1]}</p>
    <a class="botao" href="${wa(msg)}" data-wa="${msg}">Pedir orçamento no WhatsApp</a>
  </section>
</main>
<footer class="pp-rodape">
  <span>© 2026 <span translate="no">Hanei Tech</span> · As telas mostradas usam dados fictícios.</span>
  <a href="../../#produtos">Voltar para os produtos</a>
</footer>
<script src="../../js/produtos.js" defer></script>
</body>
</html>
`;

// ───────── Gestão de estoque ─────────
const lado = (ativo) => `<aside class="app-lado" aria-hidden="true">
  <div class="app-loja">Bela Vista Cosméticos<small>Loja de produtos de beleza</small></div>
  ${['Painel', 'Produtos', 'Estoque', 'Clientes', 'Usuários'].map((n) => `<span${n === ativo ? ' data-on' : ''}>${n}</span>`).join('')}
  <span class="app-sair">Sair</span>
</aside>`;

const estoqueLinhas = [
  ['Shampoo Hidratante 300 ml', 'Cabelo', 84, 30, 'ok'],
  ['Máscara de Reconstrução 500 g', 'Cabelo', 41, 25, 'ok'],
  ['Óleo Reparador 60 ml', 'Cabelo', 18, 20, 'baixo'],
  ['Esmalte Rosé Fosco', 'Unhas', 126, 40, 'ok'],
  ['Tinta Castanho 6.0', 'Coloração', 7, 15, 'critico'],
  ['Pó Descolorante 500 g', 'Coloração', 12, 12, 'baixo'],
  ['Escova Térmica Cerâmica', 'Acessórios', 33, 10, 'ok']
];
const selo = { ok: 'Em dia', baixo: 'Baixo', critico: 'Crítico' };
const maximo = 130;

const telaEntrar = `<div class="app-entrar">
  <div class="app-entrar-caixa">
    <div class="app-entrar-form">
      <div class="app-entrar-tabs"><span>Entrar</span><span data-on>Criar conta</span></div>
      <h3>Crie o acesso da sua loja</h3>
      <label class="app-campo"><span>Seu nome</span><span>Mariana Souza</span></label>
      <label class="app-campo"><span>E-mail</span><span>mariana@belavista.com.br</span></label>
      <div class="app-duas">
        <label class="app-campo"><span>Nome da loja</span><span>Bela Vista Cosméticos</span></label>
        <label class="app-campo"><span>Senha</span><span>••••••••••</span></label>
      </div>
      <span class="app-btn" style="justify-content:center">Criar minha loja</span>
      <p class="app-aviso">Cada loja tem os seus próprios usuários, produtos e clientes.</p>
    </div>
    <div class="app-entrar-lado">
      <h3>Tudo da sua loja num só lugar</h3>
      <ul><li>Cadastro de produtos com preço e estoque mínimo</li><li>Cadastro de clientes e histórico de compras</li><li>Usuários com acesso para quem trabalha com você</li><li>Aviso quando um produto está acabando</li></ul>
    </div>
  </div>
</div>`;

const telaProdutos = `<div class="app">
  ${lado('Produtos')}
  <div class="app-corpo">
    <div class="app-titulo"><h3>Produtos</h3><span class="app-btn">+ Novo produto</span></div>
    <div class="app-cols">
      <div class="app-card app-form">
        <h3>Cadastrar produto</h3>
        <label class="app-campo"><span>Nome do produto</span><span>Óleo Reparador 60 ml</span></label>
        <div class="app-duas">
          <label class="app-campo"><span>Categoria</span><span>Cabelo</span></label>
          <label class="app-campo"><span>Preço de venda</span><span>R$ 39,90</span></label>
        </div>
        <div class="app-duas">
          <label class="app-campo"><span>Quantidade inicial</span><span>40</span></label>
          <label class="app-campo"><span>Estoque mínimo</span><span>20</span></label>
        </div>
        <span class="app-btn" style="justify-content:center">Salvar produto</span>
      </div>
      <div class="app-card">
        <table class="app-tabela">
          <thead><tr><th>Produto</th><th class="esconde">Categoria</th><th class="num">Preço</th><th class="num">Qtd.</th></tr></thead>
          <tbody>
            <tr><td>Shampoo Hidratante 300 ml</td><td class="esconde">Cabelo</td><td class="num">R$ 42,90</td><td class="num">84</td></tr>
            <tr><td>Máscara de Reconstrução 500 g</td><td class="esconde">Cabelo</td><td class="num">R$ 79,90</td><td class="num">41</td></tr>
            <tr><td>Óleo Reparador 60 ml</td><td class="esconde">Cabelo</td><td class="num">R$ 39,90</td><td class="num">18</td></tr>
            <tr><td>Esmalte Rosé Fosco</td><td class="esconde">Unhas</td><td class="num">R$ 12,90</td><td class="num">126</td></tr>
            <tr><td>Tinta Castanho 6.0</td><td class="esconde">Coloração</td><td class="num">R$ 24,90</td><td class="num">7</td></tr>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div>`;

const telaEstoque = `<div class="app">
  ${lado('Estoque')}
  <div class="app-corpo">
    <div class="app-titulo"><h3>Estoque</h3><span class="app-btn app-btn--claro">Registrar entrada</span></div>
    <div class="app-kpis">
      <div class="app-kpi"><small>Produtos cadastrados</small><b>128</b></div>
      <div class="app-kpi"><small>Itens em estoque</small><b>2.340</b></div>
      <div class="app-kpi app-kpi--alerta"><small>Abaixo do mínimo</small><b>3</b></div>
    </div>
    <div class="app-card">
      <table class="app-tabela">
        <thead><tr><th>Produto</th><th class="esconde">Categoria</th><th>Quantidade</th><th class="num esconde">Mínimo</th><th>Situação</th></tr></thead>
        <tbody>
          ${estoqueLinhas.map(([n, c, q, min, s]) => `<tr><td>${n}</td><td class="esconde">${c}</td><td><b style="font-variant-numeric:tabular-nums">${q}</b><span class="app-barra app-barra--${s}"><i style="width:${Math.round(q / maximo * 100)}%"></i></span></td><td class="num esconde">${min}</td><td><span class="app-selo app-selo--${s}">${selo[s]}</span></td></tr>`).join('\n          ')}
        </tbody>
      </table>
    </div>
  </div>
</div>`;

const clientes = [
  ['Aline Prado', '(11) 9 8123-4410', '12/10', 'R$ 486,70'],
  ['Studio Cabelos & Cia', '(11) 9 7741-2093', '09/10', 'R$ 2.130,00'],
  ['Renata Duarte', '(11) 9 9317-5521', '03/10', 'R$ 218,40'],
  ['Espaço Lívia Nails', '(11) 9 6650-8742', '28/09', 'R$ 1.074,90'],
  ['Cláudia Menezes', '(11) 9 8890-1167', '21/09', 'R$ 129,80']
];
const telaClientes = `<div class="app">
  ${lado('Clientes')}
  <div class="app-corpo">
    <div class="app-titulo"><h3>Clientes</h3><span class="app-btn">+ Novo cliente</span></div>
    <div class="app-cols">
      <div class="app-card app-form">
        <h3>Cadastrar cliente</h3>
        <label class="app-campo"><span>Nome</span><span>Aline Prado</span></label>
        <label class="app-campo"><span>WhatsApp</span><span>(11) 9 8123-4410</span></label>
        <label class="app-campo"><span>Observações</span><span>Compra coloração todo mês</span></label>
        <span class="app-btn" style="justify-content:center">Salvar cliente</span>
      </div>
      <div class="app-card">
        <table class="app-tabela">
          <thead><tr><th>Cliente</th><th class="esconde">WhatsApp</th><th>Última compra</th><th class="num">Total</th></tr></thead>
          <tbody>${clientes.map(([n, t, u, v]) => `<tr><td>${n}</td><td class="esconde">${t}</td><td>${u}</td><td class="num">${v}</td></tr>`).join('')}</tbody>
        </table>
      </div>
    </div>
  </div>
</div>`;

// ───────── Agendamento online ─────────
const telaSite = `<div class="sl">
  <div class="sl-topo"><b>Espaço Vitta</b><nav><span>Nossa história</span><span>Serviços</span><span>Agenda</span><span>Contato</span></nav><span class="sl-botao">Agendar horário</span></div>
  <div class="sl-hero">
    <div>
      <h3>Cuidado que você sente, horário que você escolhe</h3>
      <p>Cabelo, barba e unhas num só lugar. Veja a agenda, escolha o profissional e marque o seu horário em poucos toques.</p>
      <div class="sl-acoes"><span class="sl-botao">Ver agenda</span><span class="sl-botao sl-botao--claro">Falar no WhatsApp</span></div>
    </div>
    <div class="sl-historia"><h4>Nossa história</h4><p>O Espaço Vitta começou com duas cadeiras e uma ideia: atender cada cliente sem pressa. Hoje somos uma equipe de seis profissionais, com o mesmo cuidado do primeiro dia.</p></div>
  </div>
  <div class="sl-faixa"><div><b>6</b>profissionais</div><div><b>12 anos</b>de atendimento</div><div><b>4,9</b>nota dos clientes</div></div>
  <div class="sl-aval">
    <figure><span class="e" role="img" aria-label="5 de 5 estrelas">★★★★★</span><blockquote>Marquei pelo site em um minuto e recebi a confirmação no WhatsApp.</blockquote><figcaption>Paula R.</figcaption></figure>
    <figure><span class="e" role="img" aria-label="5 de 5 estrelas">★★★★★</span><blockquote>Gosto de ver a agenda e escolher o horário que cabe na minha rotina.</blockquote><figcaption>Diego A.</figcaption></figure>
  </div>
</div>`;

const dias = [['Seg', '19'], ['Ter', '20'], ['Qua', '21'], ['Qui', '22'], ['Sex', '23'], ['Sáb', '24']];
// [dia (0=seg), hora inicial, duração em horas, cliente, serviço, profissional, cor]
const marcados = [
  [0, 10, 1, 'Carla M.', 'Corte', 'Ana', ''],
  [0, 14.5, 1, 'Bruno S.', 'Barba', 'Caio', 'b'],
  [2, 9, 2, 'Paula R.', 'Coloração', 'Bia', 'c'],
  [2, 11.5, 1, 'Diego A.', 'Corte', 'Caio', 'b'],
  [2, 16, 1, 'Sônia L.', 'Manicure', 'Bia', 'c'],
  [5, 10, 1.5, 'Marcos T.', 'Corte e barba', 'Caio', 'b']
];
const hh = (h) => `${Math.floor(h)}h${h % 1 ? '30' : ''}`;
const horas = [8, 9, 10, 11, 12, 13, 14, 15, 16, 17];
const grade = `<div class="ag-grade" role="img" aria-label="Agenda da semana: segunda com 2 horários marcados, quarta com 3 e sábado com 1">
  <div></div>${dias.map(([d, n], i) => `<div class="ag-dia" style="grid-column:${i + 2};grid-row:1">${d}<small>${n}</small></div>`).join('')}
  ${horas.map((h, i) => `<div class="ag-hora" style="grid-column:1;grid-row:${i + 2}">${h}h</div><div class="ag-linha" style="grid-row:${i + 2}"></div>`).join('')}
  ${marcados.map(([d, h, dur, c, s, p, cor]) => {
    const ini = (h - 8) * 2; const tam = dur * 2;
    return `<div class="ag-item${cor ? ' ag-item--' + cor : ''}" style="grid-column:${d + 2};grid-row:${2 + Math.floor(ini / 2)} / span ${Math.max(1, Math.ceil(tam / 2))};${ini % 2 ? 'align-self:end;' : ''}"><b>${hh(h)} · ${c}</b>${s} · ${p}</div>`;
  }).join('')}
</div>`;
const nomeDia = ['Segunda, 19', 'Quarta, 21', 'Sábado, 24'];
const lista = `<div class="ag-lista">${[0, 2, 5].map((d, k) => `<div class="ag-dia-lista"><h3>${nomeDia[k]}</h3>${marcados.filter((m) => m[0] === d).map(([_, h, dur, c, s, p, cor]) => `<div class="ag-item${cor ? ' ag-item--' + cor : ''}"><b>${hh(h)} · ${c}</b>${s} · ${p}</div>`).join('')}</div>`).join('')}</div>`;
const telaAgenda = `<div class="app" style="grid-template-columns:1fr">
  <div class="app-corpo">
    <div class="app-titulo"><h3>Agenda · semana de 19 a 24 de out.</h3><div class="ag-filtros"><span data-on>Todos</span><span>Ana</span><span>Bia</span><span>Caio</span></div></div>
    <div class="ag-corpo">
      <div>${grade}${lista}</div>
      <div class="ag-lateral">
        <div class="app-card app-form">
          <h3>Novo agendamento</h3>
          <label class="app-campo"><span>Serviço</span><span>Corte</span></label>
          <label class="app-campo"><span>Profissional</span><span>Ana</span></label>
          <div class="app-duas">
            <label class="app-campo"><span>Dia</span><span>Terça, 20</span></label>
            <label class="app-campo"><span>Horário</span><span>15h</span></label>
          </div>
          <span class="app-btn" style="justify-content:center">Confirmar agendamento</span>
        </div>
        <div class="app-card">
          <div class="ag-status"><span>Salvo na Google Agenda</span><span>Aviso enviado no WhatsApp</span><span>Horário bloqueado para outros clientes</span></div>
        </div>
      </div>
    </div>
  </div>
</div>`;

const telaAviso = `<div class="av">
  <div class="av-celular"><div class="av-chat">
    <header>Avisos da agenda<small>Espaço Vitta</small></header>
    <div class="av-msgs">
      <div class="av-msg"><b>Novo agendamento</b>Paula R. marcou Coloração com a Bia na quarta-feira, às 9h.<small>08:12</small></div>
      <div class="av-msg"><b>Novo agendamento</b>Diego A. marcou Corte com o Caio na quarta-feira, às 11h30.<small>08:47</small></div>
      <div class="av-msg"><b>Lembrete</b>Amanhã, às 9h: Paula R. · Coloração com a Bia.<small>18:00</small></div>
    </div>
  </div></div>
  <div class="av-lado">
    <h3>Cada horário marcado vira um aviso e um evento</h3>
    <ol class="av-passos">
      <li>O cliente escolhe o serviço, o profissional e o horário livre no site.</li>
      <li>O evento aparece na Google Agenda do local, sem ninguém digitar.</li>
      <li>O WhatsApp do responsável recebe o aviso na hora.</li>
    </ol>
    <div class="av-evento"><small>Google Agenda · quarta-feira</small><b>Coloração · Paula R.</b>9h às 11h · com a Bia</div>
  </div>
</div>`;


// ───────── Catálogo online (exemplo: veículos) ─────────
const carroIc = '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M19 17h2c.6 0 1-.4 1-1v-3c0-.9-.7-1.7-1.5-1.9C18.7 10.6 16 10 16 10s-1.3-1.4-2.2-2.3c-.5-.4-1.1-.7-1.8-.7H5c-.6 0-1.1.4-1.4.9l-1.4 2.9A3.7 3.7 0 0 0 2 12v4c0 .6.4 1 1 1h2"/><circle cx="7" cy="17" r="2"/><path d="M9 17h6"/><circle cx="17" cy="17" r="2"/></svg>';
const carros = [
  ['Sedã Executivo 2.0', 'Linha Prime', '2022 · 31.400 km', 'R$ 98.900', 'a'],
  ['SUV Compacto Turbo', 'Linha Urbana', '2021 · 44.200 km', 'R$ 84.500', 'b'],
  ['Hatch 1.0 Completo', 'Linha Urbana', '2023 · 12.800 km', 'R$ 62.900', 'c'],
  ['Picape Cabine Dupla', 'Linha Trabalho', '2022 · 38.900 km', 'R$ 189.900', 'b'],
  ['Cupê Esportivo', 'Linha Prime', '2020 · 27.300 km', 'R$ 214.000', 'a'],
  ['Crossover Híbrido', 'Linha Verde', '2023 · 9.600 km', 'R$ 156.000', 'c']
];
const ladoC = (ativo) => `<aside class="app-lado" aria-hidden="true">
  <div class="app-loja">Prime Motors<small>Concessionária</small></div>
  ${['Painel', 'Veículos', 'Marcas', 'Usuários', 'Relatórios'].map((n) => `<span${n === ativo ? ' data-on' : ''}>${n}</span>`).join('')}
  <span class="app-sair">Sair</span>
</aside>`;
const cvTopo = (ativo) => `<div class="sl-topo"><b>Prime Motors</b><nav><span${ativo === 'c' ? ' data-on' : ''}>Catálogo</span><span${ativo === 'h' ? ' data-on' : ''}>Nossa história</span><span>Localização</span><span>Contato</span></nav><span class="sl-botao">Agendar visita</span></div>`;

const telaCatalogo = `<div class="sl cv">
  ${cvTopo('c')}
  <div class="cv-cab"><div><h3>Catálogo</h3><p>Veículos revisados, com laudo e garantia.</p></div><div class="cv-filtro"><span data-on>Todas as marcas</span><span>Prime</span><span>Urbana</span><span>Trabalho</span><span>Verde</span></div></div>
  <div class="cv-grade">${carros.map(([n, m, d, v, c]) => `<div class="cv-carro"><div class="cv-foto cv-foto--${c}">${carroIc}<em>${m}</em></div><b>${n}</b><small>${d}</small><strong>${v}</strong></div>`).join('')}</div>
</div>`;

const telaHistoria = `<div class="sl cv">
  ${cvTopo('h')}
  <div class="sl-hero">
    <div><h3>Mais de 15 anos ajudando você a escolher bem</h3><p>A Prime Motors nasceu de uma paixão antiga por carros e de uma regra simples: só vender o que a gente compraria. Cada veículo passa por revisão completa antes de chegar ao catálogo.</p>
      <div class="sl-acoes"><span class="sl-botao">Ver catálogo</span><span class="sl-botao sl-botao--claro">Falar no WhatsApp</span></div></div>
    <div class="sl-historia"><h4>Nossos compromissos</h4><p>Laudo cautelar em todos os veículos, financiamento com os principais bancos e garantia de revisão na entrega das chaves.</p></div>
  </div>
  <div class="sl-faixa"><div><b>15 anos</b>de mercado</div><div><b>+2.400</b>carros vendidos</div><div><b>4,9</b>nota dos clientes</div></div>
</div>`;

const telaEntrarC = `<div class="app-entrar">
  <div class="app-entrar-caixa">
    <div class="app-entrar-form">
      <div class="app-entrar-tabs"><span data-on>Entrar</span><span>Ver o site</span></div>
      <h3>Área do funcionário</h3>
      <label class="app-campo"><span>Usuário</span><span>gerente</span></label>
      <label class="app-campo"><span>Senha</span><span>••••••••••</span></label>
      <span class="app-btn" style="justify-content:center">Entrar no sistema</span>
      <p class="app-aviso">Cada pessoa vê só o que o seu cargo permite.</p>
    </div>
    <div class="app-entrar-lado">
      <h3>O estoque da loja num só lugar</h3>
      <ul><li>Cadastro de veículos com várias fotos</li><li>Placa guardada só no sistema, nunca no site</li><li>Marcar como vendido com um clique</li><li>Relatórios de estoque e de vendas em PDF</li></ul>
    </div>
  </div>
</div>`;

const veic = [
  ['Sedã Executivo 2.0', 'Prime', '2022', 'R$ 98.900', 'Disponível', 'ok'],
  ['SUV Compacto Turbo', 'Urbana', '2021', 'R$ 84.500', 'Disponível', 'ok'],
  ['Hatch 1.0 Completo', 'Urbana', '2023', 'R$ 62.900', 'Reservado', 'baixo'],
  ['Picape Cabine Dupla', 'Trabalho', '2022', 'R$ 189.900', 'Disponível', 'ok'],
  ['Cupê Esportivo', 'Prime', '2020', 'R$ 214.000', 'Vendido', 'critico']
];
const telaEstoqueC = `<div class="app">
  ${ladoC('Veículos')}
  <div class="app-corpo">
    <div class="app-titulo"><h3>Estoque de veículos</h3><span class="app-btn">+ Cadastrar veículo</span></div>
    <div class="app-kpis">
      <div class="app-kpi"><small>Veículos em estoque</small><b>12</b></div>
      <div class="app-kpi"><small>Valor em estoque</small><b>R$ 1,3 mi</b></div>
      <div class="app-kpi app-kpi--alerta"><small>Reservados</small><b>2</b></div>
    </div>
    <div class="app-card">
      <table class="app-tabela">
        <thead><tr><th>Veículo</th><th class="esconde">Marca</th><th class="esconde">Ano</th><th class="num">Valor</th><th>Situação</th></tr></thead>
        <tbody>${veic.map(([n, m, a, v, st, k]) => `<tr><td>${n}</td><td class="esconde">${m}</td><td class="esconde">${a}</td><td class="num">${v}</td><td><span class="app-selo app-selo--${k}">${st}</span></td></tr>`).join('')}</tbody>
      </table>
    </div>
  </div>
</div>`;

const telaRelatorio = `<div class="rel-pdf">
  <div class="rel-folha">
    <header><b>Prime Motors</b><span>Relatório de estoque · 23/10/2026</span></header>
    <table class="app-tabela">
      <thead><tr><th>Veículo</th><th>Placa</th><th>Ano</th><th class="num">Valor</th></tr></thead>
      <tbody>${veic.slice(0, 4).map(([n, m, a, v], i) => `<tr><td>${n}</td><td>ABC-${['1A23','4B56','7C89','2D40'][i]}</td><td>${a}</td><td class="num">${v}</td></tr>`).join('')}</tbody>
    </table>
    <footer><span>Total em estoque</span><b>R$ 436.200</b></footer>
  </div>
  <div class="av-lado">
    <h3>Relatórios em PDF, na hora</h3>
    <ol class="av-passos">
      <li>Relatório de estoque com todos os veículos e o valor total.</li>
      <li>Relatório de vendas com o veículo, a placa e o valor de cada venda.</li>
      <li>Fica pronto para imprimir ou enviar ao sócio.</li>
    </ol>
  </div>
</div>`;

const paginas = [
  {
    slug: 'gestao-de-estoque',
    titulo: 'Sistema de gestão de estoque',
    descricao: 'Sistema online para lojas de produtos de beleza: cadastro de produtos, clientes e usuários e controle de estoque, feito pela Hanei Tech.',
    rotulo: 'Produto 02 · Sistema',
    h1: 'Gestão de estoque para a sua loja',
    lead: 'Um sistema online para quem vende produtos de beleza: cadastre produtos, clientes e usuários, e veja quanto tem de cada item sem abrir planilha.',
    msg: 'Olá, bom dia, gostaria de fazer um orçamento para um sistema de gestão de estoque.',
    abas: [['entrar', 'Entrar e criar conta'], ['produtos', 'Produtos'], ['estoque', 'Estoque'], ['clientes', 'Clientes']],
    telas: [['entrar', telaEntrar], ['produtos', telaProdutos], ['estoque', telaEstoque], ['clientes', telaClientes]],
    recursos: [
      ['Cada loja no seu espaço', 'A pessoa cria a conta, cadastra a loja e passa a gerir tudo pelo site, com os dados separados de qualquer outra loja.'],
      ['Produtos e preços', 'Cadastro com categoria, preço de venda, quantidade inicial e estoque mínimo, para cada item da prateleira.'],
      ['Estoque que avisa', 'A quantidade de cada produto aparece em barras e etiquetas. O que está acabando fica destacado.'],
      ['Clientes e usuários', 'Cadastro de clientes com WhatsApp e histórico, e usuários para quem trabalha com você.']
    ],
    fim: ['Quer organizar o estoque da sua loja?', 'Conte o que você vende e como controla hoje. A gente monta o sistema com os campos que a sua loja precisa.'],
    dominio: 'sualoja.haneitech.com.br',
    existente: {
      nome: 'Hanei Usinagem',
      url: 'https://haneiusinagem.netlify.app/',
      texto: 'Um sistema que já existe e funciona: o controle do almoxarifado de uma empresa de usinagem, com mais segurança e melhor desempenho. Abra o site, entre na área do usuário e veja por dentro.',
      imgs: [['usi-entrada', 'Tela de acesso do funcionário'], ['usi-painel', 'Tela principal'], ['usi-usuario', 'Cadastro de usuário'], ['usi-produto', 'Cadastro de produto'], ['usi-estoque', 'Lista de estoque']],
      chamada: 'O controle do seu almoxarifado com mais segurança e melhor desempenho.',
      itens: ['Gerenciamento de estoque sempre atualizado', 'Exportação do estoque em PDF, CSV e Excel', 'Diversos filtros para achar o que você precisa', 'Usuários com acesso separado por função'],
    },
    nota: 'Telas ilustrativas, com dados fictícios, para mostrar como o sistema pode ficar. O sistema final é montado de acordo com a necessidade da sua loja.'
  },
  {
    slug: 'agendamento-online',
    titulo: 'Site com agendamento online',
    descricao: 'Site com história do local, avaliações, botão de WhatsApp e agenda online ligada à Google Agenda, com aviso por WhatsApp. Feito pela Hanei Tech.',
    rotulo: 'Produto 03 · Site com agenda',
    h1: 'Site com agendamento online',
    lead: 'O site conta a história do seu negócio e deixa o cliente ver a agenda e marcar o horário sozinho. Cada agendamento vai para a Google Agenda e chega por aviso no WhatsApp.',
    msg: 'Olá, bom dia, gostaria de fazer um orçamento para um site com agendamento online.',
    abas: [['site', 'Site do local'], ['agenda', 'Agenda'], ['aviso', 'Avisos e Google Agenda']],
    telas: [['site', telaSite], ['agenda', telaAgenda], ['aviso', telaAviso]],
    recursos: [
      ['Site com a sua história', 'Quem vocês são, serviços, avaliações de clientes e botão de WhatsApp, num visual profissional.'],
      ['Agenda online', 'O cliente vê os horários livres, escolhe o serviço e o profissional e confirma sem precisar mandar mensagem.'],
      ['Google Agenda', 'Cada horário marcado vira um evento na agenda do local e o horário fica bloqueado para outros clientes.'],
      ['Aviso por WhatsApp', 'Você recebe a mensagem na hora: quem marcou, qual serviço e em que dia e horário.']
    ],
    fim: ['Quer agenda online no seu negócio?', 'Conte quantos profissionais atendem e quais serviços você oferece. A gente monta a agenda do jeito do seu local.'],
    nota: 'Telas ilustrativas, com dados fictícios, para mostrar como o site e a agenda podem ficar. A ligação com Google Agenda e WhatsApp é configurada junto com você.'
  },
  {
    slug: 'catalogo-online',
    titulo: 'Catálogo online para quem quer vender pelo site',
    descricao: 'Catálogo online com estoque para qualquer negócio que quer vender pelo site: aluguel, materiais, artigos de festa, veículos e mais. Feito pela Hanei Tech.',
    rotulo: 'Produto 04 · Catálogo para vender pelo site',
    h1: 'Catálogo online para quem quer vender pelo site',
    lead: 'Não é só para concessionárias: é um catálogo para qualquer negócio que queira vender ou alugar pelo site, com área interna para cadastrar produtos e acompanhar o estoque.',
    msg: 'Olá, bom dia, gostaria de fazer um orçamento para um catálogo online para vender pelo site.',
    dominio: 'seunegocio.com.br',
    abas: [['catalogo', 'Catálogo'], ['historia', 'Nossa história'], ['entrar', 'Entrada do funcionário'], ['estoque', 'Gestão de estoque'], ['relatorio', 'Relatório em PDF']],
    telas: [['catalogo', telaCatalogo], ['historia', telaHistoria], ['entrar', telaEntrarC], ['estoque', telaEstoqueC], ['relatorio', telaRelatorio]],
    existente: {
      nome: 'Hanei Veículos',
      url: 'https://hanei-veiculos.netlify.app/',
      texto: 'Exemplo de catálogo, feito para veículos, que já existe: catálogo para o cliente e sistema de estoque para a equipe. Abra o site, navegue pelo catálogo e entre na área do funcionário.',
      imgs: [['vei-inicio', 'Tela principal do site'], ['vei-catalogo', 'Catálogo de veículos'], ['vei-entrada', 'Entrada do usuário'], ['vei-estoque', 'Estoque de veículos'], ['vei-relatorio', 'Relatório de estoque gerado']],
      chamada: 'O seu catálogo atualizado, profissional e com a qualidade de grandes marcas e empresas.',
      itens: ['Catálogo com fotos, valor e filtro por categoria', 'Página de cada item com várias fotos', 'Estoque, vendas e usuários num só lugar', 'Relatórios de estoque e de vendas em PDF']
    },
    recursos: [
      ['Catálogo que vende', 'Fotos grandes, valor e detalhes de cada veículo, com filtro por categoria e botão de WhatsApp para pedir o item ou combinar a visita.'],
      ['Estoque atualizado', 'Cadastre, edite e marque como vendido ou indisponível. O que sai do estoque sai do catálogo sozinho.'],
      ['Equipe com acessos', 'Administrador, gerente e funcionário, cada um com as permissões do seu cargo. A placa nunca aparece no site.'],
      ['Relatórios em PDF', 'Estoque e vendas prontos para imprimir ou enviar, com total e valor de cada veículo.']
    ],
    fim: ['Quer o seu catálogo no ar?', 'Conte o que você vende ou aluga e como vende hoje. A gente monta o catálogo e o estoque do jeito do seu negócio, e avalia o que mais você precisar.'],
    nota: 'Telas ilustrativas, com dados fictícios, para mostrar como o catálogo e o sistema podem ficar. O modelo existente abaixo é um site real e funcional.'
  }
];

for (const p of paginas) {
  const dir = new URL(`../produtos/${p.slug}/`, import.meta.url);
  mkdirSync(dir, { recursive: true });
  writeFileSync(new URL('index.html', dir), pagina(p));
}
console.log('produtos ok');
