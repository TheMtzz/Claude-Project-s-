import asyncio, urllib.parse
from playwright.async_api import async_playwright
B='http://localhost:8790'
CH='/opt/pw-browsers/chromium-1194/chrome-linux/chrome'
ok=True
def check(c,msg):
    global ok
    print(('PASS ' if c else 'FAIL ')+msg); ok=ok and c
async def main():
    async with async_playwright() as p:
        b=await p.chromium.launch(executable_path=CH,args=['--no-sandbox'])
        pg=await b.new_page(viewport={'width':1440,'height':900})
        errs=[]; pg.on('pageerror',lambda e: errs.append(str(e)))
        await pg.goto(B+'/'); await pg.wait_for_timeout(400)
        hrefs=await pg.eval_on_selector_all('[data-wa]','els=>els.map(e=>e.href)')
        check(all(h.startswith('https://wa.me/5511992315202?text=') for h in hrefs), f'{len(hrefs)} links WhatsApp com o número')
        t=urllib.parse.unquote(hrefs[0].split('text=')[1]); check(t=='Olá, bom dia, gostaria de fazer um orçamento para sites.','mensagem padrão: '+t)
        # carrossel
        await pg.locator('#produto-landing').scroll_into_view_if_needed()
        x0=await pg.evaluate("document.querySelector('.carrossel-trilho').scrollLeft")
        await pg.click('.carrossel-botao[data-passo="1"]'); await pg.wait_for_timeout(900)
        x1=await pg.evaluate("document.querySelector('.carrossel-trilho').scrollLeft")
        check(x1>x0,'carrossel avança'); 
        for _ in range(4):
            await pg.click('.carrossel-botao[data-passo="1"]',force=True) if not await pg.locator('.carrossel-botao[data-passo="1"]').is_disabled() else None; await pg.wait_for_timeout(700)
        check(await pg.locator('.carrossel-botao[data-passo="1"]').is_disabled(),'botão próximo desativa no fim')
        # prévia: mensagem
        await pg.click('#aba-oficina'); 
        w=await pg.get_attribute('#modelos-whats','href')
        check('oficina' in urllib.parse.unquote(w).lower() and '5511992315202' in w,'prévia oficina: '+urllib.parse.unquote(w.split('text=')[1]))
        # menu ativo Produtos
        await pg.evaluate("document.getElementById('produtos').scrollIntoView()"); await pg.wait_for_timeout(600)
        cur=await pg.eval_on_selector_all('.topo-links a[aria-current="true"]','e=>e.map(x=>x.textContent)')
        check(cur==['Produtos'],f'menu destaca {cur}')
        # páginas de produto: abas e teclado
        for slug,n in [('gestao-de-estoque',4),('agendamento-online',3),('catalogo-online',5)]:
            await pg.goto(B+f'/produtos/{slug}/'); await pg.wait_for_timeout(300)
            await pg.focus('.pp-aba[aria-selected="true"]')
            for i in range(1,n):
                await pg.keyboard.press('ArrowRight')
                vis=await pg.eval_on_selector_all('.tela','e=>e.filter(x=>!x.hidden).length')
                check(vis==1,f'{slug}: aba {i+1} mostra 1 tela')
            await pg.keyboard.press('Home')
            check(await pg.get_attribute('.pp-aba:first-child','aria-selected')=='true',f'{slug}: Home volta à primeira')
        # sem JS
        ctx=await b.new_context(java_script_enabled=False); q=await ctx.new_page()
        await q.goto(B+'/produtos/agendamento-online/')
        check(await q.eval_on_selector_all('.tela','e=>e.every(x=>getComputedStyle(x).display!="none")'),'sem JS: todas as telas aparecem')
        await ctx.close()
        # celular: gaveta
        ctx=await b.new_context(viewport={'width':390,'height':844},is_mobile=True,has_touch=True); m=await ctx.new_page()
        await m.goto(B+'/'); await m.wait_for_timeout(300)
        await m.click('.topo-menu'); 
        links=await m.eval_on_selector_all('#gaveta a','e=>e.map(x=>x.textContent.trim())')
        check('Produtos' in links,f'gaveta: {links}')
        small=await m.evaluate('''()=>[...document.querySelectorAll('#gaveta a,#gaveta button')].filter(e=>{const r=e.getBoundingClientRect();return r.height<44}).length''')
        check(small==0,'alvos de toque >= 44px na gaveta')
        check(not errs,'sem erros de JS '+str(errs))
        await b.close()
    print('TUDO OK' if ok else 'HÁ FALHAS')
asyncio.run(main())
