// Gera as páginas /modelos/<slug>/index.html a partir de js/modelos.js
import { writeFileSync, mkdirSync } from 'node:fs';
import { MODELOS, renderModelo } from '../js/modelos.js';
for (const m of MODELOS) {
  const dir = new URL(`../modelos/${m.slug}/`, import.meta.url);
  mkdirSync(dir, { recursive: true });
  const html = `<!doctype html>
<html lang="pt-BR">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>${m.nome} · modelo de ${m.nicho.toLowerCase()} · Hanei Tech</title>
<meta name="description" content="Modelo de exemplo de site para ${m.nicho.toLowerCase()}, feito pela Hanei Tech. Empresa fictícia.">
<meta name="robots" content="noindex">
<meta name="theme-color" content="${m.cores.fundo}">
<link rel="icon" href="../../favicon.svg" type="image/svg+xml">
<link rel="stylesheet" href="../../css/fonts.css">
<link rel="stylesheet" href="../../css/modelo.css">
<style>html,body{margin:0;background:${m.cores.fundo}}</style>
</head>
<body>
<main>
${renderModelo(m, '', { pagina: true }).trim()}</main>
</body>
</html>
`;
  writeFileSync(new URL('index.html', dir), html);
}
console.log('modelos ok');
