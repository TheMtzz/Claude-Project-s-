import asyncio, sys, json
from playwright.async_api import async_playwright
B='http://localhost:8790'
CH='/opt/pw-browsers/chromium-1194/chrome-linux/chrome'
PAGES=['/','/produtos/gestao-de-estoque/','/produtos/agendamento-online/','/modelos/salao/','/modelos/oficina/']
async def main():
    async with async_playwright() as p:
        b=await p.chromium.launch(executable_path=CH,args=['--no-sandbox'])
        for w,h in [(1440,900),(1280,800),(1100,800),(1024,768),(920,800),(768,1024),(390,844),(360,740)]:
            ctx=await b.new_context(viewport={'width':w,'height':h},is_mobile=w<800,has_touch=w<800)
            pg=await ctx.new_page(); errs=[]
            pg.on('console',lambda m: errs.append(m.text) if m.type in('error','warning') else None)
            pg.on('pageerror',lambda e: errs.append(str(e)))
            pg.on('requestfailed',lambda r: errs.append('FAIL '+r.url))
            for u in PAGES:
                await pg.goto(B+u); await pg.wait_for_timeout(300)
                r=await pg.evaluate('''()=>{const d=document.documentElement;const o=[];
                  document.querySelectorAll('body *').forEach(e=>{const r=e.getBoundingClientRect();if(r.width&&r.right>innerWidth+1&&!e.closest('.carrossel-trilho,.modelos-tela,.janela'))o.push(e.tagName+'.'+e.className)});
                  return {sw:d.scrollWidth,iw:innerWidth,over:o.slice(0,4)}}''')
                bad = r['sw']>r['iw']+1
                print(w,u,'OVERFLOW' if bad else 'ok',r['over'] if bad or r['over'] else '')
            if errs: print(w,'ERRS',errs[:5])
            await ctx.close()
        await b.close()
asyncio.run(main())
