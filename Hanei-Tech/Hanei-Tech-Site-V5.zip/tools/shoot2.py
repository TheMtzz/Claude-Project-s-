import asyncio, sys
from playwright.async_api import async_playwright
from PIL import Image
B='http://localhost:8790'
CH='/opt/pw-browsers/chromium-1194/chrome-linux/chrome'
async def main():
    async with async_playwright() as p:
        b=await p.chromium.launch(executable_path=CH,args=['--no-sandbox'])
        pg=await b.new_page(viewport={'width':1600,'height':1000},device_scale_factor=2)
        for slug,aba,out in [('gestao-de-estoque','estoque','produto-estoque'),('agendamento-online','agenda','produto-agenda')]:
            await pg.goto(f'{B}/produtos/{slug}/'); await pg.wait_for_timeout(500)
            await pg.click(f'#aba-{aba}'); await pg.wait_for_timeout(300)
            await pg.locator('.janela').screenshot(path=f'/tmp/{out}.png')
            im=Image.open(f'/tmp/{out}.png').convert('RGB')
            w,h=im.size; im=im.resize((1600,round(h*1600/w)),Image.LANCZOS)
            im.save(f'img/{out}.webp',quality=88); print(out,im.size)
        for slug in ['salao','restaurante','barbearia','oficina']:
            await pg.goto(f'{B}/modelos/{slug}/'); await pg.wait_for_timeout(400)
            await pg.screenshot(path=f'/tmp/{slug}-full.png',full_page=True)
            im=Image.open(f'/tmp/{slug}-full.png').convert('RGB'); im=im.resize((1600,round(im.size[1]*1600/im.size[0])),Image.LANCZOS); print(slug,im.size)
            im.save(f'img/{slug}-full.webp',quality=86)
        await b.close()
asyncio.run(main())
