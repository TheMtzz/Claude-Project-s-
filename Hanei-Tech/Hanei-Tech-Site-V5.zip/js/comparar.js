(function(){
  var cena=document.getElementById('comp-cena'); if(!cena)return;
  var novo=document.getElementById('comp-novo'),linha=document.getElementById('comp-linha'),alca=document.getElementById('comp-alca');
  var pos=0,arr=false;
  function set(p){
    pos=Math.max(0,Math.min(100,p));
    novo.style.clipPath='inset(0 '+(100-pos)+'% 0 0)';
    linha.style.left=pos+'%';alca.style.left=pos+'%';
    alca.setAttribute('aria-valuenow',Math.round(pos));
    alca.setAttribute('aria-valuetext',(window.HaneiT||function(x){return x})(pos<50?'Mostrando mais do site antigo':'Mostrando mais do site novo'));
  }
  function doX(x){var r=cena.getBoundingClientRect();set((x-r.left)/r.width*100)}
  cena.addEventListener('pointerdown',function(e){arr=true;try{cena.setPointerCapture(e.pointerId)}catch(_){}doX(e.clientX)});
  cena.addEventListener('pointermove',function(e){if(arr)doX(e.clientX)});
  ['pointerup','pointercancel'].forEach(function(t){cena.addEventListener(t,function(){arr=false})});
  alca.addEventListener('keydown',function(e){
    if(e.key==='ArrowRight')set(pos+5);else if(e.key==='ArrowLeft')set(pos-5);else if(e.key==='Home')set(0);else if(e.key==='End')set(100);else return;
    e.preventDefault();
  });
  set(0);
  // convite: uma pequena animação de demonstração, só se o usuário aceitar movimento
  var reduz=window.matchMedia&&window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  if(!reduz&&'IntersectionObserver' in window){
    var feito=false;
    new IntersectionObserver(function(es,ob){
      if(feito||!es[0].isIntersecting)return;feito=true;ob.disconnect();
      var t0=null;(function f(t){if(arr)return;if(t0===null)t0=t;var k=(t-t0)/1400;if(k>=1){set(0);return}set(Math.sin(k*Math.PI)*38);requestAnimationFrame(f)})(performance.now());
    },{threshold:.6}).observe(cena);
  }
})();
