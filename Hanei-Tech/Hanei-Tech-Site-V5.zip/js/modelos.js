// Modelos de exemplo da Hanei Tech.
// Os nomes das empresas são fictícios. O mesmo código desenha:
//  - as páginas /modelos/<slug>/ (exemplos completos),
//  - a prévia ao vivo na seção "Veja o seu site" da página inicial.

export const MODELOS = [
  {
    slug: 'salao',
    nicho: 'Salão de beleza',
    nome: 'Studio Aurora',
    cores: { fundo: '#FBF4F1', tinta: '#3A1F2B', destaque: '#B23A5E', campo: '#F3E1DB', claro: '#FFFFFF' },
    titulo: 'Cabelo, unhas e pele',
    apoio: 'Corte, coloração, escova, manicure e design de sobrancelha. Agende pelo WhatsApp e escolha o seu horário.',
    acao: 'Agendar horário',
    servicos: [
      ['Corte e escova', 'Feminino e masculino, com lavagem e finalização.'],
      ['Coloração', 'Mechas, luzes, retoque de raiz e tonalização.'],
      ['Manicure e pedicure', 'Esmaltação comum, em gel e spa dos pés.'],
      ['Sobrancelha', 'Design com pinça ou linha e aplicação de henna.']
    ],
    marcas: ['Produtos que usamos', ['Wella Professionals', 'Truss', 'OPI']],
    avaliacoes: [
      ['Fiz mechas e ficou do jeito que eu queria. Atendimento muito atencioso do início ao fim.', 'Camila R.'],
      ['Marquei pelo WhatsApp em um minuto e fui atendida no horário combinado.', 'Fernanda L.'],
      ['Ambiente limpo, produtos de qualidade e a unha durou semanas. Voltarei com certeza.', 'Juliana M.']
    ],
    horario: [['Terça a sexta', '9h às 20h'], ['Sábado', '8h às 18h'], ['Domingo e segunda', 'Fechado']]
  },
  {
    slug: 'restaurante',
    nicho: 'Restaurante',
    nome: 'Cantina da Praça',
    cores: { fundo: '#FBF5EC', tinta: '#2B1A12', destaque: '#A61E2E', campo: '#F1E3D3', claro: '#FFFFFF' },
    titulo: 'Comida de casa, feita na hora',
    apoio: 'Almoço executivo, massas frescas e pratos à la carte. Reserve sua mesa ou peça pelo WhatsApp para retirar.',
    acao: 'Reservar mesa',
    servicos: [
      ['Almoço executivo', 'Prato do dia com salada, acompanhamento e suco.'],
      ['Massas frescas', 'Feitas na casa, com molhos de receita própria.'],
      ['Para retirar', 'Peça pelo WhatsApp e retire sem esperar.'],
      ['Eventos', 'Aniversários e confraternizações com cardápio fechado.']
    ],
    marcas: ['Na nossa cozinha', ['Massa feita na casa', 'Ingredientes frescos do dia', 'Azeite extravirgem']],
    avaliacoes: [
      ['O almoço executivo é farto e sai rápido. Virou o nosso lugar de toda sexta.', 'Rafael T.'],
      ['Reservei a mesa pelo WhatsApp e já estava tudo pronto quando chegamos.', 'Patrícia S.'],
      ['A massa fresca é a melhor da região. Fizemos o aniversário da minha mãe aqui.', 'Eduardo A.']
    ],
    horario: [['Terça a sexta', '11h às 15h e 18h às 23h'], ['Sábado e domingo', '11h às 23h'], ['Segunda', 'Fechado']]
  },
  {
    slug: 'barbearia',
    nicho: 'Barbearia',
    nome: 'Navalha Fina',
    cores: { fundo: '#F2EFE8', tinta: '#1D2420', destaque: '#85611F', campo: '#1D2420', claro: '#FFFFFF' },
    titulo: 'Corte e barba no seu horário',
    apoio: 'Corte masculino, barba com toalha quente e acabamento na navalha. Agende pelo WhatsApp e não pegue fila.',
    acao: 'Agendar horário',
    servicos: [
      ['Corte', 'Máquina e tesoura, do clássico ao degradê.'],
      ['Barba', 'Toalha quente, navalha e hidratação.'],
      ['Corte + barba', 'O combo completo com acabamento.'],
      ['Sobrancelha', 'Limpeza e alinhamento na navalha.']
    ],
    marcas: ['Produtos que usamos', ['Reuzel', 'QOD Barber Shop', 'Proraso']],
    avaliacoes: [
      ['Corte no capricho e a barba com toalha quente é outro nível. Saí renovado.', 'Lucas P.'],
      ['Horário marcado é horário cumprido. Zero fila, do jeito que tem que ser.', 'Thiago M.'],
      ['Os produtos são bons e eles explicam como usar em casa. Atendimento nota dez.', 'André C.']
    ],
    horario: [['Terça a sexta', '9h às 20h'], ['Sábado', '8h às 18h'], ['Domingo e segunda', 'Fechado']]
  },
  {
    slug: 'oficina',
    nicho: 'Oficina mecânica',
    nome: 'Ponto Certo',
    cores: { fundo: '#F4F3F0', tinta: '#1C1C1C', destaque: '#B93F14', campo: '#1C1C1C', claro: '#FFFFFF' },
    titulo: 'Seu carro em boas mãos',
    apoio: 'Revisão, freios, alinhamento, balanceamento e troca de óleo Motul, com orçamento antes de qualquer serviço.',
    acao: 'Pedir orçamento',
    servicos: [
      ['Revisão completa', 'Checagem de itens de segurança e fluidos.'],
      ['Freios', 'Pastilhas, discos e fluido de freio.'],
      ['Alinhamento e balanceamento', 'Suspensão revisada, alinhamento 3D e rodas balanceadas.'],
      ['Troca de óleo', 'Óleo Motul e filtros na especificação do fabricante.']
    ],
    marcas: ['Produtos que usamos', ['Motul', 'Bosch', 'Mann-Filter']],
    avaliacoes: [
      ['Mandaram o orçamento pelo WhatsApp antes de mexer em qualquer coisa. Preço justo e serviço no prazo.', 'Marcelo V.'],
      ['Troquei o óleo com Motul e o carro ficou mais silencioso. Explicaram tudo que foi feito.', 'Roberto F.'],
      ['Fiz alinhamento e balanceamento e o volante parou de tremer. Recomendo.', 'Daniela K.']
    ],
    horario: [['Segunda a sexta', '8h às 18h'], ['Sábado', '8h às 12h'], ['Domingo', 'Fechado']]
  }
];

const esc = (s) => String(s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

// Monta o HTML de um modelo. `nome` substitui o nome fictício (prévia ao vivo).
export function renderModelo(modelo, nome, { pagina = false } = {}) {
  const hT = pagina ? 'h1' : 'h3';
  const hS = pagina ? 'h2' : 'h4';
  const m = modelo;
  const n = esc((nome && nome.trim()) || m.nome);
  const c = m.cores;
  const escuro = c.campo === c.tinta;
  return `
<div class="mdl" style="--m-fundo:${c.fundo};--m-tinta:${c.tinta};--m-destaque:${c.destaque};--m-campo:${c.campo};--m-claro:${c.claro};--m-campo-tinta:${escuro ? c.claro : c.tinta}">
  <header class="mdl-topo">
    <span class="mdl-marca" translate="no">${n}</span>
    <nav class="mdl-links"><span>Serviços</span><span>Horários</span><span>Contato</span></nav>
    <span class="mdl-botao mdl-botao--pequeno">${esc(m.acao)}</span>
  </header>
  <section class="mdl-hero">
    <span class="mdl-orbe" aria-hidden="true"></span>
    <div class="mdl-hero-texto">
      <p class="mdl-nicho">${esc(m.nicho)}</p>
      <${hT} class="mdl-titulo">${esc(m.titulo)}</${hT}>
      <p class="mdl-apoio">${esc(m.apoio)}</p>
      <span class="mdl-botao">${esc(m.acao)} pelo WhatsApp</span>
    </div>
    <div class="mdl-pedido">
      <p class="mdl-pedido-titulo">O que você precisa?</p>
      ${m.servicos.map(([t], i) => `<span class="mdl-opcao${i === 0 ? ' mdl-opcao--on' : ''}"><i></i>${esc(t)}</span>`).join('')}
      <span class="mdl-campo-falso">Seu bairro</span>
      <span class="mdl-botao mdl-botao--cheio">Enviar pelo WhatsApp</span>
    </div>
  </section>
  <section class="mdl-servicos">
    ${m.servicos.map(([t, d], i) => `<div class="mdl-servico"><span class="mdl-num">0${i + 1}</span><${hS}>${esc(t)}</${hS}><p>${esc(d)}</p></div>`).join('')}
  </section>
  ${pagina ? `<section class="mdl-horario">
    <${hS}>Horários</${hS}>
    <dl>${m.horario.map(([d, h]) => `<div><dt>${esc(d)}</dt><dd>${esc(h)}</dd></div>`).join('')}</dl>
  </section>` : ''}
  <footer class="mdl-rodape"><span>${n}</span><span>Modelo de exemplo · Hanei Tech</span></footer>
</div>`;
}
