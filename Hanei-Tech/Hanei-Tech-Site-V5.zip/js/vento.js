window.addEventListener("load",function(){(window.requestIdleCallback||setTimeout)(function(){setTimeout(function(){
(function(){
  var pais=document.querySelector('.paisagem'); if(!pais)return;
  var nav=navigator,fraco=(nav.connection&&nav.connection.saveData)||(nav.deviceMemory&&nav.deviceMemory<=2)||(nav.hardwareConcurrency&&nav.hardwareConcurrency<=2);if(fraco)return;var reduz=window.matchMedia&&window.matchMedia('(prefers-reduced-motion: reduce)').matches; if(reduz)return;
  var st=document.createElement('style');
  st.textContent=(window.innerWidth<720?'':'.paisagem{animation:resp 26s ease-in-out infinite alternate;transform-origin:50% 60%;will-change:transform}')+'@keyframes resp{from{transform:scale(1)}to{transform:scale(1.04) translate3d(-.5%,.3%,0)}}'+
   '.nevoa{position:absolute;left:-20%;width:140%;pointer-events:none;background:radial-gradient(50% 50% at 50% 50%,rgba(170,200,255,.14),transparent 70%);'+(window.innerWidth<720?'':'filter:blur(18px);')+'will-change:transform}'+
   '.vento-cv{position:absolute;inset:0;width:100%;height:100%;pointer-events:none}';
  document.head.appendChild(st);
  [[58,24,.9],[70,30,1.2],[80,22,.7]].forEach(function(n){
    var d=document.createElement('div');d.className='nevoa';d.style.top=n[0]+'%';d.style.height=n[1]+'%';
    d.animate([{transform:'translateX(-6%)',opacity:.6},{transform:'translateX(6%)',opacity:1}],{duration:60000/n[2]/5*5/5,direction:'alternate',iterations:Infinity,easing:'ease-in-out'});
    pais.appendChild(d);
  });
  var cv=document.createElement('canvas');cv.className='vento-cv';cv.setAttribute('aria-hidden','true');pais.appendChild(cv);
  var c=cv.getContext('2d'),W,H,dpr=Math.min(1.5,window.devicePixelRatio||1);
  function fit(){W=pais.clientWidth;H=pais.clientHeight;cv.width=W*dpr;cv.height=H*dpr;c.setTransform(dpr,0,0,dpr,0,0)}
  fit();addEventListener('resize',fit);
  var mobile=W<720,N=mobile?6:20,pet=[],est=[];
  // sprites pré-desenhados: só pétalas de cerejeira, rosa muito suave
  var sp=[];for(var k=0;k<3;k++){var o=document.createElement('canvas');o.width=o.height=32;var x=o.getContext('2d');
    var g=x.createRadialGradient(16,16,0,16,16,15);g.addColorStop(0,'rgba(255,240,246,1)');g.addColorStop(1,'rgba(244,170,196,1)');
    x.fillStyle=g;x.translate(16,16);x.rotate(k*.5);x.beginPath();x.moveTo(0,-14);x.bezierCurveTo(13,-10,13,9,0,14);x.bezierCurveTo(-13,9,-13,-10,0,-14);x.fill();
    x.fillStyle='rgba(255,255,255,.35)';x.beginPath();x.ellipse(0,-2,3,7,0,0,6.3);x.fill();sp.push(o)}
  for(var i=0;i<(mobile?24:80);i++)est.push({x:Math.random()*W,y:Math.random()*H*.45,r:Math.random()*1.1+.3,f:Math.random()*6,v:Math.random()*1.4+.5});
  function nova(ini){var z=Math.random();return{x:ini?Math.random()*W:-30-Math.random()*200,y:Math.random()*H*.8,z:z,s:(7+z*13)*(mobile?.8:1),a:Math.random()*6.28,va:(Math.random()-.5)*.04,fase:Math.random()*6.28,vy:.12+z*.3,sp:sp[i%3|0],al:.10+z*.20}}
  for(i=0;i<N;i++){var p0=nova(true);p0.sp=sp[i%3];pet.push(p0)}
  var t0=performance.now(),vis=true,last=0;
  document.addEventListener('visibilitychange',function(){vis=!document.hidden;if(vis)requestAnimationFrame(quadro)});
  function rajada(t){return .5+.4*Math.sin(t*.00035)+.3*Math.max(0,Math.sin(t*.0011+1.7))}
  function quadro(now){
    if(!vis)return;requestAnimationFrame(quadro);
    if(now-last<(mobile?42:33))return;last=now;                    // ~30 quadros/s: leve
    if(document.documentElement.dataset.mov==='off'||document.documentElement.dataset.contraste==='1'||scrollY>innerHeight*1.2){c.clearRect(0,0,W,H);return}   // longe do topo, nada a desenhar
    var t=now-t0,w=rajada(t);c.clearRect(0,0,W,H);
    for(var i=0;i<est.length;i++){var e=est[i],a=.3+.6*Math.abs(Math.sin(t*.001*e.v+e.f));c.fillStyle='rgba(255,255,255,'+(a*.7).toFixed(2)+')';c.fillRect(e.x,e.y,e.r*1.6,e.r*1.6)}
    for(i=0;i<pet.length;i++){var p=pet[i];
      p.fase+=.05+.03*w;p.a+=p.va*(1+w);
      p.x+=(1.3+p.z*3)*w*(mobile?.7:1)+Math.sin(p.fase)*.5;p.y+=p.vy+Math.sin(p.fase*.7+i)*.5*(.4+w*.6);
      if(p.x>W+40||p.y>H+40){var n=nova(false);n.sp=p.sp;pet[i]=n;continue}
      c.save();c.globalAlpha=p.al;c.translate(p.x,p.y);c.rotate(p.a);c.scale(1,.5+.5*Math.abs(Math.sin(p.fase)));c.drawImage(p.sp,-p.s,-p.s,p.s*2,p.s*2);c.restore();
    }
  }
  requestAnimationFrame(quadro);
})();

},4500)})});
