(function(){
  var cena=document.getElementById('cena'),limpo=document.getElementById('limpo'),linha=document.getElementById('linha'),alca=document.getElementById('alca');
  var pos=0,arr=false;
  function set(p){pos=Math.max(0,Math.min(100,p));limpo.style.clipPath='inset(0 '+(100-pos)+'% 0 0)';linha.style.left=pos+'%';alca.style.left=pos+'%';alca.setAttribute('aria-valuenow',Math.round(pos))}
  function doX(x){var r=cena.getBoundingClientRect();set((x-r.left)/r.width*100)}
  cena.addEventListener('pointerdown',function(e){arr=true;try{cena.setPointerCapture(e.pointerId)}catch(_){}doX(e.clientX);e.preventDefault()});
  cena.addEventListener('pointermove',function(e){if(arr)doX(e.clientX)});
  ['pointerup','pointercancel'].forEach(function(t){cena.addEventListener(t,function(){arr=false})});
  alca.addEventListener('keydown',function(e){if(e.key==='ArrowRight')set(pos+5);else if(e.key==='ArrowLeft')set(pos-5);else if(e.key==='Home')set(0);else if(e.key==='End')set(100);else return;e.preventDefault()});
  set(45);
})();
