(function(){
  const el=function(id){return document.getElementById(id)};
  /* ---------- Agenda ---------- */
  function initAgenda(){
    const WA=document.body.getAttribute('data-wa');
    const SEM=['dom','seg','ter','qua','qui','sex','sáb'],SEMF=['domingo','segunda-feira','terça-feira','quarta-feira','quinta-feira','sexta-feira','sábado'];
    const MES=['jan','fev','mar','abr','mai','jun','jul','ago','set','out','nov','dez'];
    const DIAS=21,PASSO=30;
    const dias=el('agDias'),horas=el('agHoras'),vazio=el('agVazio'),res=el('agRes');
    let diaSel=null,horaSel=null;
    const p2=function(n){return String(n).padStart(2,'0')};
    const iso=function(d){return d.getFullYear()+'-'+p2(d.getMonth()+1)+'-'+p2(d.getDate())};
    const fim=function(d){return d.getDay()===0||d.getDay()===6?14:18};
    const slots=function(d){
      const out=[];
      for(let m=9*60;m+PASSO<=fim(d)*60;m+=PASSO)out.push(m);
      return out;
    };
    const livre=function(d,m){
      const agora=new Date();
      if(iso(d)!==iso(agora))return true;
      return m>agora.getHours()*60+agora.getMinutes()+15;
    };
    const lista=[];
    const base=new Date();base.setHours(0,0,0,0);
    for(let i=0;i<DIAS;i++){const d=new Date(base);d.setDate(base.getDate()+i);lista.push(d)}
    const temVaga=function(d){return slots(d).some(function(m){return livre(d,m)})};
    const atualizaRes=function(){
      if(diaSel&&horaSel!==null){
        res.textContent='Selecionado: '+SEMF[diaSel.getDay()]+', '+p2(diaSel.getDate())+'/'+p2(diaSel.getMonth()+1)+'/'+diaSel.getFullYear()+', às '+p2(Math.floor(horaSel/60))+':'+p2(horaSel%60)+'.';
      }else res.textContent='';
    };
    const desenhaHoras=function(){
      horas.textContent='';horaSel=null;atualizaRes();
      if(!diaSel){vazio.textContent='Escolha um dia para ver os horários.';return}
      vazio.textContent='';
      slots(diaSel).forEach(function(m){
        const b=document.createElement('button');b.type='button';b.className='hora';
        b.textContent=p2(Math.floor(m/60))+':'+p2(m%60);
        b.setAttribute('aria-pressed','false');
        if(!livre(diaSel,m)){b.disabled=true;b.setAttribute('aria-label',b.textContent+', indisponível')}
        b.addEventListener('click',function(){
          horaSel=m;
          horas.querySelectorAll('.hora').forEach(function(x){x.setAttribute('aria-pressed',x===b?'true':'false')});
          el('agGeralE').textContent='';atualizaRes();
        });
        horas.append(b);
      });
    };
    const seleciona=function(d,btn){
      diaSel=d;
      dias.querySelectorAll('.dia').forEach(function(x){x.setAttribute('aria-pressed',x===btn?'true':'false')});
      desenhaHoras();
    };
    lista.forEach(function(d){
      const b=document.createElement('button');b.type='button';b.className='dia';b.setAttribute('aria-pressed','false');
      b.innerHTML='<small></small><b></b><small></small>';
      b.children[0].textContent=SEM[d.getDay()];b.children[1].textContent=String(d.getDate());b.children[2].textContent=MES[d.getMonth()];
      if(!temVaga(d))b.disabled=true;
      b.addEventListener('click',function(){seleciona(d,b)});
      dias.append(b);
    });
    el('agForm').addEventListener('submit',function(e){
      e.preventDefault();
      ['agNomeE','agAceiteE','agGeralE'].forEach(function(i){el(i).textContent=''});
      const nome=el('agNome').value.trim();let bad=false;
      if(!diaSel||horaSel===null){el('agGeralE').textContent='Escolha o dia e o horário.';bad=true}
      if(!nome){el('agNomeE').textContent='Digite o seu nome.';if(!bad)el('agNome').focus();bad=true}
      if(!el('agAceite').checked){el('agAceiteE').textContent='Marque a caixa para enviar o pedido pelo WhatsApp.';if(!bad)el('agAceite').focus();bad=true}
      if(bad)return;
      const obs=el('agObs').value.trim();
      let t='Olá! Gostaria de agendar um horário na Barbearia Nobre (modelo da Hanei Tech).\n';
      t+='Nome: '+nome+'\n';
      t+='Dia: '+SEMF[diaSel.getDay()]+', '+p2(diaSel.getDate())+'/'+p2(diaSel.getMonth()+1)+'/'+diaSel.getFullYear()+'\n';
      t+='Horário: '+p2(Math.floor(horaSel/60))+':'+p2(horaSel%60)+'\n';
      if(obs)t+='Corte/observação: '+obs+'\n';
      t+='\nPode confirmar? Obrigado!';
      const a=document.createElement('a');
      a.href='https://wa.me/'+WA+'?text='+encodeURIComponent(t);a.target='_blank';a.rel='noopener';
      document.body.appendChild(a);a.click();a.remove();
    });
    const primeiro=lista.findIndex(temVaga);
    if(primeiro>-1){const b=dias.children[primeiro];seleciona(lista[primeiro],b)}
  }

  function initMenu(){
    const gav=el('gaveta'),bg=el('burger');
    const abre=function(v){
      gav.classList.toggle('on',v);gav.setAttribute('aria-hidden',v?'false':'true');
      bg.setAttribute('aria-expanded',v?'true':'false');bg.setAttribute('aria-label',v?'Fechar menu':'Abrir menu');
      document.body.style.overflow=v?'hidden':'';
      if(v){el('gavetaX').focus()}else{bg.focus()}
    };
    bg.addEventListener('click',function(){abre(true)});
    el('gavetaX').addEventListener('click',function(){abre(false)});
    el('gavetaFundo').addEventListener('click',function(){abre(false)});
    gav.querySelectorAll('a').forEach(function(a){a.addEventListener('click',function(){abre(false)})});
    document.addEventListener('keydown',function(e){if(e.key==='Escape'&&gav.classList.contains('on'))abre(false)});
  }
  function initHoje(){
    const d=String(new Date().getDay());
    document.querySelectorAll('#tab tr').forEach(function(tr){if(tr.dataset.d===d){tr.classList.add('hoje');tr.setAttribute('aria-current','date')}});
  }
  [initAgenda,initMenu,initHoje].forEach(function(f){f()});
})();
