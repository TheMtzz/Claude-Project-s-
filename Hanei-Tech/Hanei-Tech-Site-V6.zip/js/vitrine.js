(function(){
  var car=document.getElementById('vit-carrossel'); if(!car)return;
  var tr=document.getElementById('vit-trilho'),sl=[].slice.call(tr.children),pts=[].slice.call(document.querySelectorAll('.vit-ponto'));
  var reduz=window.matchMedia&&window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  var atual=0,pausa=false,TEMPO=6500;
  function centro(i){var s=sl[i];return s.offsetLeft-(tr.clientWidth-s.clientWidth)/2}
  function marca(i){
    atual=i;
    sl.forEach(function(s,j){s.classList.toggle('ativo',j===i)});
    pts.forEach(function(p,j){if(j===i){p.setAttribute('aria-current','true');p.classList.remove('rodando');void p.offsetWidth;if(!reduz)p.classList.add('rodando')}else{p.removeAttribute('aria-current');p.classList.remove('rodando')}});
  }
  function vai(i,auto){i=(i+sl.length)%sl.length;tr.scrollTo({left:centro(i),behavior:reduz||auto===2?'auto':'smooth'});marca(i)}
  document.getElementById('vit-ant').addEventListener('click',function(){pausa=true;vai(atual-1)});
  document.getElementById('vit-prox').addEventListener('click',function(){pausa=true;vai(atual+1)});
  pts.forEach(function(p,i){p.addEventListener('click',function(){pausa=true;vai(i)})});
  var t=0;
  tr.addEventListener('scroll',function(){clearTimeout(t);t=setTimeout(function(){
    var m=1e9,k=0;sl.forEach(function(s,j){var d=Math.abs(centro(j)-tr.scrollLeft);if(d<m){m=d;k=j}});if(k!==atual)marca(k)},90)},{passive:true});
  tr.addEventListener('keydown',function(e){if(e.key==='ArrowRight'){vai(atual+1);e.preventDefault()}else if(e.key==='ArrowLeft'){vai(atual-1);e.preventDefault()}});
  ['pointerdown','focusin','mouseenter'].forEach(function(ev){car.addEventListener(ev,function(){pausa=true})});
  car.addEventListener('mouseleave',function(){pausa=false});
  window.addEventListener('resize',function(){tr.scrollTo({left:centro(atual),behavior:'auto'})});
  // autoplay suave, só enquanto a seção está visível e se o visitante aceita movimento
  var visivel=false;
  if('IntersectionObserver' in window)new IntersectionObserver(function(es){visivel=es[0].isIntersecting},{threshold:.5}).observe(car);
  if(!reduz)setInterval(function(){if(visivel&&!pausa&&!document.hidden&&document.documentElement.dataset.mov!=='off')vai(atual+1)},TEMPO);
  tr.scrollLeft=centro(0);marca(0);
})();
// Modal interativo: abre o modelo de verdade, dentro da página
(function(){
  var dlg=document.getElementById('vit-modal'); if(!dlg||!dlg.showModal)return;
  var fr=document.getElementById('vm-frame'),pal=document.getElementById('vm-palco'),tit=document.getElementById('vit-modal-titulo'),full=document.getElementById('vm-full'),wa=document.getElementById('vm-wa');
  var ult=null;
  function disp(d){pal.className='vm-palco'+(d==='cel'?' vm-cel':'');[].forEach.call(dlg.querySelectorAll('.vm-d'),function(b){b.setAttribute('aria-pressed',String(b.dataset.d===d))})}
  function abre(a,slide){
    ult=a;var nome=slide.querySelector('h3').textContent;
    tit.textContent=nome;fr.src=a.getAttribute('href');full.href=a.getAttribute('href');
    var msg=(window.HaneiT||function(x){return x})('Olá, bom dia, gostaria de fazer um orçamento para um site como o modelo ')+nome+'.';
    wa.dataset.wa=msg;wa.href='https://wa.me/5511992315202?text='+encodeURIComponent(msg);
    disp('pc');dlg.showModal();document.body.style.overflow='hidden';
  }
  function fecha(){dlg.close()}
  dlg.addEventListener('close',function(){fr.removeAttribute('src');document.body.style.overflow='';if(ult)ult.focus()});
  dlg.addEventListener('click',function(e){if(e.target===dlg)fecha()});
  document.getElementById('vm-fechar').addEventListener('click',fecha);
  [].forEach.call(dlg.querySelectorAll('.vm-d'),function(b){b.addEventListener('click',function(){disp(b.dataset.d)})});
  [].forEach.call(document.querySelectorAll('.vit-slide'),function(sl){
    var a=sl.querySelector('.vit-abrir');
    a.addEventListener('click',function(e){e.preventDefault();abre(a,sl)});
    sl.querySelector('.vit-aparelhos').addEventListener('click',function(){abre(a,sl)});
    sl.querySelector('.vit-aparelhos').style.cursor='pointer';
  });
})();

/* luz que segue o ponteiro nos quadros (só com mouse; leve) */
(function(){
  if(!window.matchMedia||!matchMedia('(hover:hover)').matches)return;
  var q=document.querySelectorAll('.func-bloco,.prod-card'),ras=0;
  [].forEach.call(q,function(el){
    el.addEventListener('pointermove',function(e){
      if(ras)return;ras=requestAnimationFrame(function(){ras=0;var r=el.getBoundingClientRect();el.style.setProperty('--mx',(e.clientX-r.left)+'px');el.style.setProperty('--my',(e.clientY-r.top)+'px')})
    },{passive:true});
    el.addEventListener('pointerleave',function(){el.style.removeProperty('--mx');el.style.removeProperty('--my')});
  });
})();
