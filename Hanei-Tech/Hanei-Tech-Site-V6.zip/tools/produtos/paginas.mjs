// Conteúdo de cada página de produto (textos, abas, recursos e modelo existente).
import { telaEntrar, telaProdutos, telaEstoque, telaClientes, telaSite, telaAgenda, telaAviso, telaCatalogo, telaHistoria, telaEntrarC, telaEstoqueC, telaRelatorio } from './telas.mjs';

export const paginas = [
  {
    slug: 'gestao-de-estoque',
    titulo: 'Sistema de gestão de estoque',
    descricao: 'Sistema online para lojas de produtos de beleza: cadastro de produtos, clientes e usuários e controle de estoque, feito pela Hanei Tech.',
    rotulo: 'Produto 02 · Sistema',
    h1: 'Gestão de estoque para a sua loja',
    lead: 'Um sistema online para quem vende produtos de beleza: cadastre produtos, clientes e usuários, e veja quanto tem de cada item sem abrir planilha.',
    msg: 'Olá, bom dia, gostaria de fazer um orçamento para um sistema de gestão de estoque.',
    abas: [['entrar', 'Entrar e criar conta'], ['produtos', 'Produtos'], ['estoque', 'Estoque'], ['clientes', 'Clientes']],
    telas: [['entrar', telaEntrar], ['produtos', telaProdutos], ['estoque', telaEstoque], ['clientes', telaClientes]],
    recursos: [
      ['Cada loja no seu espaço', 'A pessoa cria a conta, cadastra a loja e passa a gerir tudo pelo site, com os dados separados de qualquer outra loja.'],
      ['Produtos e preços', 'Cadastro com categoria, preço de venda, quantidade inicial e estoque mínimo, para cada item da prateleira.'],
      ['Estoque que avisa', 'A quantidade de cada produto aparece em barras e etiquetas. O que está acabando fica destacado.'],
      ['Clientes e usuários', 'Cadastro de clientes com WhatsApp e histórico, e usuários para quem trabalha com você.']
    ],
    fim: ['Quer organizar o estoque da sua loja?', 'Conte o que você vende e como controla hoje. A gente monta o sistema com os campos que a sua loja precisa.'],
    dominio: 'sualoja.haneitech.com.br',
    existente: {
      nome: 'Hanei Usinagem',
      url: 'https://haneiusinagem.netlify.app/',
      texto: 'Um sistema que já existe e funciona: o controle do almoxarifado de uma empresa de usinagem, com mais segurança e melhor desempenho. Abra o site, entre na área do usuário e veja por dentro.',
      imgs: [['usi-entrada', 'Tela de acesso do funcionário'], ['usi-painel', 'Tela principal'], ['usi-usuario', 'Cadastro de usuário'], ['usi-produto', 'Cadastro de produto'], ['usi-estoque', 'Lista de estoque']],
      chamada: 'O controle do seu almoxarifado com mais segurança e melhor desempenho.',
      itens: ['Gerenciamento de estoque sempre atualizado', 'Exportação do estoque em PDF, CSV e Excel', 'Diversos filtros para achar o que você precisa', 'Usuários com acesso separado por função'],
    },
    nota: 'Telas ilustrativas, com dados fictícios, para mostrar como o sistema pode ficar. O sistema final é montado de acordo com a necessidade da sua loja.'
  },
  {
    slug: 'agendamento-online',
    titulo: 'Site com agendamento online',
    descricao: 'Site com história do local, avaliações, botão de WhatsApp e agenda online ligada à Google Agenda, com aviso por WhatsApp. Feito pela Hanei Tech.',
    rotulo: 'Produto 03 · Site com agenda',
    h1: 'Site com agendamento online',
    lead: 'O site conta a história do seu negócio e deixa o cliente ver a agenda e marcar o horário sozinho. Cada agendamento vai para a Google Agenda e chega por aviso no WhatsApp.',
    msg: 'Olá, bom dia, gostaria de fazer um orçamento para um site com agendamento online.',
    abas: [['site', 'Site do local'], ['agenda', 'Agenda'], ['aviso', 'Avisos e Google Agenda']],
    telas: [['site', telaSite], ['agenda', telaAgenda], ['aviso', telaAviso]],
    recursos: [
      ['Site com a sua história', 'Quem vocês são, serviços, avaliações de clientes e botão de WhatsApp, num visual profissional.'],
      ['Agenda online', 'O cliente vê os horários livres, escolhe o serviço e o profissional e confirma sem precisar mandar mensagem.'],
      ['Google Agenda', 'Cada horário marcado vira um evento na agenda do local e o horário fica bloqueado para outros clientes.'],
      ['Aviso por WhatsApp', 'Você recebe a mensagem na hora: quem marcou, qual serviço e em que dia e horário.']
    ],
    fim: ['Quer agenda online no seu negócio?', 'Conte quantos profissionais atendem e quais serviços você oferece. A gente monta a agenda do jeito do seu local.'],
    existente: {
      nome: 'Ronald Barber',
      url: 'https://ronald-barber.netlify.app/',
      texto: 'Um site de barbearia que já existe, com agendamento por dia e horário. Abra o site, escolha um horário e veja como o pedido chega pelo WhatsApp.',
      imgs: [['rb-inicio', 'Tela principal'], ['rb-cortes', 'Cortes e equipamentos'], ['rb-agenda', 'Agendamento por dia e horário'], ['rb-local', 'Endereço e horários'], ['rb-contato', 'Contato e Instagram']],
      chamada: 'A agenda do seu negócio funcionando direto no site.',
      itens: ['Agendamento com dia e horário escolhidos pelo cliente', 'Pedido pronto no WhatsApp, confirmado por você', 'Cortes, endereço, horários e Instagram num só lugar', 'Funciona bem no celular e no computador'],
    },
    nota: 'Telas ilustrativas, com dados fictícios, para mostrar como o site e a agenda podem ficar. A ligação com Google Agenda e WhatsApp é configurada junto com você.'
  },
  {
    slug: 'catalogo-online',
    titulo: 'Catálogo online para quem quer vender pelo site',
    descricao: 'Catálogo online com estoque para qualquer negócio que quer vender pelo site: aluguel, materiais, artigos de festa, veículos e mais. Feito pela Hanei Tech.',
    rotulo: 'Produto 04 · Catálogo para vender pelo site',
    h1: 'Catálogo online para quem quer vender pelo site',
    lead: 'Não é só para concessionárias: é um catálogo para qualquer negócio que queira vender ou alugar pelo site, com área interna para cadastrar produtos e acompanhar o estoque.',
    msg: 'Olá, bom dia, gostaria de fazer um orçamento para um catálogo online para vender pelo site.',
    dominio: 'seunegocio.com.br',
    abas: [['catalogo', 'Catálogo'], ['historia', 'Nossa história'], ['entrar', 'Entrada do funcionário'], ['estoque', 'Gestão de estoque'], ['relatorio', 'Relatório em PDF']],
    telas: [['catalogo', telaCatalogo], ['historia', telaHistoria], ['entrar', telaEntrarC], ['estoque', telaEstoqueC], ['relatorio', telaRelatorio]],
    existente: {
      nome: 'Hanei Veículos',
      url: 'https://hanei-veiculos.netlify.app/',
      texto: 'Exemplo de catálogo, feito para veículos, que já existe: catálogo para o cliente e sistema de estoque para a equipe. Abra o site, navegue pelo catálogo e entre na área do funcionário.',
      imgs: [['vei-inicio', 'Tela principal do site'], ['vei-catalogo', 'Catálogo de veículos'], ['vei-entrada', 'Entrada do usuário'], ['vei-estoque', 'Estoque de veículos'], ['vei-relatorio', 'Relatório de estoque gerado']],
      chamada: 'O seu catálogo atualizado, profissional e com a qualidade de grandes marcas e empresas.',
      itens: ['Catálogo com fotos, valor e filtro por categoria', 'Página de cada item com várias fotos', 'Estoque, vendas e usuários num só lugar', 'Relatórios de estoque e de vendas em PDF']
    },
    recursos: [
      ['Catálogo que vende', 'Fotos grandes, valor e detalhes de cada veículo, com filtro por categoria e botão de WhatsApp para pedir o item ou combinar a visita.'],
      ['Estoque atualizado', 'Cadastre, edite e marque como vendido ou indisponível. O que sai do estoque sai do catálogo sozinho.'],
      ['Equipe com acessos', 'Administrador, gerente e funcionário, cada um com as permissões do seu cargo. A placa nunca aparece no site.'],
      ['Relatórios em PDF', 'Estoque e vendas prontos para imprimir ou enviar, com total e valor de cada veículo.']
    ],
    fim: ['Quer o seu catálogo no ar?', 'Conte o que você vende ou aluga e como vende hoje. A gente monta o catálogo e o estoque do jeito do seu negócio, e avalia o que mais você precisar.'],
    nota: 'Telas ilustrativas, com dados fictícios, para mostrar como o catálogo e o sistema podem ficar. O modelo existente abaixo é um site real e funcional.'
  }
];

