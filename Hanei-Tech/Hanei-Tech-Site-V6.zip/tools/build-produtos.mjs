// Gera as páginas /produtos/<slug>/index.html
import { readFileSync, writeFileSync, mkdirSync } from 'node:fs';
import { paginas } from './produtos/paginas.mjs';

const WA = '5511992315202';
const wa = (t) => `https://wa.me/${WA}?text=${encodeURIComponent(t)}`;
const MSG = 'Olá, bom dia, gostaria de fazer um orçamento para sites.';

// símbolo do letreiro (copiado da página inicial)
const home = readFileSync(new URL('../index.html', import.meta.url), 'utf8');
const defs = home.slice(home.indexOf('<svg width="0"'), home.indexOf('</symbol></svg>') + '</symbol></svg>'.length);

const pagina = ({ titulo, descricao, rotulo, h1, lead, msg, abas, telas, recursos, fim, nota, existente, dominio }) => `<!doctype html>
<html lang="pt-BR">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<title>${titulo} · Hanei Tech</title>
<meta name="description" content="${descricao}">
<meta name="theme-color" content="#03050C">
<meta property="og:type" content="website">
<meta property="og:title" content="${titulo} · Hanei Tech">
<meta property="og:description" content="${descricao}">
<meta property="og:locale" content="pt_BR">
<link rel="icon" href="../../favicon.svg" type="image/svg+xml">
<link rel="stylesheet" href="../../css/fonts.css">
<link rel="stylesheet" href="../../css/site.css">
<link rel="stylesheet" href="../../css/produtos.css">
</head>
<body>
${defs}
<a class="pular" href="#conteudo">Pular para o conteúdo</a>
<div class="paisagem" aria-hidden="true"><div class="paisagem-escuro" style="opacity:.86"></div></div>
<header class="topo topo--simples">
  <a class="topo-marca" href="../../" aria-label="Hanei Tech, início"><svg class="marca" viewBox="0 0 1084 100" aria-hidden="true"><use href="#marca"/></svg></a>
  <nav class="topo-links" aria-label="Principal">
    <a href="../../">Início</a>
    <a href="../../#produtos">Produtos</a>
    <a href="../../#contato">Contato</a>
  </nav>
  <a class="botao-contorno topo-conversar" href="${wa(MSG)}" data-wa="${MSG}">Vamos Conversar <svg class="seta" viewBox="0 0 20 20" aria-hidden="true"><path d="M4 10h11M11 5l5 5-5 5"/></svg></a>
</header>
<main id="conteudo" class="pp-main">
  <section class="pp-hero" aria-labelledby="pp-h1">
    <div>
      <p class="pp-rotulo">${rotulo}</p>
      <h1 id="pp-h1">${h1}</h1>
    </div>
    <div class="pp-hero-texto">
      <p>${lead}</p>
      <div class="pp-acoes">
        <a class="botao" href="${wa(msg)}" data-wa="${msg}">Pedir orçamento</a>
        <a class="link" href="#telas">Ver as telas <span aria-hidden="true">↓</span></a>
      </div>
    </div>
  </section>
  <section class="pp-demo" id="telas" aria-labelledby="pp-demo-t">
    <div class="pp-demo-topo">
      <h2 id="pp-demo-t">Telas de exemplo</h2>
      <div class="pp-abas" role="tablist" aria-label="Escolha a tela">
        ${abas.map(([id, nome], i) => `<button type="button" role="tab" class="pp-aba" id="aba-${id}" aria-controls="tela-${id}" aria-selected="${i === 0}"${i ? ' tabindex="-1"' : ''}>${nome}</button>`).join('\n        ')}
      </div>
    </div>
    <div class="janela" data-ui>
      <div class="janela-barra" aria-hidden="true"><i></i><i></i><i></i><span>${dominio || 'seunegocio.com.br'}</span></div>
      ${telas.map(([id, html], i) => `<div class="tela" id="tela-${id}" role="tabpanel" aria-labelledby="aba-${id}"${i ? ' hidden' : ''}>${html}</div>`).join('\n      ')}
    </div>
    <p class="pp-nota">${nota}</p>
  </section>
  ${existente ? `<section class="pp-exist" id="modelo-existente" aria-labelledby="pp-ex-t">
    <div class="pp-exist-topo">
      <div>
        <p class="pp-rotulo">Modelo existente</p>
        <h2 id="pp-ex-t">${existente.nome}</h2>
        <p>${existente.texto}</p>
      </div>
      <a class="botao" href="${existente.url}" target="_blank" rel="noopener">Visitar site <svg class="seta" viewBox="0 0 20 20" aria-hidden="true"><path d="M4 10h11M11 5l5 5-5 5"/></svg></a>
    </div>
    <ul class="pp-exist-telas">
      ${existente.imgs.map(([f, t]) => `<li><a href="${existente.url}" target="_blank" rel="noopener"><img src="../../img/${f}.webp" width="1440" height="900" alt="${t}" loading="lazy"></a><span>${t}</span></li>`).join('\n      ')}
    </ul>
    <p class="pp-exist-chamada">${existente.chamada}</p>
    <ul class="pp-exist-itens">${existente.itens.map((i) => `<li>${i}</li>`).join('')}</ul>
  </section>` : ''}
  <section class="pp-recursos" aria-labelledby="pp-rec-t">
    <h2 id="pp-rec-t">O que vem no sistema</h2>
    ${recursos.map(([t, d], i) => `<div class="pp-recurso"><b>0${i + 1}</b><h3>${t}</h3><p>${d}</p></div>`).join('\n    ')}
  </section>
  <section class="pp-fim" aria-labelledby="pp-fim-t">
    <h2 id="pp-fim-t">${fim[0]}</h2>
    <p>${fim[1]}</p>
    <a class="botao" href="${wa(msg)}" data-wa="${msg}">Pedir orçamento no WhatsApp</a>
  </section>
</main>
<footer class="pp-rodape">
  <span>© 2026 <span translate="no">Hanei Tech</span> · As telas mostradas usam dados fictícios.</span>
  <a href="../../#produtos">Voltar para os produtos</a>
</footer>
<script src="../../js/produtos.js" defer></script>
</body>
</html>
`;

// ───────── Gestão de estoque ─────────
for (const p of paginas) {
  const dir = new URL(`../produtos/${p.slug}/`, import.meta.url);
  mkdirSync(dir, { recursive: true });
  writeFileSync(new URL('index.html', dir), pagina(p));
}
console.log('produtos ok');
