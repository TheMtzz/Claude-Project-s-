/* Carrega os CSS de rodapé/produtos depois do primeiro desenho (substitui onload inline, proibido pela CSP). */
(function(){document.querySelectorAll('link[rel=stylesheet][media=print]').forEach(function(l){l.media='all'})})();
