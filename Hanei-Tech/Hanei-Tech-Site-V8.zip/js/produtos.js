// Páginas de produto: abas das telas de exemplo.
(function () {
  'use strict';
  document.documentElement.classList.add('js');
  document.querySelectorAll('[data-wa]').forEach((a) => { a.target = '_blank'; a.rel = 'noopener noreferrer'; });
  const abas = [...document.querySelectorAll('.pp-aba')];
  const telas = abas.map((a) => document.getElementById(a.getAttribute('aria-controls')));
  function mostrar(i) {
    abas.forEach((a, j) => { a.setAttribute('aria-selected', String(j === i)); a.tabIndex = j === i ? 0 : -1; });
    telas.forEach((t, j) => { t.hidden = j !== i; });
  }
  abas.forEach((a, i) => {
    a.addEventListener('click', () => mostrar(i));
    a.addEventListener('keydown', (e) => {
      const m = { ArrowRight: 1, ArrowDown: 1, ArrowLeft: -1, ArrowUp: -1 };
      let j = null;
      if (e.key in m) j = (i + m[e.key] + abas.length) % abas.length;
      else if (e.key === 'Home') j = 0;
      else if (e.key === 'End') j = abas.length - 1;
      if (j === null) return;
      e.preventDefault(); abas[j].focus(); mostrar(j);
    });
  });
})();
