/* Gerado por tools/bundle.mjs a partir de js/modelos.js e js/site.js. Edite os originais. */
(function () {
'use strict';
// Modelos de exemplo da Hanei Tech.
// Os nomes das empresas são fictícios. O mesmo código desenha:
//  - as páginas /modelos/<slug>/ (exemplos completos),
//  - a prévia ao vivo na seção "Veja o seu site" da página inicial.

const MODELOS = [
  {
    slug: 'salao',
    nicho: 'Salão de beleza',
    nome: 'Studio Aurora',
    cores: { fundo: '#FBF4F1', tinta: '#3A1F2B', destaque: '#B23A5E', campo: '#F3E1DB', claro: '#FFFFFF' },
    titulo: 'Cabelo, unhas e pele',
    apoio: 'Corte, coloração, escova, manicure e design de sobrancelha. Agende pelo WhatsApp e escolha o seu horário.',
    acao: 'Agendar horário',
    servicos: [
      ['Corte e escova', 'Feminino e masculino, com lavagem e finalização.'],
      ['Coloração', 'Mechas, luzes, retoque de raiz e tonalização.'],
      ['Manicure e pedicure', 'Esmaltação comum, em gel e spa dos pés.'],
      ['Sobrancelha', 'Design com pinça ou linha e aplicação de henna.']
    ],
    marcas: ['Produtos que usamos', ['Wella Professionals', 'Truss', 'OPI']],
    avaliacoes: [
      ['Fiz mechas e ficou do jeito que eu queria. Atendimento muito atencioso do início ao fim.', 'Camila R.'],
      ['Marquei pelo WhatsApp em um minuto e fui atendida no horário combinado.', 'Fernanda L.'],
      ['Ambiente limpo, produtos de qualidade e a unha durou semanas. Voltarei com certeza.', 'Juliana M.']
    ],
    horario: [['Terça a sexta', '9h às 20h'], ['Sábado', '8h às 18h'], ['Domingo e segunda', 'Fechado']]
  },
  {
    slug: 'restaurante',
    nicho: 'Restaurante',
    nome: 'Cantina da Praça',
    cores: { fundo: '#FBF5EC', tinta: '#2B1A12', destaque: '#A61E2E', campo: '#F1E3D3', claro: '#FFFFFF' },
    titulo: 'Comida de casa, feita na hora',
    apoio: 'Almoço executivo, massas frescas e pratos à la carte. Reserve sua mesa ou peça pelo WhatsApp para retirar.',
    acao: 'Reservar mesa',
    servicos: [
      ['Almoço executivo', 'Prato do dia com salada, acompanhamento e suco.'],
      ['Massas frescas', 'Feitas na casa, com molhos de receita própria.'],
      ['Para retirar', 'Peça pelo WhatsApp e retire sem esperar.'],
      ['Eventos', 'Aniversários e confraternizações com cardápio fechado.']
    ],
    marcas: ['Na nossa cozinha', ['Massa feita na casa', 'Ingredientes frescos do dia', 'Azeite extravirgem']],
    avaliacoes: [
      ['O almoço executivo é farto e sai rápido. Virou o nosso lugar de toda sexta.', 'Rafael T.'],
      ['Reservei a mesa pelo WhatsApp e já estava tudo pronto quando chegamos.', 'Patrícia S.'],
      ['A massa fresca é a melhor da região. Fizemos o aniversário da minha mãe aqui.', 'Eduardo A.']
    ],
    horario: [['Terça a sexta', '11h às 15h e 18h às 23h'], ['Sábado e domingo', '11h às 23h'], ['Segunda', 'Fechado']]
  },
  {
    slug: 'barbearia',
    nicho: 'Barbearia',
    nome: 'Navalha Fina',
    cores: { fundo: '#F2EFE8', tinta: '#1D2420', destaque: '#85611F', campo: '#1D2420', claro: '#FFFFFF' },
    titulo: 'Corte e barba no seu horário',
    apoio: 'Corte masculino, barba com toalha quente e acabamento na navalha. Agende pelo WhatsApp e não pegue fila.',
    acao: 'Agendar horário',
    servicos: [
      ['Corte', 'Máquina e tesoura, do clássico ao degradê.'],
      ['Barba', 'Toalha quente, navalha e hidratação.'],
      ['Corte + barba', 'O combo completo com acabamento.'],
      ['Sobrancelha', 'Limpeza e alinhamento na navalha.']
    ],
    marcas: ['Produtos que usamos', ['Reuzel', 'QOD Barber Shop', 'Proraso']],
    avaliacoes: [
      ['Corte no capricho e a barba com toalha quente é outro nível. Saí renovado.', 'Lucas P.'],
      ['Horário marcado é horário cumprido. Zero fila, do jeito que tem que ser.', 'Thiago M.'],
      ['Os produtos são bons e eles explicam como usar em casa. Atendimento nota dez.', 'André C.']
    ],
    horario: [['Terça a sexta', '9h às 20h'], ['Sábado', '8h às 18h'], ['Domingo e segunda', 'Fechado']]
  },
  {
    slug: 'oficina',
    nicho: 'Oficina mecânica',
    nome: 'Ponto Certo',
    cores: { fundo: '#F4F3F0', tinta: '#1C1C1C', destaque: '#B93F14', campo: '#1C1C1C', claro: '#FFFFFF' },
    titulo: 'Seu carro em boas mãos',
    apoio: 'Revisão, freios, alinhamento, balanceamento e troca de óleo Motul, com orçamento antes de qualquer serviço.',
    acao: 'Pedir orçamento',
    servicos: [
      ['Revisão completa', 'Checagem de itens de segurança e fluidos.'],
      ['Freios', 'Pastilhas, discos e fluido de freio.'],
      ['Alinhamento e balanceamento', 'Suspensão revisada, alinhamento 3D e rodas balanceadas.'],
      ['Troca de óleo', 'Óleo Motul e filtros na especificação do fabricante.']
    ],
    marcas: ['Produtos que usamos', ['Motul', 'Bosch', 'Mann-Filter']],
    avaliacoes: [
      ['Mandaram o orçamento pelo WhatsApp antes de mexer em qualquer coisa. Preço justo e serviço no prazo.', 'Marcelo V.'],
      ['Troquei o óleo com Motul e o carro ficou mais silencioso. Explicaram tudo que foi feito.', 'Roberto F.'],
      ['Fiz alinhamento e balanceamento e o volante parou de tremer. Recomendo.', 'Daniela K.']
    ],
    horario: [['Segunda a sexta', '8h às 18h'], ['Sábado', '8h às 12h'], ['Domingo', 'Fechado']]
  }
];

const esc = (s) => String(s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

// Monta o HTML de um modelo. `nome` substitui o nome fictício (prévia ao vivo).
function renderModelo(modelo, nome, { pagina = false } = {}) {
  const hT = pagina ? 'h1' : 'h3';
  const hS = pagina ? 'h2' : 'h4';
  const m = modelo;
  const n = esc((nome && nome.trim()) || m.nome);
  const c = m.cores;
  const escuro = c.campo === c.tinta;
  return `
<div class="mdl" style="--m-fundo:${c.fundo};--m-tinta:${c.tinta};--m-destaque:${c.destaque};--m-campo:${c.campo};--m-claro:${c.claro};--m-campo-tinta:${escuro ? c.claro : c.tinta}">
  <header class="mdl-topo">
    <span class="mdl-marca" translate="no">${n}</span>
    <nav class="mdl-links"><span>Serviços</span><span>Horários</span><span>Contato</span></nav>
    <span class="mdl-botao mdl-botao--pequeno">${esc(m.acao)}</span>
  </header>
  <section class="mdl-hero">
    <span class="mdl-orbe" aria-hidden="true"></span>
    <div class="mdl-hero-texto">
      <p class="mdl-nicho">${esc(m.nicho)}</p>
      <${hT} class="mdl-titulo">${esc(m.titulo)}</${hT}>
      <p class="mdl-apoio">${esc(m.apoio)}</p>
      <span class="mdl-botao">${esc(m.acao)} pelo WhatsApp</span>
    </div>
    <div class="mdl-pedido">
      <p class="mdl-pedido-titulo">O que você precisa?</p>
      ${m.servicos.map(([t], i) => `<span class="mdl-opcao${i === 0 ? ' mdl-opcao--on' : ''}"><i></i>${esc(t)}</span>`).join('')}
      <span class="mdl-campo-falso">Seu bairro</span>
      <span class="mdl-botao mdl-botao--cheio">Enviar pelo WhatsApp</span>
    </div>
  </section>
  <section class="mdl-servicos">
    ${m.servicos.map(([t, d], i) => `<div class="mdl-servico"><span class="mdl-num">0${i + 1}</span><${hS}>${esc(t)}</${hS}><p>${esc(d)}</p></div>`).join('')}
  </section>
  ${pagina ? `<section class="mdl-horario">
    <${hS}>Horários</${hS}>
    <dl>${m.horario.map(([d, h]) => `<div><dt>${esc(d)}</dt><dd>${esc(h)}</dd></div>`).join('')}</dl>
  </section>` : ''}
  <footer class="mdl-rodape"><span>${n}</span><span>Modelo de exemplo · Hanei Tech</span></footer>
</div>`;
}



// ───────────────────────────────────────────────────────────────
// WhatsApp da Hanei Tech: só números, com DDI e DDD.
// Exemplo: '5511912345678'. Se ficar vazio, os botões abrem
// o WhatsApp com a mensagem pronta e a pessoa escolhe o contato.
const WHATSAPP = '5511992315202';
// ───────────────────────────────────────────────────────────────

const linkWhats = (texto) => `https://wa.me/${WHATSAPP}?text=${encodeURIComponent(texto)}`;
const semMovimento = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
const celular = window.matchMedia('(max-width: 900px)');
const raiz = document.documentElement;
// A classe "js" liga as animações de entrada. Só é ligada se o script rodar:
// sem script, todo o conteúdo aparece normalmente.
raiz.classList.add('js');

document.querySelectorAll('[data-wa]').forEach((a) => {
  a.href = linkWhats(a.dataset.wa);
  a.target = '_blank';
  a.rel = 'noopener noreferrer';
});

// Entradas: título, texto e imagem sobem em sequência quando a seção aparece.
const observador = new IntersectionObserver((itens) => {
  itens.forEach((item) => {
    if (!item.isIntersecting) return;
    item.target.classList.add('visivel');
    observador.unobserve(item.target);
  });
}, { rootMargin: '0px 0px -10% 0px', threshold: 0.12 });

document.querySelectorAll('section, footer').forEach((secao) => {
  secao.querySelectorAll('[data-sobe]').forEach((el, i) => {
    el.style.setProperty('--atraso', `${Math.min(i, 5) * 80}ms`);
    observador.observe(el);
  });
});
document.querySelectorAll('.etapa').forEach((el) => observador.observe(el));

// Se a rolagem pular uma seção (link do menu, tecla End), o que já passou aparece mesmo assim.
function revelarPassados() {
  document.querySelectorAll('[data-sobe]:not(.visivel), .etapa:not(.visivel)').forEach((el) => {
    if (el.getBoundingClientRect().top < window.innerHeight) {
      el.classList.add('visivel');
      observador.unobserve(el);
    }
  });
}

// Vídeo: para com "reduzir movimento"
if (semMovimento) document.querySelectorAll('video[autoplay]').forEach((v) => { v.removeAttribute('autoplay'); v.pause(); });

// ───── Cabeçalho ─────
// Computador: fixo sempre, ganha fundo sólido depois de sair do topo.
// Celular: some ao descer e volta ao subir, para liberar a tela.
const topo = document.querySelector('.topo');
let ultimoY = window.scrollY;

// Menu: destaca a seção que está na tela ("Início" em azul, como na arte).
const linksMenu = [...document.querySelectorAll('.topo-links a[data-secao]')];
const secoesMenu = linksMenu.map((a) => document.getElementById(a.dataset.secao)).filter(Boolean);
function marcarSecao() {
  // vale a seção do menu que está cruzando a linha a 35% da altura da tela
  const meio = window.innerHeight * 0.35;
  let atualId = null;
  for (const s of secoesMenu) {
    const r = s.getBoundingClientRect();
    if (r.top <= meio && r.bottom > meio) atualId = s.id;
  }
  if (!atualId && window.scrollY < 200) atualId = 'inicio';
  linksMenu.forEach((a) => a.setAttribute('aria-current', String(a.dataset.secao === atualId)));
}

// ───── Tela inicial: paisagem escurece e dragão diminui ao descer ─────
const paisagem = document.querySelector('.paisagem');
const dragao = document.querySelector('.hero-dragao');
function cenaInicial() {
  const h = window.innerHeight;
  const p = Math.min(1, Math.max(0, window.scrollY / h));
  paisagem.style.setProperty('--escuro', (0.62 * p).toFixed(3));
  if (dragao && !semMovimento) {
    const escala = 1 - 0.32 * p;
    dragao.style.transform = `translate3d(0, ${(-p * 0.18 * h).toFixed(1)}px, 0) scale(${escala.toFixed(3)})`;
    dragao.style.opacity = (1 - Math.max(0, (p - 0.35) / 0.65)).toFixed(3);
  }
}

// ───── Menu lateral (celular) ─────
const gaveta = document.getElementById('gaveta');
const botaoMenu = document.querySelector('.topo-menu');
let focoAntes = null;
function abrirGaveta() {
  focoAntes = document.activeElement;
  gaveta.hidden = false;
  botaoMenu.setAttribute('aria-expanded', 'true');
  document.body.style.overflow = 'hidden';
  gaveta.querySelector('.gaveta-fechar').focus();
}
function fecharGaveta() {
  if (gaveta.hidden) return;
  gaveta.hidden = true;
  botaoMenu.setAttribute('aria-expanded', 'false');
  document.body.style.overflow = '';
  focoAntes?.focus?.();
}
botaoMenu?.addEventListener('click', abrirGaveta);
gaveta?.querySelectorAll('[data-fechar]').forEach((el) => el.addEventListener('click', fecharGaveta));
document.addEventListener('keydown', (e) => {
  if (gaveta.hidden) return;
  if (e.key === 'Escape') fecharGaveta();
  if (e.key === 'Tab') {               // mantém o foco dentro do menu aberto
    const focaveis = [...gaveta.querySelectorAll('a, button')];
    const primeiro = focaveis[0], ultimo = focaveis[focaveis.length - 1];
    if (e.shiftKey && document.activeElement === primeiro) { e.preventDefault(); ultimo.focus(); }
    else if (!e.shiftKey && document.activeElement === ultimo) { e.preventDefault(); primeiro.focus(); }
  }
});
celular.addEventListener('change', (e) => { if (!e.matches) fecharGaveta(); });

// ───── Projetos: prévia ao vivo com o nome digitado ─────
// O estado vai para a URL: dá para mandar ao cliente um link como
// ?nome=Salão%20da%20Ana&modelo=salao#modelos e ele já abre com o nome dele.
const tela = document.getElementById('previa');
const painel = document.getElementById('previa-painel');
const campoNome = document.getElementById('nome-empresa');
const itens = [...document.querySelectorAll('.modelos-item')];
const botaoWhats = document.getElementById('modelos-whats');
const linkAbrir = document.getElementById('modelos-abrir');
let atual = -1;
let urlPendente;

function salvarNaUrl() {
  clearTimeout(urlPendente);
  urlPendente = setTimeout(() => {
    const url = new URL(location.href);
    const nome = campoNome.value.trim();
    if (nome) url.searchParams.set('nome', nome); else url.searchParams.delete('nome');
    if (atual > 0) url.searchParams.set('modelo', MODELOS[atual].slug); else url.searchParams.delete('modelo');
    history.replaceState(null, '', url);
  }, 400);
}

function mostrarModelo(i, animar = true) {
  if (!tela) return;
  const m = MODELOS[i];
  const nome = campoNome.value.trim();
  tela.innerHTML = renderModelo(m, nome);
  if (animar && !semMovimento && i !== atual) {
    tela.classList.remove('entrando');
    void tela.offsetWidth;
    tela.classList.add('entrando');
  }
  if (i !== atual) tela.scrollTop = 0;
  atual = i;
  itens.forEach((b, j) => {
    b.setAttribute('aria-selected', String(j === i));
    b.tabIndex = j === i ? 0 : -1;
  });
  painel.setAttribute('aria-labelledby', itens[i].id);
  const empresa = nome ? ` Minha empresa: ${nome}.` : '';
  botaoWhats.dataset.wa = `Olá, bom dia, gostaria de fazer um orçamento para um site de ${m.nicho.toLowerCase()}.${empresa}`;
  botaoWhats.href = linkWhats(botaoWhats.dataset.wa);
  linkAbrir.href = `modelos/${m.slug}/`;
}

if (tela) {
  const params = new URLSearchParams(location.search);
  if (params.get('nome')) campoNome.value = params.get('nome').slice(0, 40);
  const inicial = Math.max(0, MODELOS.findIndex((m) => m.slug === params.get('modelo')));
  mostrarModelo(inicial, false);
  campoNome.addEventListener('input', () => { mostrarModelo(atual, false); salvarNaUrl(); });
  itens.forEach((botao, i) => {
    botao.addEventListener('click', () => { mostrarModelo(i); salvarNaUrl(); });
    botao.addEventListener('keydown', (e) => {
      const teclas = { ArrowRight: 1, ArrowDown: 1, ArrowLeft: -1, ArrowUp: -1, Home: 'inicio', End: 'fim' };
      if (!(e.key in teclas)) return;
      e.preventDefault();
      const t = teclas[e.key];
      const j = t === 'inicio' ? 0 : t === 'fim' ? itens.length - 1 : (i + t + itens.length) % itens.length;
      itens[j].focus();
      itens[j].click();
    });
  });
}

// ───── Produtos: carrossel dos modelos ─────
document.querySelectorAll('.carrossel').forEach((car) => {
  const trilho = car.querySelector('.carrossel-trilho');
  const botoes = [...car.querySelectorAll('.carrossel-botao')];
  const passo = () => (trilho.querySelector('.carrossel-item')?.getBoundingClientRect().width || 400) + 20;
  const atualizar = () => {
    const max = trilho.scrollWidth - trilho.clientWidth - 4;
    botoes[0].disabled = trilho.scrollLeft <= 4;
    botoes[1].disabled = trilho.scrollLeft >= max;
  };
  botoes.forEach((b) => b.addEventListener('click', () => {
    trilho.scrollBy({ left: Number(b.dataset.passo) * passo(), behavior: semMovimento ? 'auto' : 'smooth' });
  }));
  trilho.addEventListener('scroll', () => requestAnimationFrame(atualizar), { passive: true });
  trilho.addEventListener('keydown', (e) => {
    if (e.key === 'ArrowRight' || e.key === 'ArrowLeft') {
      e.preventDefault();
      trilho.scrollBy({ left: (e.key === 'ArrowRight' ? 1 : -1) * passo(), behavior: semMovimento ? 'auto' : 'smooth' });
    }
  });
  window.addEventListener('resize', atualizar);
  atualizar();
});

// ───── Rolagem ─────
let pedido = false;
function aoRolar() {
  if (pedido) return;
  pedido = true;
  requestAnimationFrame(() => {
    const y = window.scrollY;
    topo.classList.toggle('solido', y > 40);
    topo.classList.toggle('escondido', celular.matches && y > ultimoY && y > 200 && gaveta.hidden);
    ultimoY = y;
    cenaInicial();
    marcarSecao();
    revelarPassados();
    pedido = false;
  });
}
window.addEventListener('scroll', aoRolar, { passive: true });
window.addEventListener('resize', aoRolar);
topo.addEventListener('focusin', () => topo.classList.remove('escondido'));
aoRolar();

// Entrada discreta da área da equipe: 5 toques rápidos no "© 2026 Hanei Tech" do rodapé.
(() => {
  const el = document.getElementById('marca-c');
  if (!el) return;
  let n = 0, t = 0;
  el.addEventListener('click', () => {
    const agora = Date.now();
    n = agora - t > 1200 ? 1 : n + 1;
    t = agora;
    if (n >= 5) { n = 0; location.href = 'equipe/'; }
  });
})();

})();
