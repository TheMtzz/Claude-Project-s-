/* Cliente mínimo do Supabase (Auth + REST + Edge Function) — sem bibliotecas, funciona com a CSP do site. */
(function () {
  'use strict';
  var C = window.EQCFG || {};
  var K = 'eq-sessao';
  var memoria = null;

  function ler() {
    try { var t = sessionStorage.getItem(K); return t ? JSON.parse(t) : memoria; } catch (e) { return memoria; }
  }
  function gravar(s) {
    memoria = s;
    try { if (s) sessionStorage.setItem(K, JSON.stringify(s)); else sessionStorage.removeItem(K); } catch (e) { /* sem storage: fica só na memória da aba */ }
  }
  function agora() { return Math.floor(Date.now() / 1000); }
  function configurado() { return !!C.url && C.url.indexOf('SEU-PROJETO') < 0 && !!C.chave && C.chave.indexOf('COLE-AQUI') < 0; }

  function el(tag, attrs) {
    var n = document.createElement(tag);
    if (attrs) for (var k in attrs) {
      var v = attrs[k];
      if (v === false || v == null) continue;
      if (k === 'class') n.className = v;
      else if (k === 'text') n.textContent = v;
      else if (k.slice(0, 2) === 'on') n.addEventListener(k.slice(2), v);
      else n.setAttribute(k, v === true ? '' : v);
    }
    for (var i = 2; i < arguments.length; i++) {
      var c = arguments[i];
      if (c == null || c === false) continue;
      n.appendChild(typeof c === 'string' ? document.createTextNode(c) : c);
    }
    return n;
  }

  async function http(url, init) {
    var r;
    try { r = await fetch(url, init); } catch (e) { var er = new Error('Sem conexão com o servidor. Confira a internet e tente de novo.'); er.rede = true; throw er; }
    var corpo = null;
    var txt = await r.text();
    if (txt) { try { corpo = JSON.parse(txt); } catch (e) { corpo = txt; } }
    if (!r.ok) {
      var m = corpo && (corpo.erro || corpo.msg || corpo.error_description || corpo.message);
      var er2 = new Error(typeof m === 'string' ? m : 'Algo deu errado (' + r.status + ').');
      er2.status = r.status;
      throw er2;
    }
    return { corpo: corpo, resp: r };
  }

  // entra com usuário OU e-mail (o servidor resolve e confere a senha)
  async function entrar(identificador, senha) {
    var o = await http(C.url + '/functions/v1/equipe-api', {
      method: 'POST', headers: { apikey: C.chave, Authorization: 'Bearer ' + C.chave, 'Content-Type': 'application/json' },
      body: JSON.stringify({ acao: 'entrar', identificador: identificador, senha: senha })
    });
    guardarTokens(o.corpo, false);
  }
  function guardarTokens(t, verificado) {
    var atual = ler() || {};
    gravar({ at: t.access_token, rt: t.refresh_token, exp: t.expires_at || (agora() + (t.expires_in || 3600)), uid: t.user && t.user.id, email: t.user && t.user.email, ok: verificado === undefined ? atual.ok : verificado });
  }
  async function renovar() {
    var s = ler();
    if (!s || !s.rt) throw new Error('Sessão encerrada.');
    var o = await http(C.url + '/auth/v1/token?grant_type=refresh_token', {
      method: 'POST', headers: { apikey: C.chave, 'Content-Type': 'application/json' },
      body: JSON.stringify({ refresh_token: s.rt })
    });
    guardarTokens(o.corpo, s.ok);
  }
  async function token() {
    var s = ler();
    if (!s) return null;
    if (s.exp - 60 < agora()) { try { await renovar(); } catch (e) { gravar(null); return null; } s = ler(); }
    return s.at;
  }
  function paraLogin() { gravar(null); location.replace('index.html'); }

  // chamada autenticada ao banco (REST/RPC)
  async function db(caminho, init) {
    init = init || {};
    var t = await token();
    if (!t) { paraLogin(); throw new Error('Sessão encerrada.'); }
    var h = Object.assign({ apikey: C.chave, Authorization: 'Bearer ' + t, 'Content-Type': 'application/json' }, init.headers || {});
    try { return await http(C.url + '/rest/v1/' + caminho, Object.assign({}, init, { headers: h })); }
    catch (e) { if (e.status === 401) { paraLogin(); } throw e; }
  }
  async function rpc(nome, args) { return (await db('rpc/' + nome, { method: 'POST', body: JSON.stringify(args || {}) })).corpo; }

  // chamada à função de servidor (e-mail, convite, senha)
  async function fn(acao, corpo, tokenFixo) {
    var t = tokenFixo || (await token()) || C.chave;
    var o = await http(C.url + '/functions/v1/equipe-api', {
      method: 'POST', headers: { apikey: C.chave, Authorization: 'Bearer ' + t, 'Content-Type': 'application/json' },
      body: JSON.stringify(Object.assign({ acao: acao }, corpo || {}))
    });
    return o.corpo;
  }

  function marcarVerificado() { var s = ler(); if (s) { s.ok = true; gravar(s); } }

  // vigia: só deixa ficar na página quem tem login + código verificado de verdade (conferido no servidor)
  async function guarda(exigeAdmin) {
    var s = ler();
    if (!configurado() || !s || !s.ok) { paraLogin(); return new Promise(function () {}); }
    try {
      var ok = await rpc('sessao_verificada');
      if (ok !== true) { paraLogin(); return new Promise(function () {}); }
      var r = await db('perfis?id=eq.' + encodeURIComponent(s.uid) + '&select=id,nome,usuario,email,papel,ativo');
      var p = r.corpo && r.corpo[0];
      if (!p || !p.ativo) { paraLogin(); return new Promise(function () {}); }
      if (exigeAdmin && p.papel !== 'admin') { location.replace('painel.html'); return new Promise(function () {}); }
      return p;
    } catch (e) {
      if (e.rede) throw e;
      paraLogin(); return new Promise(function () {});
    }
  }
  async function sair() {
    try { await fn('sair'); } catch (e) { /* segue */ }
    paraLogin();
  }

  function saudacao() {
    var h = new Date().getHours();
    return h >= 5 && h < 12 ? 'Bom dia' : h >= 12 && h < 18 ? 'Boa tarde' : 'Boa noite';
  }
  function aviso(alvo, texto, tipo) {
    alvo.textContent = texto || '';
    alvo.className = 'aviso' + (texto ? ' ' + (tipo || 'erro') : '');
    alvo.hidden = !texto;
  }
  function ocupado(botao, sim, textoOcupado) {
    if (sim) { botao.dataset.t = botao.textContent; botao.textContent = textoOcupado || 'Aguarde…'; botao.disabled = true; }
    else { botao.textContent = botao.dataset.t || botao.textContent; botao.disabled = false; }
  }

  window.EQ = { C: C, el: el, entrar: entrar, token: token, db: db, rpc: rpc, fn: fn, guarda: guarda, sair: sair, ler: ler, gravar: gravar,
    marcarVerificado: marcarVerificado, saudacao: saudacao, aviso: aviso, ocupado: ocupado, configurado: configurado, paraLogin: paraLogin };
})();
