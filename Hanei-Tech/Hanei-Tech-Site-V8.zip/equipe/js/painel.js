(function () {
  'use strict';
  EQ.guarda().then(function (p) {
    var primeiro = String(p.nome || '').trim().split(/\s+/)[0] || '';
    document.getElementById('saud').textContent = EQ.saudacao() + (primeiro ? ', ' + primeiro : '') + '.';
    document.getElementById('sub').textContent = p.papel === 'admin' ? 'Você é administrador. Escolha por onde começar.' : 'Escolha por onde começar.';
    if (p.papel === 'admin') document.getElementById('a-usuarios').hidden = false;
  }).catch(function (e) { EQ.aviso(document.getElementById('aviso'), e.message, 'erro'); });
})();
