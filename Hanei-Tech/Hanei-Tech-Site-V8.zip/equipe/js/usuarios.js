(function () {
  'use strict';
  var $ = function (i) { return document.getElementById(i); }, av = $('aviso'), el = EQ.el, eu;

  function selo(u) {
    if (!u.ativo) return el('span', { class: 'selo err', text: 'Desativado' });
    if (!u.confirmado) return el('span', { class: 'selo warn', text: 'Aguardando confirmação do e-mail' });
    return el('span', { class: 'selo ok', text: 'Ativo' });
  }
  async function agir(acao, corpo, ok) {
    try { await EQ.fn(acao, corpo); EQ.aviso(av, ok, 'ok'); await carregar(); }
    catch (er) { EQ.aviso(av, er.message, 'erro'); }
  }
  async function carregar() {
    var lista = await EQ.rpc('listar_equipe'), tb = $('corpo');
    tb.textContent = '';
    lista.forEach(function (u) {
      var acoes = el('div', { class: 'linha-botoes' });
      if (u.id !== eu.id) {
        acoes.appendChild(el('button', { type: 'button', class: 'botao-pq', text: u.confirmado ? 'Resetar senha' : 'Reenviar convite', onclick: function () {
          if (confirm('Enviar novo link de senha para ' + u.nome + '?')) agir('reenviar_convite', { id: u.id }, 'Link enviado para ' + u.email + '.'); } }));
        acoes.appendChild(el('button', { type: 'button', class: 'botao-pq' + (u.ativo ? ' perigo' : ''), text: u.ativo ? 'Desativar' : 'Reativar', onclick: function () {
          if (!u.ativo || confirm('Desativar ' + u.nome + '? Ela perde o acesso na hora.')) agir('alterar_usuario', { id: u.id, ativo: !u.ativo }, u.ativo ? 'Usuário desativado.' : 'Usuário reativado.'); } }));
      } else acoes.appendChild(el('span', { class: 'mut', text: 'Você' }));
      tb.appendChild(el('tr', null, el('td', { text: u.nome }), el('td', { text: u.usuario || '—' }), el('td', { text: u.email || '' }),
        el('td', { text: u.papel === 'admin' ? 'Administrador' : 'Funcionário' }), el('td', null, selo(u)), el('td', null, acoes)));
    });
  }
  $('f-novo').addEventListener('submit', async function (e) {
    e.preventDefault();
    var b = e.target.querySelector('button[type=submit]'); EQ.ocupado(b, true, 'Enviando…');
    try {
      await EQ.fn('convidar', { nome: $('n-nome').value, usuario: $('n-usuario').value, email: $('n-email').value, papel: $('n-papel').value });
      EQ.aviso(av, 'Convite enviado para ' + $('n-email').value + '. O acesso só vale depois que a pessoa clicar no link.', 'ok');
      e.target.reset(); await carregar();
    } catch (er) { EQ.aviso(av, er.message, 'erro'); }
    EQ.ocupado(b, false);
  });
  EQ.guarda(true).then(function (p) { eu = p; return carregar(); }).catch(function (e) { EQ.aviso(av, e.message, 'erro'); });
})();
