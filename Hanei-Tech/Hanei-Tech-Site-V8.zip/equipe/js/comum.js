(function () { 'use strict'; var b = document.getElementById('b-sair'); if (b) b.addEventListener('click', function () { EQ.sair(); }); })();
