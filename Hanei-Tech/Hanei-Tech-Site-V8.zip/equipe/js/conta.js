(function () {
  'use strict';
  var $ = function (i) { return document.getElementById(i); }, av = $('aviso');
  EQ.guarda().then(function (p) {
    $('d-nome').value = p.nome || ''; $('d-usuario').value = p.usuario || ''; $('d-email').value = p.email || '';
  }).catch(function (e) { EQ.aviso(av, e.message, 'erro'); });

  $('f-dados').addEventListener('submit', async function (e) {
    e.preventDefault();
    var b = e.target.querySelector('button[type=submit]'); EQ.ocupado(b, true, 'Salvando…');
    try { await EQ.fn('atualizar_perfil', { nome: $('d-nome').value, usuario: $('d-usuario').value }); EQ.aviso(av, 'Dados salvos.', 'ok'); }
    catch (er) { EQ.aviso(av, er.message, 'erro'); }
    EQ.ocupado(b, false);
  });
  $('f-troca').addEventListener('submit', async function (e) {
    e.preventDefault();
    if ($('p-nova').value !== $('p-conf').value) return EQ.aviso(av, 'As senhas novas não são iguais.', 'erro');
    var b = e.target.querySelector('button[type=submit]'); EQ.ocupado(b, true, 'Trocando…');
    try { await EQ.fn('trocar_senha', { atual: $('p-atual').value, nova: $('p-nova').value }); e.target.reset(); EQ.aviso(av, 'Senha trocada.', 'ok'); }
    catch (er) { EQ.aviso(av, er.message, 'erro'); }
    EQ.ocupado(b, false);
  });
})();
