/* Configuração da área da equipe. Preencha com os dados do SEU projeto Supabase
   (Project Settings > API). A chave "anon/publishable" é pública por natureza; a proteção real está nas regras (RLS) do banco.
   NUNCA coloque aqui a chave "service_role". Atalho: node tools/configurar-equipe.mjs <url> <chave> */
window.EQCFG = {
  url: 'https://SEU-PROJETO.supabase.co',
  chave: 'COLE-AQUI-A-CHAVE-ANON-OU-PUBLISHABLE'
};
