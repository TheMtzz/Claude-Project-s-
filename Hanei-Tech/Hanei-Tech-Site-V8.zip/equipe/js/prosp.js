(function () {
  'use strict';
  var $ = function (i) { return document.getElementById(i); }, av = $('aviso'), el = EQ.el;
  var POR_PAGINA = 20, pagina = 0, total = 0, eu, nomes = {}, buscou = false;

  var COLS = 'retomadas,ultimo_contato_em,id,dono,nome,nicho,telefone,whatsapp,tem_site,site,so_rede_social,endereco,cidade,uf,nota,avaliacoes,maps_url,primeira_msg,respondeu,fechado,observacao';
  var UFS = ['AC','AL','AP','AM','BA','CE','DF','ES','GO','MA','MT','MS','MG','PA','PB','PR','PE','PI','RJ','RN','RS','RO','RR','SC','SP','SE','TO'];

  function cap(s) { s = String(s || ''); return s.charAt(0).toUpperCase() + s.slice(1); }
  function enc(v) { return encodeURIComponent(v); }

  function montarConsulta() {
    var q = ['select=' + COLS];
    var nome = $('f-q').value.replace(/[*%,()\\]/g, ' ').trim();
    if (nome) q.push('nome=ilike.' + enc('*' + nome + '*'));
    if ($('f-dono').value) q.push('dono=eq.' + enc($('f-dono').value));
    if ($('f-uf').value) q.push('uf=eq.' + enc($('f-uf').value));
    if ($('f-nicho').value) q.push('nicho=eq.' + enc($('f-nicho').value));
    var s = $('f-site').value;
    if (s === 'nao') q.push('tem_site=is.false'); else if (s === 'sim') q.push('tem_site=is.true');
    var st = $('f-status').value;
    if (st === 'novo') q.push('primeira_msg=is.false');
    else if (st === 'retomar') { q.push('primeira_msg=is.true'); q.push('respondeu=is.null'); q.push('fechado=is.null'); q.push('ultimo_contato_em=lt.' + enc(new Date(Date.now() - 3 * 86400000).toISOString())); }
    else if (st === 'andamento') { q.push('primeira_msg=is.true'); q.push('respondeu=is.null'); }
    else if (st === 'sim') q.push('respondeu=is.true');
    else if (st === 'nao') q.push('respondeu=is.false');
    else if (st === 'fechado') q.push('fechado=is.true');
    q.push('order=score.desc.nullslast,nota.desc.nullslast,nome.asc');
    q.push('limit=' + POR_PAGINA, 'offset=' + (pagina * POR_PAGINA));
    return q.join('&');
  }

  var TRES_DIAS = 3 * 86400000;
  function diasDesde(iso) { return iso ? Math.floor((Date.now() - new Date(iso).getTime()) / 86400000) : null; }
  function paraRetomar(l) { return !!l.primeira_msg && l.respondeu == null && l.fechado == null && !!l.ultimo_contato_em && (Date.now() - new Date(l.ultimo_contato_em).getTime()) >= TRES_DIAS; }

  function podeEditar(l) { return eu.papel === 'admin' || l.dono === eu.id; }

  async function salvar(l, campos, ctl, card) {
    try {
      var r = await EQ.db('leads?id=eq.' + enc(l.id) + '&select=' + COLS, { method: 'PATCH', body: JSON.stringify(campos), headers: { Prefer: 'return=representation' } });
      var nova = r.corpo && r.corpo[0];
      if (!nova) throw new Error('Sem permissão para mudar este lead (ele é de outra pessoa).');
      Object.assign(l, nova);
      EQ.aviso(av, '');
      var c = card.querySelector('[data-k=primeira_msg]'); if (c) c.checked = !!l.primeira_msg;
    } catch (er) { EQ.aviso(av, er.message, 'erro'); desenhar(); }
  }

  function tri(valor) { return valor === true ? 'sim' : valor === false ? 'nao' : ''; }
  function deTri(v) { return v === 'sim' ? true : v === 'nao' ? false : null; }

  function seletorTri(rotulo, l, campo, card) {
    var id = 's-' + campo + '-' + l.id;
    var s = el('select', { id: id, 'data-k': campo, disabled: !podeEditar(l) },
      el('option', { value: '', text: '—' }), el('option', { value: 'sim', text: 'Sim' }), el('option', { value: 'nao', text: 'Não' }));
    s.value = tri(l[campo]);
    s.addEventListener('change', function () { salvar(l, (function () { var o = {}; o[campo] = deTri(s.value); return o; })(), s, card); });
    return el('div', { class: 'campo', style: 'margin:0' }, el('label', { for: id, text: rotulo }), s);
  }

  function cartao(l) {
    var card = el('article', { class: 'lead', 'aria-label': l.nome });
    var siteSelo = l.tem_site ? el('span', { class: 'selo err', text: 'Tem site' }) : l.so_rede_social ? el('span', { class: 'selo warn', text: 'Só rede social' }) : el('span', { class: 'selo ok', text: 'Sem site' });
    var busca = 'https://www.google.com/maps/search/?api=1&query=' + enc([l.nome, l.cidade, l.uf].filter(Boolean).join(' '));
    card.appendChild(el('div', { class: 'lead-topo' }, el('h3', { text: l.nome }), siteSelo, el('span', { class: 'selo ac', text: cap(l.nicho) }),
      paraRetomar(l) ? el('span', { class: 'selo warn', text: 'Retomar: ' + diasDesde(l.ultimo_contato_em) + ' dias sem resposta' }) : null,
      el('a', { class: 'botao-pq', href: l.maps_url || busca, target: '_blank', rel: 'noopener noreferrer', text: 'Conferir no Maps ↗', 'aria-label': 'Conferir ' + l.nome + ' no Google Maps (abre em nova aba)' })));

    var info = el('div', { class: 'lead-info' });
    var local = [l.cidade, l.uf].filter(Boolean).join(' - ');
    if (local) info.appendChild(el('span', { text: local }));
    if (l.endereco) info.appendChild(el('span', { text: l.endereco }));
    if (l.nota != null) info.appendChild(el('span', { text: '★ ' + String(l.nota).replace('.', ',') + (l.avaliacoes != null ? ' (' + l.avaliacoes + ' avaliações)' : '') }));
    info.appendChild(el('span', { text: 'Cadastrado por ' + (nomes[l.dono] || 'outra pessoa') }));
    card.appendChild(info);

    var contato = el('div', { class: 'lead-info' });
    if (l.telefone) contato.appendChild(el('strong', { style: 'color:var(--ink)', text: l.telefone }));
    var detalhes = null;
    if (l.whatsapp) {
      var ctxMsg = function (tipo) { return { eu: String(eu.nome || '').trim().split(/\s+/)[0] || eu.usuario || '', saudacao: EQ.saudacao(), tipo: tipo }; };
      var ta = el('textarea', { id: 'm-' + l.id, rows: '6', maxlength: '1000', 'aria-label': 'Texto da mensagem para ' + l.nome });
      var retomar = paraRetomar(l);
      ta.value = EQMSG.montar(l, ctxMsg(retomar ? 'retomada' : 'primeira'));
      var tipoSel = el('select', { id: 'mt-' + l.id, 'aria-label': 'Tipo de mensagem' }, el('option', { value: 'primeira', text: 'Primeira mensagem' }), el('option', { value: 'retomada', text: 'Retomada (3 dias depois, sem resposta)' }));
      tipoSel.value = retomar ? 'retomada' : 'primeira';
      tipoSel.addEventListener('change', function () { ta.value = EQMSG.montar(l, ctxMsg(tipoSel.value)); });
      var zap = function () { return 'https://wa.me/' + l.whatsapp + '?text=' + enc(ta.value); };
      var wa = el('a', { class: 'botao-pq', href: zap(), target: '_blank', rel: 'noopener noreferrer', text: retomar ? 'Retomar no WhatsApp ↗' : 'Chamar no WhatsApp ↗', 'aria-label': (retomar ? 'Retomar conversa com ' : 'Chamar ') + l.nome + ' no WhatsApp com a mensagem pronta (abre em nova aba)' });
      wa.addEventListener('click', function () {
        wa.href = zap();
        // retomada enviada: o banco reinicia a contagem dos 3 dias
        if (retomar && tipoSel.value === 'retomada' && podeEditar(l)) salvar(l, { retomadas: (l.retomadas || 0) + 1 }, wa, card).then(function () { buscar(true); });
      });
      contato.appendChild(wa);
      detalhes = el('details', Object.assign({ class: 'msg' }, retomar ? { open: true } : {}), el('summary', { text: 'Ver ou editar a mensagem' }), tipoSel, ta,
        el('p', { class: 'mut', style: 'margin:6px 0 0;font-size:14px', text: 'Você decide se usa. O botão acima abre o WhatsApp com este texto. Mande uma por vez, com calma.' }));
    } else contato.appendChild(el('span', { class: 'selo', text: l.telefone ? 'Telefone fixo, sem WhatsApp' : 'Sem telefone no Maps' }));
    card.appendChild(contato);
    if (detalhes) card.appendChild(detalhes);

    var ctl = el('div', { class: 'lead-ctl' });
    var cx = el('input', { type: 'checkbox', id: 'c-' + l.id, 'data-k': 'primeira_msg', disabled: !podeEditar(l) });
    cx.checked = !!l.primeira_msg;
    cx.addEventListener('change', function () { salvar(l, { primeira_msg: cx.checked }, cx, card); });
    ctl.appendChild(el('label', { class: 'marca-cx', for: 'c-' + l.id }, cx, '1ª mensagem enviada'));
    ctl.appendChild(seletorTri('Respondeu?', l, 'respondeu', card));
    ctl.appendChild(seletorTri('Fechado?', l, 'fechado', card));
    var ob = el('input', { type: 'text', id: 'o-' + l.id, maxlength: '1000', value: l.observacao || '', disabled: !podeEditar(l), placeholder: 'Anotação' });
    ob.addEventListener('change', function () { salvar(l, { observacao: ob.value.trim() || null }, ob, card); });
    ctl.appendChild(el('div', { class: 'campo', style: 'margin:0' }, el('label', { for: 'o-' + l.id, text: 'Observação' }), ob));
    if (eu.papel === 'admin') ctl.appendChild(el('button', { type: 'button', class: 'botao-pq perigo', text: 'Apagar', 'aria-label': 'Apagar ' + l.nome, onclick: async function () {
      if (!confirm('Apagar "' + l.nome + '" de vez?')) return;
      try { await EQ.db('leads?id=eq.' + enc(l.id), { method: 'DELETE' }); buscar(true); } catch (er) { EQ.aviso(av, er.message, 'erro'); } } }));
    card.appendChild(ctl);
    return card;
  }

  var ultimos = [];
  function desenhar() {
    var box = $('lista'); box.textContent = '';
    ultimos.forEach(function (l) { box.appendChild(cartao(l)); });
    var pgs = Math.max(1, Math.ceil(total / POR_PAGINA));
    $('pag').hidden = total <= POR_PAGINA;
    $('pag-t').textContent = 'Página ' + (pagina + 1) + ' de ' + pgs;
    $('b-ant').disabled = pagina === 0; $('b-prox').disabled = pagina + 1 >= pgs;
  }
  async function buscar(manter) {
    if (!manter) pagina = 0;
    EQ.aviso(av, '');
    try {
      var r = await EQ.db('leads?' + montarConsulta(), { headers: { Prefer: 'count=exact' } });
      var cr = r.resp.headers.get('content-range') || '';
      total = parseInt(cr.split('/')[1], 10); if (!isFinite(total)) total = r.corpo.length;
      ultimos = r.corpo; buscou = true;
      $('contagem').textContent = total === 0 ? 'Nenhum lugar encontrado com esses filtros.' : total + (total === 1 ? ' lugar encontrado.' : ' lugares encontrados.');
      desenhar();
    } catch (er) { EQ.aviso(av, er.message, 'erro'); }
  }

  function opcoes(sel, lista, fmt) {
    var atual = sel.value; while (sel.options.length > 1) sel.remove(1);
    lista.forEach(function (v) { sel.appendChild(el('option', { value: v, text: fmt ? fmt(v) : v })); });
    sel.value = atual;
  }
  async function carregarFiltros() {
    var eq = await EQ.rpc('listar_equipe'); nomes = {};
    eq.forEach(function (p) { nomes[p.id] = p.nome; });
    var sel = $('f-dono'); while (sel.options.length > 1) sel.remove(1);
    eq.forEach(function (p) { sel.appendChild(el('option', { value: p.id, text: p.nome + (p.usuario ? ' (' + p.usuario + ')' : '') })); });
    var o = await EQ.rpc('opcoes_leads');
    opcoes($('f-uf'), o.ufs && o.ufs.length ? o.ufs : UFS);
    opcoes($('f-nicho'), o.nichos || [], cap);
    var dl = $('u-nichos'); dl.textContent = '';
    (o.nichos || []).forEach(function (n) { dl.appendChild(el('option', { value: n })); });
    var r = await EQ.rpc('resumo_equipe'), box = $('resumo'); box.textContent = '';
    r.forEach(function (x) {
      box.appendChild(el('div', { class: 'cartao' }, el('b', { text: nomes[x.dono] || 'Outra pessoa' }),
        el('div', { class: 'mut', text: x.total + ' leads · ' + x.sem_contato + ' sem contato · ' + x.em_andamento + ' aguardando · ' + x.para_retomar + ' p/ retomar · ' + x.respondeu_sim + ' sim · ' + x.fechados + ' fechados' })));
    });
  }

  $('f-filtro').addEventListener('submit', function (e) { e.preventDefault(); buscar(false); });
  $('b-limpar').addEventListener('click', function () {
    $('f-filtro').reset(); $('lista').textContent = ''; $('contagem').textContent = ''; $('pag').hidden = true; buscou = false; ultimos = [];
  });
  $('b-ant').addEventListener('click', function () { pagina--; buscar(true); });
  $('b-prox').addEventListener('click', function () { pagina++; buscar(true); });

  // ---------- upload ----------
  var dlg = $('dlg'), preparados = null;
  function avU(t, tipo) { EQ.aviso($('u-aviso'), t, tipo); }
  function fechar() { if (dlg.close) dlg.close(); else dlg.removeAttribute('open'); }
  $('b-subir').addEventListener('click', function () {
    $('u-arq').value = ''; $('u-form').hidden = true; $('u-so-fechar').hidden = false; avU(''); preparados = null;
    if (dlg.showModal) dlg.showModal(); else dlg.setAttribute('open', '');
    $('u-arq').focus();
  });
  $('u-fechar').addEventListener('click', fechar); $('u-fechar2').addEventListener('click', fechar);

  var brutas = null;
  function recalcular() {
    if (!brutas) return;
    var r = EQIMP.montar(brutas, { cidade: $('u-cidade').value, uf: $('u-uf').value, nicho: $('u-nicho').value, soSemSite: $('u-sosem').checked });
    preparados = r.leads;
    var s = r.stats;
    $('u-resumo').textContent = 'Arquivo com ' + s.lidas + ' lugares. Vão subir ' + s.aceitas + (s.repetidas ? ' (' + s.repetidas + ' repetidos no arquivo)' : '') + '. ' +
      (s.semWhats ? s.semWhats + ' sem WhatsApp (sem telefone ou telefone fixo). ' : '') + (s.invalidas ? s.invalidas + ' ignorados por falta de dados.' : '');
    $('u-enviar').disabled = !preparados.length;
  }
  ['u-cidade', 'u-uf', 'u-nicho'].forEach(function (i) { $(i).addEventListener('input', recalcular); });
  $('u-sosem').addEventListener('change', recalcular);
  $('u-arq').addEventListener('change', function () {
    var f = $('u-arq').files[0]; avU(''); $('u-form').hidden = true; brutas = null;
    if (!f) return;
    if (f.size > 5 * 1024 * 1024) return avU('Arquivo grande demais (máximo 5 MB).', 'erro');
    var fr = new FileReader();
    fr.onload = function () {
      try {
        brutas = EQIMP.lerArquivo(f.name, fr.result);
        if (!brutas.length) return avU('Não encontrei nenhum lugar nesse arquivo.', 'erro');
        var loc = EQIMP.localDaBusca(brutas[0].busca);
        $('u-cidade').value = loc.cidade; $('u-uf').value = loc.uf; $('u-nicho').value = '';
        $('u-form').hidden = false; $('u-so-fechar').hidden = true; recalcular();
      } catch (er) { avU('Não consegui ler esse arquivo. Use o CSV ou o JSON exportado pela extensão.', 'erro'); }
    };
    fr.readAsText(f, 'utf-8');
  });
  $('u-enviar').addEventListener('click', async function () {
    if (!preparados || !preparados.length) return;
    if (!$('u-cidade').value.trim() || !/^[A-Za-z]{2}$/.test($('u-uf').value.trim())) return avU('Informe a cidade e o estado (UF com 2 letras).', 'erro');
    var b = $('u-enviar'); EQ.ocupado(b, true, 'Subindo…');
    var novos = 0;
    try {
      for (var i = 0; i < preparados.length; i += 100) {
        var lote = preparados.slice(i, i + 100).map(function (x) { return Object.assign({}, x, { dono: eu.id }); });
        var r = await EQ.db('leads?on_conflict=chave&select=id', { method: 'POST', body: JSON.stringify(lote), headers: { Prefer: 'resolution=ignore-duplicates,return=representation' } });
        novos += (r.corpo || []).length;
      }
      var ja = preparados.length - novos;
      avU(novos + ' lugares novos cadastrados em seu nome.' + (ja ? ' ' + ja + ' já estavam na base (de você ou de outra pessoa) e foram ignorados.' : ''), 'ok');
      $('u-form').hidden = true; $('u-so-fechar').hidden = false; brutas = null;
      await carregarFiltros();
    } catch (er) { avU(er.message, 'erro'); }
    EQ.ocupado(b, false);
  });

  EQ.guarda().then(function (p) { eu = p; return carregarFiltros(); }).then(function () {
    $('contagem').textContent = 'Escolha os filtros e toque em Buscar. Nenhum cliente aparece antes disso.';
  }).catch(function (e) { EQ.aviso(av, e.message, 'erro'); });
})();
