/* Lê o CSV ou o JSON exportado pela extensão de leads do Google Maps e transforma em linhas para a tabela "leads".
   Código próprio. Roda no navegador (e também no Node, para os testes). */
(function (g) {
  'use strict';
  var REDES = ['instagram.com', 'facebook.com', 'fb.com', 'fb.me', 'linktr.ee', 'linktree.com', 'wa.me', 'whatsapp.com', 'tiktok.com', 'youtube.com',
    'youtu.be', 'linkedin.com', 'twitter.com', 'x.com', 'ifood.com.br', 'bit.ly', 'goo.gl', 'beacons.ai', 'bio.link', 'about.me', 'sites.google.com',
    'business.site', 'negocio.site', 'google.com', 'maps.app.goo.gl'];

  function semAcento(s) { return String(s == null ? '' : s).normalize('NFD').replace(/[̀-ͯ]/g, ''); }
  function norm(s) { return semAcento(s).toLowerCase().replace(/[^a-z0-9]+/g, ' ').trim(); }

  // ---- CSV (aceita ; ou , , aspas, quebras de linha dentro de aspas, BOM) ----
  function parseCSV(texto) {
    texto = String(texto).replace(/^﻿/, '');
    var primeira = texto.split(/\r?\n/, 1)[0] || '';
    var delim = (primeira.split(';').length >= primeira.split(',').length) ? ';' : ',';
    var linhas = [], atual = [], campo = '', aspas = false;
    for (var i = 0; i < texto.length; i++) {
      var c = texto[i];
      if (aspas) {
        if (c === '"') { if (texto[i + 1] === '"') { campo += '"'; i++; } else aspas = false; }
        else campo += c;
      } else if (c === '"') aspas = true;
      else if (c === delim) { atual.push(campo); campo = ''; }
      else if (c === '\n' || c === '\r') {
        if (c === '\r' && texto[i + 1] === '\n') i++;
        atual.push(campo); campo = '';
        if (atual.length > 1 || atual[0] !== '') linhas.push(atual);
        atual = [];
      } else campo += c;
    }
    if (campo !== '' || atual.length) { atual.push(campo); if (atual.length > 1 || atual[0] !== '') linhas.push(atual); }
    if (!linhas.length) return [];
    var cab = linhas[0].map(norm);
    return linhas.slice(1).map(function (l) { var o = {}; cab.forEach(function (h, i) { o[h] = (l[i] || '').trim(); }); return o; });
  }

  // ---- unifica CSV e JSON no mesmo formato ----
  function dePlanilha(r) {
    return { nome: r['empresa'], site: r['site'], telefone: r['telefone'], wa: r['whatsapp link'], categoria: r['categoria'], endereco: r['endereco'],
      nota: r['nota'], avaliacoes: r['avaliacoes'], mapsUrl: r['link google maps'], busca: r['busca de origem'], score: r['score'] };
  }
  function deJson(o) {
    return { nome: o.name, site: o.website, telefone: o.phone, e164: o.phoneE164, categoria: o.category, endereco: o.address, nota: o.rating,
      avaliacoes: o.reviews, mapsUrl: o.placeUrl, busca: o.query, score: o.score, cid: o.cid };
  }
  function lerArquivo(nome, texto) {
    var t = String(texto).replace(/^﻿/, '').trim();
    if (/\.json$/i.test(nome) || t[0] === '[' || t[0] === '{') {
      var d = JSON.parse(t);
      if (!Array.isArray(d)) d = d.leads || d.items || [d];
      return d.map(deJson);
    }
    return parseCSV(t).map(dePlanilha);
  }

  function hostDe(u) {
    try { return new URL(/^https?:\/\//i.test(u) ? u : 'https://' + u).hostname.replace(/^www\./, '').toLowerCase(); } catch (e) { return ''; }
  }
  function ehRede(u) { var h = hostDe(u); return !!h && REDES.some(function (r) { return h === r || h.slice(-r.length - 1) === '.' + r; }); }

  // telefone brasileiro: celular = DDD + 9 dígitos começando em 9 (aceita WhatsApp). Fixo não tem WhatsApp.
  function whats(r) {
    var d = String(r.e164 || '').replace(/\D/g, '');
    if (!d && r.wa) { var m = /wa\.me\/(\d{10,15})/.exec(r.wa); if (m) d = m[1]; }
    if (!d) d = String(r.telefone || '').replace(/\D/g, '');
    if (!d) return null;
    if (d.length === 10 || d.length === 11) d = '55' + d;
    if (d.indexOf('55') === 0) {
      var n = d.slice(2);
      return n.length === 11 && n[2] === '9' ? d : null;
    }
    return d.length >= 10 && d.length <= 15 ? d : null;
  }

  function cidDe(url) { var m = /1s(0x[0-9a-f]+:0x[0-9a-f]+)/i.exec(url || ''); return m ? m[1].toLowerCase() : ''; }
  function numero(v, casas) { var n = parseFloat(String(v == null ? '' : v).replace(',', '.')); return isFinite(n) ? Number(n.toFixed(casas)) : null; }

  // "Barbearia em São Paulo - SP" -> { cidade: 'São Paulo', uf: 'SP' }
  function localDaBusca(q) {
    var m = /\bem\s+(.+?)\s*[-,]\s*([A-Za-z]{2})\s*$/.exec(String(q || ''));
    return m ? { cidade: m[1].trim(), uf: m[2].toUpperCase() } : { cidade: '', uf: '' };
  }

  // opcoes: { cidade, uf, nicho (vazio = usar a Categoria de cada linha), soSemSite }
  function montar(linhas, opcoes) {
    opcoes = opcoes || {};
    var vistos = {}, saida = [], st = { lidas: linhas.length, invalidas: 0, repetidas: 0, comSite: 0, semWhats: 0, aceitas: 0 };
    linhas.forEach(function (r) {
      var nome = String(r.nome || '').trim().slice(0, 200);
      if (!nome) { st.invalidas++; return; }
      var site = String(r.site || '').trim().slice(0, 500);
      var rede = !!site && ehRede(site);
      var temSite = !!site && !rede;
      if (temSite) st.comSite++;
      if (opcoes.soSemSite && temSite) return;
      var w = whats(r);
      if (!w) st.semWhats++;
      var nicho = (opcoes.nicho || r.categoria || 'sem categoria').trim().toLowerCase().slice(0, 60);
      var cid = (r.cid || cidDe(r.mapsUrl)).toLowerCase();
      var tel = String(r.telefone || '').trim().slice(0, 40);
      var chave = (cid || (norm(nome) + '|' + (String(tel).replace(/\D/g, '') || norm(r.endereco)))).slice(0, 400);
      if (chave.length < 3) { st.invalidas++; return; }
      if (vistos[chave]) { st.repetidas++; return; }
      vistos[chave] = 1;
      var nota = numero(r.nota, 1), av = numero(r.avaliacoes, 0), sc = numero(r.score, 0);
      var uf = String(opcoes.uf || '').toUpperCase();
      saida.push({
        chave: chave, nome: nome, nicho: nicho, telefone: tel || null, whatsapp: w, tem_site: temSite, site: site || null, so_rede_social: rede,
        endereco: String(r.endereco || '').trim().slice(0, 300) || null, cidade: String(opcoes.cidade || '').trim().slice(0, 100) || null,
        uf: /^[A-Z]{2}$/.test(uf) ? uf : null, nota: nota != null && nota >= 0 && nota <= 5 ? nota : null,
        avaliacoes: av != null && av >= 0 ? Math.round(av) : null, maps_url: /^https:\/\/www\.google\.[a-z.]+\/maps\//i.test(r.mapsUrl || '') ? String(r.mapsUrl).slice(0, 800) : null,
        busca_origem: String(r.busca || '').slice(0, 200) || null, score: sc != null && sc >= 0 && sc <= 100 ? Math.round(sc) : null
      });
    });
    st.aceitas = saida.length;
    return { leads: saida, stats: st };
  }

  var API = { parseCSV: parseCSV, lerArquivo: lerArquivo, montar: montar, localDaBusca: localDaBusca, whats: whats, ehRede: ehRede };
  if (typeof module !== 'undefined' && module.exports) module.exports = API; else g.EQIMP = API;
})(typeof window !== 'undefined' ? window : globalThis);
