(function () {
  'use strict';
  var $ = function (i) { return document.getElementById(i); };
  var avisoEl = $('aviso');
  var vistas = ['v-config', 'v-login', 'v-codigo', 'v-link', 'v-senha'];
  var tokenLink = null; // token que veio no link do e-mail

  function mostrar(id, foco) {
    vistas.forEach(function (v) { $(v).hidden = v !== id; });
    EQ.aviso(avisoEl, '');
    var f = foco && $(foco); if (f) f.focus();
  }
  function msg(t, tipo) { EQ.aviso(avisoEl, t, tipo); }

  // 1) veio do link do e-mail? (convite ou recuperação)
  function lerLink() {
    var h = location.hash.replace(/^#/, '');
    if (!h) return null;
    var p = new URLSearchParams(h);
    history.replaceState(null, '', location.pathname);
    if (p.get('error')) return { erro: p.get('error_code') === 'otp_expired' ? 'Esse link venceu. Toque em "Primeiro acesso" para receber outro.' : 'Link inválido. Peça outro em "Primeiro acesso".' };
    if (p.get('access_token') && (p.get('type') === 'invite' || p.get('type') === 'recovery')) return { token: p.get('access_token') };
    return null;
  }

  async function iniciar() {
    if (!EQ.configurado()) { mostrar('v-config'); return; }
    var l = lerLink();
    if (l && l.token) { tokenLink = l.token; EQ.gravar(null); mostrar('v-senha', 's-nova'); return; }
    mostrar('v-login', 'l-id');
    if (l && l.erro) msg(l.erro, 'erro');
    // já logado e verificado nesta aba? vai direto ao painel
    var s = EQ.ler();
    if (s && s.ok) { try { if ((await EQ.rpc('sessao_verificada')) === true) location.replace('painel.html'); } catch (e) { /* fica no login */ } }
  }

  $('f-login').addEventListener('submit', async function (e) {
    e.preventDefault();
    var id = $('l-id').value.trim(), senha = $('l-senha').value;
    if (!id || !senha) return msg('Digite usuário (ou e-mail) e senha.', 'erro');
    var b = e.submitter || e.target.querySelector('button[type=submit]');
    EQ.ocupado(b, true, 'Entrando…');
    try {
      await EQ.entrar(id, senha);
      await EQ.fn('enviar_codigo');
      $('c-email').textContent = 'o seu e-mail cadastrado';
      mostrar('v-codigo', 'c-cod');
      msg('Código enviado. Veja também a caixa de spam.', 'info');
      cooldown();
    } catch (er) {
      EQ.gravar(null);
      if (er.status === 403 && /Confirme seu e-mail/.test(er.message)) {
        mostrar('v-link', 'k-id'); $('k-id').value = id; msg(er.message, 'erro');
      } else msg(er.message, 'erro');
    }
    EQ.ocupado(b, false);
  });

  var tmr;
  function cooldown() {
    var b = $('b-reenviar'), n = 30;
    b.disabled = true; clearInterval(tmr);
    tmr = setInterval(function () { n--; b.textContent = n > 0 ? 'Reenviar código (' + n + ')' : 'Reenviar código'; if (n <= 0) { clearInterval(tmr); b.disabled = false; } }, 1000);
  }
  $('b-reenviar').addEventListener('click', async function () {
    try { await EQ.fn('enviar_codigo'); msg('Novo código enviado.', 'ok'); cooldown(); } catch (er) { msg(er.message, 'erro'); }
  });
  $('b-voltar1').addEventListener('click', function () { EQ.gravar(null); mostrar('v-login', 'l-id'); });

  $('f-codigo').addEventListener('submit', async function (e) {
    e.preventDefault();
    var cod = $('c-cod').value.replace(/\s/g, '');
    if (!/^\d{6}$/.test(cod)) return msg('Digite os 6 números do código.', 'erro');
    var b = e.target.querySelector('button[type=submit]');
    EQ.ocupado(b, true, 'Conferindo…');
    try { await EQ.fn('verificar_codigo', { codigo: cod }); EQ.marcarVerificado(); location.replace('painel.html'); }
    catch (er) { msg(er.message, 'erro'); EQ.ocupado(b, false); }
  });

  $('b-primeiro').addEventListener('click', function () { mostrar('v-link', 'k-id'); });
  $('b-esqueci').addEventListener('click', function () { mostrar('v-link', 'k-id'); });
  $('b-voltar2').addEventListener('click', function () { mostrar('v-login', 'l-id'); });
  $('f-link').addEventListener('submit', async function (e) {
    e.preventDefault();
    var id = $('k-id').value.trim();
    if (!id) return msg('Digite seu usuário ou e-mail.', 'erro');
    var b = e.target.querySelector('button[type=submit]');
    EQ.ocupado(b, true, 'Enviando…');
    try { await EQ.fn('recuperar_senha', { identificador: id }); msg('Pronto. Se esse cadastro existir, o link chegou no e-mail dele (veja o spam). O link vale por 1 hora.', 'ok'); }
    catch (er) { msg(er.message, 'erro'); }
    EQ.ocupado(b, false);
  });

  $('f-senha').addEventListener('submit', async function (e) {
    e.preventDefault();
    var a = $('s-nova').value, c = $('s-conf').value;
    if (a !== c) return msg('As senhas não são iguais.', 'erro');
    var b = e.target.querySelector('button[type=submit]');
    EQ.ocupado(b, true, 'Salvando…');
    try {
      await EQ.fn('definir_senha', { senha: a }, tokenLink);
      tokenLink = null; $('s-nova').value = ''; $('s-conf').value = '';
      mostrar('v-login', 'l-id');
      msg('Senha criada e e-mail confirmado. Agora entre com seu usuário e a senha nova.', 'ok');
    } catch (er) { msg(er.message, 'erro'); }
    EQ.ocupado(b, false);
  });

  window.addEventListener('hashchange', iniciar);
  iniciar();
})();
