/* Mensagens de WhatsApp por nicho, baseadas no capítulo 3 do e-book "Fechando Clientes":
   cite algo real, dê antes de pedir, faça uma pergunta fácil (sim/não), fique abaixo de ~60 palavras,
   e retome 3 dias depois sem pressão. Quem usa pode editar o texto antes de abrir o WhatsApp.
   Para mudar os textos, edite este arquivo. Nunca invente dados: a nota e as avaliações só entram se vierem do lead. */
(function () {
  'use strict';
  function sem(n) { return String(n || '').toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '').trim(); }

  // o que o cliente do negócio não consegue fazer hoje (por nicho)
  var FALTA = {
    barbearia: ['barbearia', 'agendar o horário', 'escolher o horário'],
    'salao de beleza': ['salão', 'ver os serviços e agendar', 'marcar o horário'],
    cabeleireiro: ['salão', 'ver os serviços e agendar', 'marcar o horário'],
    restaurante: ['restaurante', 'ver o cardápio e fazer o pedido', 'ver o cardápio'],
    lanchonete: ['lanchonete', 'ver o cardápio e fazer o pedido', 'ver o cardápio'],
    pizzaria: ['pizzaria', 'ver o cardápio e fazer o pedido', 'ver o cardápio'],
    dentista: ['dentista', 'marcar a consulta', 'marcar a consulta'],
    clinica: ['clínica', 'marcar a consulta', 'marcar a consulta'],
    'pet shop': ['pet shop', 'agendar banho e tosa', 'agendar o banho e a tosa'],
    oficina: ['oficina', 'pedir orçamento', 'pedir orçamento'],
    'oficina mecanica': ['oficina', 'pedir orçamento', 'pedir orçamento'],
    academia: ['academia', 'ver os planos e falar com vocês', 'ver os planos'],
    tatuador: ['estúdio de tatuagem', 'ver os trabalhos e agendar', 'ver os trabalhos']
  };
  var PADRAO = ['negócio', 'ver os serviços e falar com vocês', 'ver os serviços'];

  function dados(lead) {
    var f = FALTA[sem(lead.nicho)] || PADRAO;
    return { tipo: f[0], falta: f[1], falta2: f[2] };
  }
  // trecho de prova real (só se existir e for bom)
  function prova(lead) {
    var n = Number(lead.nota), a = Number(lead.avaliacoes);
    if (n >= 4.3 && a >= 10) return ', com nota ' + String(n).replace('.', ',') + ' e ' + a + ' avaliações';
    if (n >= 4.3) return ', com ótima nota entre os clientes';
    return '';
  }
  function local(lead) { return lead.cidade ? ' em ' + lead.cidade : ''; }

  // ctx: { eu: primeiro nome de quem envia, saudacao: "Boa tarde", tipo: 'primeira' | 'retomada' }
  function montar(lead, ctx) {
    ctx = ctx || {};
    var d = dados(lead), eu = ctx.eu || '', s = ctx.saudacao || 'Olá';
    var quem = eu ? 'Me chamo ' + eu + ', da Hanei Tech.' : 'Sou da Hanei Tech.';
    if (ctx.tipo === 'retomada') {
      return 'Oi! Aqui é ' + (eu ? eu + ', da Hanei Tech' : 'da Hanei Tech') + '. Só passando para ver se a minha mensagem sobre a ' + (lead.nome || 'sua empresa') +
        ' se perdeu. Sem pressão: se não for um bom momento, é só me avisar que eu não incomodo mais.';
    }
    return s + '! ' + quem + ' Estava procurando ' + (d.tipo === 'negócio' ? 'negócios' : d.tipo.replace(/^(estúdio)/, 'um $1')) + local(lead) + ' e encontrei a ' + (lead.nome || 'sua empresa') + prova(lead) + '. ' +
      'Percebi que ainda não existe um site para o cliente ' + d.falta + ' pelo celular. Eu crio sites para negócios locais e posso te mostrar um exemplo de como ficaria o da ' + (lead.nome || 'sua empresa') + '. Podemos conversar?';
  }
  window.EQMSG = { montar: montar };
})();
