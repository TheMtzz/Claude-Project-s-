// Uso: node tools/configurar-equipe.mjs https://SEU-PROJETO.supabase.co SUA-CHAVE-ANON-OU-PUBLISHABLE
// Põe o endereço e a chave do Supabase em equipe/js/cfg.js e trava a CSP (_headers) só no seu projeto.
import { readFileSync, writeFileSync } from 'node:fs';
const [url, chave] = process.argv.slice(2);
if (!/^https:\/\/[a-z0-9-]+\.supabase\.co$/.test(url || '') || !chave || chave.length < 20) {
  console.error('Uso: node tools/configurar-equipe.mjs https://SEU-PROJETO.supabase.co SUA-CHAVE');
  process.exit(1);
}
if (/service_role/i.test(chave) || (chave.split('.').length === 3 && /"role"\s*:\s*"service_role"/.test(Buffer.from(chave.split('.')[1], 'base64url').toString()))) {
  console.error('Essa é a chave service_role (secreta). Use a chave anon/publishable.'); process.exit(1);
}
const raiz = new URL('../', import.meta.url);
const cfg = new URL('equipe/js/cfg.js', raiz), hd = new URL('_headers', raiz);
writeFileSync(cfg, readFileSync(cfg, 'utf8').replace(/url: '[^']*'/, `url: '${url}'`).replace(/chave: '[^']*'/, `chave: '${chave}'`));
writeFileSync(hd, readFileSync(hd, 'utf8').replace(/connect-src 'self' https:\/\/[^;]+;/, `connect-src 'self' ${url};`));
console.log('Pronto: cfg.js e _headers atualizados para', url);
