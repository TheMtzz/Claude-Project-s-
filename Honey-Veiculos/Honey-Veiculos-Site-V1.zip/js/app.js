(function () {
  'use strict';
  // ─────────────────────────────────────────────────────────────
  // WhatsApp da loja: só números, com DDI e DDD (exemplo: '5511912345678').
  // Este é um site-modelo fictício: enquanto estiver vazio, o botão abre o
  // WhatsApp com a mensagem pronta e a pessoa escolhe o contato.
  const WHATSAPP = '';
  // ─────────────────────────────────────────────────────────────
  const raiz = document.documentElement;
  raiz.classList.add('js');
  const semMovimento = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  const compacto = window.matchMedia('(max-width: 1040px)');
  const mouse = window.matchMedia('(hover: hover) and (pointer: fine)');

  document.querySelectorAll('[data-wa]').forEach((a) => {
    a.href = `https://wa.me/${WHATSAPP}?text=${encodeURIComponent(a.dataset.wa)}`;
    a.target = '_blank';
    a.rel = 'noopener';
  });

  // Entradas
  const observador = new IntersectionObserver((itens) => {
    itens.forEach((item) => {
      if (!item.isIntersecting) return;
      item.target.classList.add('visivel');
      observador.unobserve(item.target);
    });
  }, { rootMargin: '0px 0px -8% 0px', threshold: 0.08 });
  document.querySelectorAll('[data-sobe]').forEach((el) => observador.observe(el));
  document.querySelectorAll('.carro').forEach((el, i) => { el.style.setProperty('--atraso', `${(i % 4) * 80}ms`); observador.observe(el); });
  function revelarPassados() {
    document.querySelectorAll('[data-sobe]:not(.visivel), .carro:not(.visivel)').forEach((el) => {
      if (el.getBoundingClientRect().top < window.innerHeight) { el.classList.add('visivel'); observador.unobserve(el); }
    });
  }

  // Menu: destaca a seção na tela
  const topo = document.querySelector('.topo');
  const links = [...document.querySelectorAll('.topo-links a[data-secao]')];
  const secoes = links.map((a) => document.getElementById(a.dataset.secao)).filter(Boolean);
  function marcarSecao() {
    const meio = window.innerHeight * 0.4;
    let atual = null;
    for (const s of secoes) { const r = s.getBoundingClientRect(); if (r.top <= meio && r.bottom > meio) atual = s.id; }
    if (!atual && window.scrollY < 200) atual = 'inicio';
    links.forEach((a) => a.setAttribute('aria-current', String(a.dataset.secao === atual)));
  }

  // Menu lateral
  const gaveta = document.getElementById('gaveta');
  const botaoMenu = document.querySelector('.topo-menu');
  let focoAntes = null;
  function abrir() { focoAntes = document.activeElement; gaveta.hidden = false; botaoMenu.setAttribute('aria-expanded', 'true'); document.body.style.overflow = 'hidden'; gaveta.querySelector('.gaveta-fechar').focus(); }
  function fechar() { if (gaveta.hidden) return; gaveta.hidden = true; botaoMenu.setAttribute('aria-expanded', 'false'); document.body.style.overflow = ''; focoAntes && focoAntes.focus && focoAntes.focus(); }
  botaoMenu.addEventListener('click', abrir);
  gaveta.querySelectorAll('[data-fechar]').forEach((el) => el.addEventListener('click', fechar));
  document.addEventListener('keydown', (e) => {
    if (gaveta.hidden) return;
    if (e.key === 'Escape') fechar();
    if (e.key === 'Tab') {
      const f = [...gaveta.querySelectorAll('a, button')], a = f[0], z = f[f.length - 1];
      if (e.shiftKey && document.activeElement === a) { e.preventDefault(); z.focus(); }
      else if (!e.shiftKey && document.activeElement === z) { e.preventDefault(); a.focus(); }
    }
  });
  compacto.addEventListener('change', (e) => { if (!e.matches) fechar(); });

  // Catálogo: fotos em carrossel. Passe o mouse para ver as outras; no celular, deslize.
  document.querySelectorAll('.carro').forEach((carro) => {
    const trilho = carro.querySelector('.carro-slides');
    const pontos = carro.querySelector('.carro-pontos');
    let timer = null;
    const lista = () => [...trilho.children];
    function marcar() {
      const i = Math.round(trilho.scrollLeft / trilho.clientWidth);
      [...pontos.children].forEach((p, j) => p.classList.toggle('on', j === i));
    }
    function montarPontos() { pontos.innerHTML = lista().map(() => '<i></i>').join(''); marcar(); }
    trilho.addEventListener('scroll', () => requestAnimationFrame(marcar), { passive: true });
    montarPontos();
    const ir = (i) => trilho.scrollTo({ left: i * trilho.clientWidth, behavior: semMovimento ? 'auto' : 'smooth' });
    carro.addEventListener('mouseenter', () => {
      if (!mouse.matches || semMovimento || lista().length < 2) return;
      let i = 0;
      timer = setInterval(() => { i = (i + 1) % lista().length; ir(i); }, 1000);
    });
    carro.addEventListener('mouseleave', () => { clearInterval(timer); if (mouse.matches) trilho.scrollTo({ left: 0, behavior: 'auto' }); });
  });

  // Rolagem
  let ultimoY = window.scrollY, pedido = false;
  const carroHero = document.querySelector('.hero-foto');
  function aoRolar() {
    if (pedido) return; pedido = true;
    requestAnimationFrame(() => {
      const y = window.scrollY;
      topo.classList.toggle('solido', y > 40);
      topo.classList.toggle('escondido', compacto.matches && y > ultimoY && y > 200 && gaveta.hidden);
      ultimoY = y;
      if (carroHero && !semMovimento && y < window.innerHeight) carroHero.style.transform = `translate3d(0, ${(y * -0.06).toFixed(1)}px, 0)`;
      marcarSecao(); revelarPassados(); pedido = false;
    });
  }
  window.addEventListener('scroll', aoRolar, { passive: true });
  window.addEventListener('resize', aoRolar);
  topo.addEventListener('focusin', () => topo.classList.remove('escondido'));
  aoRolar();
})();
