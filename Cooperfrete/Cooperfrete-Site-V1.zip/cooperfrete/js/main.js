(function(){
  const NUM='5511964247976';
  const MESES=['Janeiro','Fevereiro','Março','Abril','Maio','Junho','Julho','Agosto','Setembro','Outubro','Novembro','Dezembro'];
  const DIAS=['domingo','segunda-feira','terça-feira','quarta-feira','quinta-feira','sexta-feira','sábado'];
  const ORC='Adquira sua passagem já. Faça o orçamento pelo botão do WhatsApp.';
  const P=[
    {id:'hopi',nome:'Hopi Hari',img:'img/hopi-hari.svg',txt:'Parque temático em Vinhedo (SP), com montanhas-russas e atrações para toda a família.',data:'2026-11-05'},
    {id:'wet',nome:'Wet’n Wild',img:'img/wet-n-wild.svg',txt:'Um dos maiores parques aquáticos do Brasil, em Itupeva (SP), a cerca de 45 minutos da capital, com mais de 25 atrações para todas as idades.',data:'2026-11-10'},
    {id:'sesc',nome:'Sesc Pompeia',img:'img/sesc-pompeia.webp',txt:'Centro de cultura, esporte e lazer instalado em uma antiga fábrica, em projeto da arquiteta Lina Bo Bardi.',data:'2026-11-07',link:'https://www.sescsp.org.br/unidades/11_POMPEIA/'},
    {id:'jaragua',nome:'Pico do Jaraguá',img:'img/pico-do-jaragua.webp',txt:'Ponto mais alto da cidade de São Paulo, dentro do Parque Estadual do Jaraguá, um dos últimos remanescentes de Mata Atlântica da região metropolitana.',data:'2026-11-02',link:'https://www.saopaulo.sp.gov.br/conhecasp/parques-e-reservas-naturais/parque-estadual-do-jaragua/'},
    {id:'sala',nome:'Sala São Paulo',img:'img/sala-sao-paulo.webp',txt:'Sede da Orquestra Sinfônica do Estado de São Paulo, instalada no imponente edifício da antiga Estrada de Ferro Sorocabana.',data:'2026-11-12',link:'http://www.salasaopaulo.art.br/home.aspx'},
    {id:'praia',nome:'Dia de praia',img:'img/praia.svg',txt:'Um dia de sol e mar no litoral paulista.',data:'2026-11-15'},
    {id:'ipiranga',nome:'Museu do Ipiranga',img:'img/museu-ipiranga.svg',txt:'Também conhecido como Museu Paulista, fica no Parque da Independência, no bairro do Ipiranga.',data:'2026-11-18'},
    {id:'pina',nome:'Pinacoteca de São Paulo',img:'img/pinacoteca.webp',txt:'Um dos principais museus de arte do Brasil, no centro de São Paulo, fundado em 1905.',data:'2026-11-20',link:'https://pinacoteca.org.br/'},
    {id:'pelezao',nome:'Clube Pelezão',img:'img/clube-pelezao.webp',txt:'Clube municipal na Lapa, com duas piscinas, quadras, playground e pista de caminhada.',end:'R. Belmonte, 957 - Alto da Lapa, São Paulo - SP, 05082-001',data:'2026-11-23',link:'https://prefeitura.sp.gov.br/noticia/ferias-clube-pelezao-e-opcao-de-lazer-na-lapa'},
    {id:'canto',nome:'Canto Cidadão',img:'img/canto-cidadao.webp',txt:'Espaço com programação cultural em Pinheiros, zona oeste de São Paulo.',end:'Rua Galeno de Almeida, 577 - Pinheiros, São Paulo - SP, 05410-030',data:'2026-11-26',link:'http://cantocidadao.org.br/'},
    {id:'centro',nome:'Centro de São Paulo',img:'img/centro-sp.svg',txt:'Roteiro pelo centro histórico, com marcos como o Pátio do Colégio e o Theatro Municipal.',data:'2026-11-29'}
  ];
  const porData=Object.fromEntries(P.map(function(p){return [p.data,p]}));
  const U={
    el:function(t,c,h){const e=document.createElement(t);if(c)e.className=c;if(h!=null)e.innerHTML=h;return e},
    wa:function(msg){return 'https://wa.me/'+NUM+'?text='+encodeURIComponent(msg)},
    pad:function(n){return n<10?'0'+n:''+n},
    br:function(iso){const d=iso.split('-');return d[2]+'/'+d[1]},
    dataExt:function(iso){const d=iso.split('-'),dt=new Date(+d[0],+d[1]-1,+d[2]);return DIAS[dt.getDay()]+', '+(+d[2])+' de '+MESES[+d[1]-1].toLowerCase()}
  };

  /* carrossel de passeios */
  function cartao(p,aoVerData){
    const c=U.el('article','pc');
    c.innerHTML='<img src="'+p.img+'" alt="'+p.nome+'" width="800" height="600" loading="lazy"><div class="pc-b"><h3>'+p.nome+'</h3><p>'+p.txt+'</p><div class="pc-l"></div></div>';
    const l=c.querySelector('.pc-l');
    const b=U.el('button',null,'Ver data');
    b.type='button';
    b.setAttribute('aria-label','Ver data da viagem para '+p.nome);
    b.addEventListener('click',function(){aoVerData(p.data)});
    l.appendChild(b);
    if(p.link){
      const a=U.el('a',null,'Saiba mais');
      a.href=p.link;a.target='_blank';a.rel='noopener';
      a.setAttribute('aria-label','Saiba mais sobre '+p.nome+' (abre em nova aba)');
      l.appendChild(a);
    }
    return c;
  }
  function initCarrossel(aoVerData){
    const car=document.getElementById('car'),prev=document.getElementById('prev'),next=document.getElementById('next');
    P.slice().sort(function(a,b){return a.data<b.data?-1:1}).forEach(function(p){car.appendChild(cartao(p,aoVerData))});
    const passo=function(){const c=car.querySelector('.pc');return c?c.getBoundingClientRect().width+20:300};
    const andar=function(dir){car.scrollBy({left:dir*passo(),behavior:'smooth'})};
    const setas=function(){prev.disabled=car.scrollLeft<4;next.disabled=car.scrollLeft+car.clientWidth>=car.scrollWidth-4};
    prev.addEventListener('click',function(){andar(-1)});
    next.addEventListener('click',function(){andar(1)});
    car.addEventListener('keydown',function(e){if(e.key==='ArrowRight'){andar(1)}if(e.key==='ArrowLeft'){andar(-1)}});
    car.addEventListener('scroll',setas,{passive:true});
    window.addEventListener('resize',setas);
    setas();
  }

  /* agenda */
  function htmlDetalhe(p,sel){
    const msg='Olá! Quero fazer o orçamento da viagem para '+p.nome+' no dia '+U.br(sel)+'.';
    let h='<img src="'+p.img+'" alt="'+p.nome+'" width="800" height="500"><div class="det-b"><p class="data">'+U.dataExt(sel)+'</p><h3>Viagem para '+p.nome+'</h3><p>'+p.txt+'</p>';
    if(p.end)h+='<p class="end">'+p.end+'</p>';
    h+='<p class="cta">'+ORC+'</p><div class="det-bt"><a class="btn btn-wa" href="'+U.wa(msg)+'" target="_blank" rel="noopener">Pedir orçamento desta viagem<span class="sr"> (abre o WhatsApp)</span></a>';
    if(p.link)h+='<a class="btn btn-line" href="'+p.link+'" target="_blank" rel="noopener">Saiba mais<span class="sr"> sobre '+p.nome+' (abre em nova aba)</span></a>';
    return h+'</div></div>';
  }
  function celulaViagem(d,mes,p,ev){
    const b=U.el('button','dia tem','<img src="'+p.img+'" alt=""><span class="n">'+d+'</span><span class="t">'+p.nome+'</span>');
    b.type='button';
    b.setAttribute('aria-pressed',ev.ativa?'true':'false');
    b.setAttribute('aria-label',d+' de '+MESES[mes].toLowerCase()+': viagem para '+p.nome);
    b.addEventListener('click',function(){ev.aoEscolher(false)});
    return b;
  }
  function itemLista(d,mes,p,ev){
    const li=U.el('li'),lb=U.el('button',null,'<b>'+U.pad(d)+'/'+U.pad(mes+1)+'</b><span>'+p.nome+'</span>');
    lb.type='button';
    lb.setAttribute('aria-pressed',ev.ativa?'true':'false');
    lb.addEventListener('click',function(){ev.aoEscolher(true)});
    li.appendChild(lb);
    return li;
  }
  function initAgenda(){
    const est={ano:2026,mes:10,sel:null};
    const grade=document.getElementById('grade'),nome=document.getElementById('mesNome'),lista=document.getElementById('lista'),det=document.getElementById('det');
    const detalhe=function(){
      const p=est.sel&&porData[est.sel];
      det.innerHTML=p?htmlDetalhe(p,est.sel):'<div class="det-vazio"><p class="data">Agenda</p><h3>Escolha uma viagem</h3><p>Toque em uma data marcada no calendário para ver os detalhes do passeio.</p></div>';
    };
    const escolher=function(iso,doItem){
      est.sel=iso;
      render();
      if(doItem){det.scrollIntoView({behavior:'smooth',block:'nearest'})}
      else if(window.innerWidth<=1000){det.scrollIntoView({behavior:'smooth',block:'start'})}
    };
    const diaDoMes=function(d){
      const iso=est.ano+'-'+U.pad(est.mes+1)+'-'+U.pad(d),p=porData[iso];
      if(!p){grade.appendChild(U.el('span','dia','<span class="n">'+d+'</span>'));return false}
      const ev={ativa:est.sel===iso,aoEscolher:function(doItem){escolher(iso,doItem)}};
      grade.appendChild(celulaViagem(d,est.mes,p,ev));
      lista.appendChild(itemLista(d,est.mes,p,ev));
      return true;
    };
    function render(){
      nome.textContent=MESES[est.mes]+' de '+est.ano;
      grade.innerHTML='';lista.innerHTML='';
      const ini=new Date(est.ano,est.mes,1).getDay(),tot=new Date(est.ano,est.mes+1,0).getDate();
      let n=0;
      for(let i=0;i<ini;i++){grade.appendChild(U.el('span','dia vazio'))}
      for(let d=1;d<=tot;d++){if(diaDoMes(d))n++}
      if(!n){lista.appendChild(U.el('li',null,'<p style="color:#4a5876;padding:6px 2px">Sem viagens marcadas neste mês. Peça um orçamento pelo WhatsApp.</p>'))}
      if(est.sel&&!porData[est.sel])est.sel=null;
      detalhe();
    }
    const mudaMes=function(delta){
      est.mes+=delta;
      if(est.mes<0){est.mes=11;est.ano--}
      if(est.mes>11){est.mes=0;est.ano++}
      est.sel=null;
      render();
    };
    document.getElementById('mesPrev').addEventListener('click',function(){mudaMes(-1)});
    document.getElementById('mesNext').addEventListener('click',function(){mudaMes(1)});
    est.sel='2026-11-05';
    render();
    return {mostrar:function(iso){
      const d=iso.split('-');
      est.ano=+d[0];est.mes=+d[1]-1;est.sel=iso;
      render();
      document.getElementById('agenda').scrollIntoView({behavior:'smooth'});
    }};
  }

  /* menu lateral (celular) */
  function initMenu(){
    const gav=document.getElementById('gaveta'),bg=document.getElementById('burger');
    const abre=function(v){
      gav.classList.toggle('on',v);
      gav.setAttribute('aria-hidden',v?'false':'true');
      bg.setAttribute('aria-expanded',v?'true':'false');
      document.body.style.overflow=v?'hidden':'';
      if(v){document.getElementById('gavetaX').focus()}else{bg.focus()}
    };
    bg.addEventListener('click',function(){abre(true)});
    document.getElementById('gavetaX').addEventListener('click',function(){abre(false)});
    document.getElementById('gavetaFundo').addEventListener('click',function(){abre(false)});
    gav.querySelectorAll('a').forEach(function(a){a.addEventListener('click',function(){abre(false)})});
    document.addEventListener('keydown',function(e){if(e.key==='Escape'&&gav.classList.contains('on'))abre(false)});
  }

  /* cabeçalho some ao descer (celular) */
  function initCabecalho(){
    const topo=document.getElementById('topo');
    let ult=0;
    window.addEventListener('scroll',function(){
      const y=window.scrollY;
      if(window.innerWidth<=900){topo.classList.toggle('esconde',y>ult&&y>120)}else{topo.classList.remove('esconde')}
      ult=y;
    },{passive:true});
  }

  /* entrada suave */
  function initEntrada(){
    document.documentElement.classList.add('js');
    const rev=document.querySelectorAll('.rev');
    if(!('IntersectionObserver' in window)){rev.forEach(function(r){r.classList.add('vis')});return}
    const io=new IntersectionObserver(function(es){es.forEach(function(e){if(e.isIntersecting){e.target.classList.add('vis');io.unobserve(e.target)}})},{threshold:.12});
    rev.forEach(function(r){io.observe(r)});
  }

  function iniciar(){
    const agenda=initAgenda();
    initCarrossel(agenda.mostrar);
    [initMenu,initCabecalho,initEntrada].forEach(function(f){f()});
  }
  iniciar();
})();
